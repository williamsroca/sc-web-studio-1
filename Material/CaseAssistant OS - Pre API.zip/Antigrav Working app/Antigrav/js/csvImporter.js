/**
 * Case Assistant OS - Smart CSV Importer & Non-Degrading Data Merger
 * Parses CasePeer CSV reports and merges new rows without overwriting user notes or recent contact dates.
 * Supports Smart Update & Merge (Default) as well as Fresh Initial Seed Mode.
 */

const CSVImporter = {
  /**
   * Auto-fetches local CSV files on first launch if storage is unitialized.
   */
  seedLocalFilesIfEmpty: async () => {
    if (localStorage.getItem(STORAGE_KEYS.INITIALIZED) === 'true') {
      Storage.runMigrations();
      return;
    }

    try {
      console.log('Seeding initial dataset from local CSV files...');
      
      const res1 = await fetch("Erin's Case List - Liability Pending.csv").catch(() => fetch("data/Erin's Case List - Liability Pending.csv")).catch(() => null);
      const res2 = await fetch("MedicalRequestsReport.csv").catch(() => fetch("data/MedicalRequestsReport.csv")).catch(() => null);
      const res3 = await fetch("MyCasesReport.csv").catch(() => fetch("data/MyCasesReport.csv")).catch(() => null);

      if (res1 && res2 && res3) {
        const text1 = await res1.text();
        const text2 = await res2.text();
        const text3 = await res3.text();

        CSVImporter.importCSVText(text3, 'MyCasesReport.csv', true, 'seed');
        CSVImporter.importCSVText(text1, "Erin's Case List - Liability Pending.csv", true, 'seed');
        CSVImporter.importCSVText(text2, 'MedicalRequestsReport.csv', true, 'seed');

        localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
        Storage.runMigrations();
        Storage.addActivityLog('System Seeded', 'Base dataset loaded from local CSV files.', 'System');
        return;
      }
    } catch (e) {
      console.warn('Could not auto-fetch CSV files, ready for drag & drop.', e);
    }
  },

  /**
   * Main entry point to parse and merge CSV string content.
   * @param {string} csvString
   * @param {string} fileName
   * @param {boolean} isInitialSeed
   * @param {string} importMode 'merge' (default) | 'seed'
   * @returns {Object|null} Import statistics
   */
  importCSVText: (csvString, fileName = 'Imported_File.csv', isInitialSeed = false, importMode = 'merge') => {
    const rows = Utils.parseCSV(csvString);
    if (!rows || rows.length < 2) {
      Utils.showToast('CSV file is empty or missing valid headers.', 'warning');
      return null;
    }

    const headers = rows[0].map(h => h.toLowerCase().trim());
    const dataRows = rows.slice(1);

    let addedCount = 0;
    let updatedCount = 0;
    let preservedNotesCount = 0;

    // Detect CSV Report Type based on headers
    if (headers.includes('medical provider') || headers.includes('request type')) {
      if (importMode === 'seed' && !isInitialSeed) {
        Storage.setArray(STORAGE_KEYS.REQUESTS, []);
      }
      const result = CSVImporter.mergeRequestsReport(headers, dataRows);
      addedCount = result.added;
      updatedCount = result.updated;
      preservedNotesCount = result.preservedNotes;
    } else if (headers.includes('3p liability') || headers.includes('vehicle location')) {
      if (importMode === 'seed' && !isInitialSeed) {
        Storage.setArray(STORAGE_KEYS.LIABILITY, []);
      }
      const result = CSVImporter.mergeLiabilityReport(headers, dataRows);
      addedCount = result.added;
      updatedCount = result.updated;
      preservedNotesCount = result.preservedNotes;
    } else if (headers.includes('file number') || headers.includes('statute')) {
      if (importMode === 'seed' && !isInitialSeed) {
        Storage.setArray(STORAGE_KEYS.CASES, []);
      }
      const result = CSVImporter.mergeMyCasesReport(headers, dataRows);
      addedCount = result.added;
      updatedCount = result.updated;
      preservedNotesCount = result.preservedNotes;
    } else {
      const result = CSVImporter.mergeRequestsReport(headers, dataRows);
      addedCount = result.added;
      updatedCount = result.updated;
      preservedNotesCount = result.preservedNotes;
    }

    const stats = { addedCount, updatedCount, preservedNotesCount, totalRows: dataRows.length };
    Storage.addImportHistory(fileName, stats);
    
    if (!isInitialSeed) {
      localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
      Storage.addActivityLog('CSV Imported', `Imported "${fileName}" [${importMode.toUpperCase()}]: ${addedCount} added, ${updatedCount} updated, ${preservedNotesCount} notes kept.`, 'CSV');
      Utils.showToast(`Import successful: ${addedCount} new, ${updatedCount} updated!`, 'success');
    }

    return stats;
  },

  // ==========================================
  // SPECIFIC REPORT TYPE MERGERS
  // ==========================================

  /**
   * Merges Medical Records / Billing CSV report.
   */
  mergeRequestsReport: (headers, dataRows) => {
    const existingReqs = Storage.getRequests();
    const existingCases = Storage.getCases();
    let added = 0;
    let updated = 0;
    let preservedNotes = 0;

    const col = (row, name) => {
      const idx = headers.indexOf(name.toLowerCase());
      return idx >= 0 && row[idx] !== undefined ? row[idx].trim() : '';
    };

    dataRows.forEach(row => {
      const rawCase = col(row, 'case');
      if (!rawCase) return;

      const { clientName, dol } = Utils.extractClientAndDOL(rawCase);
      const provider = col(row, 'medical provider');
      const requestType = col(row, 'request type');
      const status = col(row, 'status') || 'Requested';
      const requestDate = col(row, 'request date');
      const caseStatus = col(row, 'case status');
      const leadAttorney = col(row, 'lead attorney');
      const caseManager = col(row, 'case manager');
      const doi = col(row, 'doi') || dol;

      const matchIdx = existingReqs.findIndex(r => 
        (r.clientName.toLowerCase() === clientName.toLowerCase() || r.rawCase === rawCase) &&
        r.provider.toLowerCase() === provider.toLowerCase() &&
        r.requestType.toLowerCase() === requestType.toLowerCase()
      );

      if (matchIdx >= 0) {
        const oldItem = existingReqs[matchIdx];
        if (oldItem.notes && oldItem.notes.trim()) preservedNotes++;

        let finalLastContact = oldItem.lastContactDate || oldItem.lastFollowUpDate || '';
        if (requestDate && Utils.isNewerDate(requestDate, finalLastContact)) {
          finalLastContact = requestDate;
        }

        existingReqs[matchIdx] = {
          ...oldItem,
          status: oldItem.status === 'Received' || oldItem.status === 'Closed' ? oldItem.status : (status || oldItem.status),
          initialRequestDate: oldItem.initialRequestDate || requestDate || Utils.formatDate(new Date()),
          lastContactDate: finalLastContact,
          caseStatus: caseStatus || oldItem.caseStatus,
          leadAttorney: leadAttorney || oldItem.leadAttorney,
          caseManager: caseManager || oldItem.caseManager,
          updatedAt: new Date().toISOString()
        };
        updated++;
      } else {
        existingReqs.push({
          id: Utils.generateId(),
          clientName,
          dol: doi,
          rawCase,
          provider,
          requestType,
          status,
          initialRequestDate: requestDate || Utils.formatDate(new Date()),
          lastContactDate: requestDate || '',
          lastFollowUpDate: requestDate || '',
          nextFollowUpDate: requestDate ? Utils.formatDate(new Date(Utils.parseDate(requestDate).getTime() + 7 * 24 * 60 * 60 * 1000)) : '',
          contactMethod: 'Fax/Email',
          fax: '',
          email: '',
          phone: '',
          caseStatus,
          leadAttorney,
          caseManager,
          notes: '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        added++;
      }

      const caseIdx = existingCases.findIndex(c => c.clientName.toLowerCase() === clientName.toLowerCase());
      if (caseIdx === -1) {
        existingCases.push({
          id: Utils.generateId(),
          clientName,
          dol: doi,
          rawCase,
          caseStatus: caseStatus || 'Treating',
          attorney: leadAttorney,
          caseManager,
          insurance: '',
          adjuster: '',
          claimNumber: '',
          liabilityStatus: 'Unknown',
          notes: '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
    });

    Storage.setArray(STORAGE_KEYS.REQUESTS, existingReqs);
    Storage.setArray(STORAGE_KEYS.CASES, existingCases);
    return { added, updated, preservedNotes };
  },

  /**
   * Merges Liability Pending CSV report.
   */
  mergeLiabilityReport: (headers, dataRows) => {
    const existingLiab = Storage.getLiabilityItems();
    const existingCases = Storage.getCases();
    let added = 0;
    let updated = 0;
    let preservedNotes = 0;

    const col = (row, name) => {
      const idx = headers.indexOf(name.toLowerCase());
      return idx >= 0 && row[idx] !== undefined ? row[idx].trim() : '';
    };

    dataRows.forEach(row => {
      const rawCase = col(row, 'case');
      if (!rawCase) return;

      const { clientName, dol } = Utils.extractClientAndDOL(rawCase);
      const doi = col(row, 'doi') || dol;
      const caseType = col(row, 'case type');
      const caseStatus = col(row, 'case status');
      const liabilityStatus = col(row, '3p liability') || 'Pending';
      const policyLimit = col(row, 'policy limit');
      const vehicleLocation = col(row, 'vehicle location');
      const ins1P = col(row, '1p');
      const ins3P = col(row, '3p');
      const caseManager = col(row, 'case manager') || col(row, 'lead attorney') || col(row, 'primary') ||
        (existingCases.find(c => c.clientName.toLowerCase() === clientName.toLowerCase())?.caseManager) || 'Erin Garcia';

      const matchIdx = existingLiab.findIndex(l => 
        l.clientName.toLowerCase() === clientName.toLowerCase()
      );

      if (matchIdx >= 0) {
        const oldItem = existingLiab[matchIdx];
        if (oldItem.notes && oldItem.notes.trim()) preservedNotes++;

        existingLiab[matchIdx] = {
          ...oldItem,
          caseManager: oldItem.caseManager || caseManager,
          liabilityStatus: liabilityStatus || oldItem.liabilityStatus,
          insurance3P: ins3P || oldItem.insurance3P,
          insurance1P: ins1P || oldItem.insurance1P,
          policyLimit: policyLimit || oldItem.policyLimit,
          vehicleLocation: vehicleLocation || oldItem.vehicleLocation,
          updatedAt: new Date().toISOString()
        };
        updated++;
      } else {
        existingLiab.push({
          id: Utils.generateId(),
          clientName,
          dol: doi,
          rawCase,
          caseType,
          caseStatus,
          caseManager,
          insurance3P: ins3P,
          insurance1P: ins1P,
          adjuster: '',
          claimNumber: '',
          liabilityStatus,
          policeReportStatus: 'Pending',
          decPageStatus: 'Pending',
          pendingItems: 'Police Report: Pending | DEC Page: Pending',
          lastContactDate: '',
          lastFollowUpDate: '',
          nextFollowUpDate: '',
          policyLimit,
          vehicleLocation,
          notes: '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        added++;
      }

      const caseIdx = existingCases.findIndex(c => c.clientName.toLowerCase() === clientName.toLowerCase());
      if (caseIdx >= 0) {
        existingCases[caseIdx].liabilityStatus = liabilityStatus;
        existingCases[caseIdx].insurance = ins3P || ins1P || existingCases[caseIdx].insurance;
      }
    });

    Storage.setArray(STORAGE_KEYS.LIABILITY, existingLiab);
    Storage.setArray(STORAGE_KEYS.CASES, existingCases);
    return { added, updated, preservedNotes };
  },

  /**
   * Merges My Cases CSV report.
   */
  mergeMyCasesReport: (headers, dataRows) => {
    const existingCases = Storage.getCases();
    let added = 0;
    let updated = 0;
    let preservedNotes = 0;

    const col = (row, name) => {
      const idx = headers.indexOf(name.toLowerCase());
      return idx >= 0 && row[idx] !== undefined ? row[idx].trim() : '';
    };

    dataRows.forEach(row => {
      const rawCase = col(row, 'case');
      if (!rawCase) return;

      const { clientName, dol } = Utils.extractClientAndDOL(rawCase);
      const doi = col(row, 'doi') || dol;
      const caseType = col(row, 'case type');
      const caseStatus = col(row, 'case status');
      const primary = col(row, 'primary');
      const language = col(row, 'language');
      const statute = col(row, 'statute');
      const lastTouched = col(row, 'last touched');
      const fileNumber = col(row, 'file number');

      const matchIdx = existingCases.findIndex(c => 
        c.clientName.toLowerCase() === clientName.toLowerCase()
      );

      if (matchIdx >= 0) {
        const oldItem = existingCases[matchIdx];
        if (oldItem.notes && oldItem.notes.trim()) preservedNotes++;

        existingCases[matchIdx] = {
          ...oldItem,
          caseType: caseType || oldItem.caseType,
          caseStatus: caseStatus || oldItem.caseStatus,
          caseManager: primary || oldItem.caseManager,
          language: language || oldItem.language,
          statute: statute || oldItem.statute,
          lastTouched: lastTouched || oldItem.lastTouched,
          fileNumber: fileNumber || oldItem.fileNumber,
          updatedAt: new Date().toISOString()
        };
        updated++;
      } else {
        existingCases.push({
          id: Utils.generateId(),
          clientName,
          dol: doi,
          rawCase,
          caseType,
          caseStatus,
          caseManager: primary,
          language,
          statute,
          lastTouched,
          fileNumber,
          insurance: '',
          adjuster: '',
          claimNumber: '',
          liabilityStatus: 'Pending',
          notes: '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        added++;
      }
    });

    Storage.setArray(STORAGE_KEYS.CASES, existingCases);
    return { added, updated, preservedNotes };
  }
};

window.CSVImporter = CSVImporter;
