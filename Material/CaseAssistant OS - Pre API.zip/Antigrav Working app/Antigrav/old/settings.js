/**
 * Case Assistant v1.5 - Settings & Data Management Module
 */

const Settings = {
  init: () => {
    Settings.renderStats();
  },

  renderStats: () => {
    const versionEl = document.getElementById('settings-version');
    const casesCount = document.getElementById('settings-cases-count');
    const reqsCount = document.getElementById('settings-reqs-count');
    const liabCount = document.getElementById('settings-liab-count');
    const storageBytesEl = document.getElementById('settings-storage-bytes');

    if (versionEl) versionEl.textContent = Storage.CURRENT_VERSION;
    if (casesCount) casesCount.textContent = Storage.getCases().length;
    if (reqsCount) reqsCount.textContent = Storage.getRequests().length;
    if (liabCount) liabCount.textContent = Storage.getLiabilityItems().length;

    if (storageBytesEl) {
      let totalBytes = 0;
      for (let x in localStorage) {
        if (localStorage.hasOwnProperty(x)) {
          totalBytes += (localStorage[x].length + x.length) * 2;
        }
      }
      const kb = (totalBytes / 1024).toFixed(2);
      storageBytesEl.textContent = `${kb} KB`;
    }
  },

  // Export JSON Backup
  exportData: () => {
    Storage.exportBackupJSON();
  },

  // Import JSON Backup
  importData: (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      Storage.importBackupJSON(evt.target.result);
    };
    reader.readAsText(file);
  },

  // Clear Database with Custom Modal Confirmation
  wipeDatabase: () => {
    Storage.clearAllData();
  }
};

window.Settings = Settings;
