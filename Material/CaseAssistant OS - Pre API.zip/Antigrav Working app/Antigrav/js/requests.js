/**
 * Case Assistant OS - Medical Records & Billing Requests Controller
 * Handles table rendering, multi-criteria filtering, status inline updates, follow-up logging,
 * and top section summary header cards.
 */

const Requests = {
  activeSearch: '',
  activeProviderFilter: '',
  activeManagerFilter: '',
  activeStatusFilter: '',
  activeTypeFilter: '',
  activeAgingFilter: '',

  /**
   * Initializes Requests tab controller.
   */
  init: () => {
    Requests.renderSummaryHeader();
    Requests.renderRequestsTable();
    Requests.setupFilters();
  },

  /**
   * Sets status filter programmatically from Dashboard KPI navigation.
   * @param {string} status
   */
  setFilterStatus: (status) => {
    Requests.activeStatusFilter = (status || '').toLowerCase();
    const statusSelect = document.getElementById('req-filter-status');
    if (statusSelect) statusSelect.value = status ? status : '';
    Requests.renderSummaryHeader();
    Requests.renderRequestsTable();
  },

  /**
   * Sets aging filter programmatically from Dashboard KPI navigation.
   * @param {string} aging
   */
  setFilterAging: (aging) => {
    Requests.activeAgingFilter = aging || '';
    const agingSelect = document.getElementById('req-filter-aging');
    if (agingSelect) agingSelect.value = aging ? aging : '';
    Requests.renderSummaryHeader();
    Requests.renderRequestsTable();
  },

  /**
   * Sets provider filter programmatically.
   * @param {string} provider
   */
  setFilterProvider: (provider) => {
    Requests.activeProviderFilter = provider || '';
    const providerSelect = document.getElementById('req-filter-provider');
    if (providerSelect) providerSelect.value = provider ? provider : '';
    Requests.renderSummaryHeader();
    Requests.renderRequestsTable();
  },

  /**
   * Sets up DOM event listeners for filter inputs and selectors.
   */
  setupFilters: () => {
    const searchInput = document.getElementById('req-search-input');
    const providerSelect = document.getElementById('req-filter-provider');
    const managerSelect = document.getElementById('req-filter-manager');
    const statusSelect = document.getElementById('req-filter-status');
    const typeSelect = document.getElementById('req-filter-type');
    const agingSelect = document.getElementById('req-filter-aging');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        Requests.activeSearch = e.target.value.toLowerCase().trim();
        Requests.renderRequestsTable();
      });
    }

    if (providerSelect) {
      providerSelect.addEventListener('change', (e) => {
        Requests.activeProviderFilter = e.target.value;
        Requests.renderRequestsTable();
      });
    }

    if (managerSelect) {
      managerSelect.addEventListener('change', (e) => {
        Requests.activeManagerFilter = e.target.value.toLowerCase();
        Requests.renderRequestsTable();
      });
    }

    if (statusSelect) {
      statusSelect.addEventListener('change', (e) => {
        Requests.activeStatusFilter = e.target.value.toLowerCase();
        Requests.renderRequestsTable();
      });
    }

    if (typeSelect) {
      typeSelect.addEventListener('change', (e) => {
        Requests.activeTypeFilter = e.target.value.toLowerCase();
        Requests.renderRequestsTable();
      });
    }

    if (agingSelect) {
      agingSelect.addEventListener('change', (e) => {
        Requests.activeAgingFilter = e.target.value;
        Requests.renderRequestsTable();
      });
    }
  },

  /**
   * Renders top Section Summary Header cards for Requests tab.
   */
  renderSummaryHeader: () => {
    const container = document.getElementById('requests-summary-header');
    if (!container) return;

    const reqs = Utils.filterByActiveCaseManager(Storage.getRequests());
    const total = reqs.length;
    let pending = 0;
    let completed = 0;
    let overdue = 0;

    reqs.forEach(r => {
      const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
      if (aging.level === 'completed') completed++;
      else {
        pending++;
        if (aging.level === 'overdue' || aging.level === 'unknown') overdue++;
      }
    });

    container.innerHTML = `
      <div class="kpi-grid mb-3">
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Requests.setFilterStatus('')">
          <span class="kpi-title">Total Requests</span>
          <span class="kpi-value">${total}</span>
          <span class="kpi-sub">all medical/billing</span>
        </div>
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Requests.setFilterStatus('pending')">
          <span class="kpi-title">Pending</span>
          <span class="kpi-value" style="color:var(--accent-primary)">${pending}</span>
          <span class="kpi-sub">in process</span>
        </div>
        <div class="kpi-card glass-card border-left-danger" style="cursor:pointer;" onclick="Requests.setFilterAging('overdue')">
          <span class="kpi-title">Overdue (30+ Days)</span>
          <span class="kpi-value" style="color:var(--status-danger)">${overdue}</span>
          <span class="kpi-sub">action needed</span>
        </div>
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Requests.setFilterStatus('received')">
          <span class="kpi-title">Completed (Received)</span>
          <span class="kpi-value" style="color:var(--status-success)">${completed}</span>
          <span class="kpi-sub">records received</span>
        </div>
      </div>
    `;
  },

  /**
   * Renders the Requests table with multi-criteria filtering applied.
   */
  renderRequestsTable: () => {
    const container = document.getElementById('requests-table-body');
    if (!container) return;

    const rawReqs = Storage.getRequests();

    // Dynamically Populate Provider Dropdown
    const providerSelect = document.getElementById('req-filter-provider');
    if (providerSelect && providerSelect.options.length <= 1) {
      const providers = Array.from(new Set(rawReqs.map(r => r.provider).filter(Boolean))).sort();
      providers.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p;
        opt.textContent = p;
        providerSelect.appendChild(opt);
      });
    }

    // Dynamically Populate Case Manager Dropdown
    const managerSelect = document.getElementById('req-filter-manager');
    if (managerSelect && managerSelect.options.length <= 1) {
      const managers = Array.from(new Set(rawReqs.map(r => r.caseManager || r.leadAttorney).filter(Boolean))).sort();
      managers.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m;
        opt.textContent = m;
        managerSelect.appendChild(opt);
      });
    }

    // Apply Global Active Case Manager Filter (Single Source of Truth)
    let reqs = Utils.filterByActiveCaseManager(rawReqs);

    // Apply Search Filter
    if (Requests.activeSearch) {
      const q = Requests.activeSearch;
      reqs = reqs.filter(r => 
        (r.clientName || '').toLowerCase().includes(q) ||
        (r.provider || '').toLowerCase().includes(q) ||
        (r.dol || '').toLowerCase().includes(q) ||
        (r.status || '').toLowerCase().includes(q) ||
        (r.requestType || '').toLowerCase().includes(q) ||
        (r.caseManager || r.leadAttorney || '').toLowerCase().includes(q)
      );
    }

    // Apply Dropdown Filters
    if (Requests.activeProviderFilter) {
      reqs = reqs.filter(r => r.provider === Requests.activeProviderFilter);
    }

    if (Requests.activeManagerFilter) {
      reqs = reqs.filter(r => (r.caseManager || r.leadAttorney || '').toLowerCase().includes(Requests.activeManagerFilter));
    }

    if (Requests.activeStatusFilter) {
      reqs = reqs.filter(r => (r.status || '').toLowerCase() === Requests.activeStatusFilter);
    }

    if (Requests.activeTypeFilter) {
      reqs = reqs.filter(r => (r.requestType || '').toLowerCase().includes(Requests.activeTypeFilter));
    }

    if (Requests.activeAgingFilter) {
      reqs = reqs.filter(r => {
        const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
        return aging.level === Requests.activeAgingFilter;
      });
    }

    if (reqs.length === 0) {
      container.innerHTML = `
        <tr>
          <td colspan="8" class="text-center text-muted py-4">
            No medical requests found matching the selected criteria.
          </td>
        </tr>
      `;
      return;
    }

    container.innerHTML = reqs.map(r => {
      const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
      const manager = r.caseManager || r.leadAttorney || 'Erin Garcia';

      return `
        <tr id="req-row-${r.id}">
          <td>
            <strong>${r.clientName}</strong>
            <div style="font-size:0.75rem; color:var(--text-muted)">DOL: ${r.dol || 'N/A'}</div>
          </td>
          <td>🏥 <strong>${r.provider}</strong></td>
          <td><span class="badge badge-info">${r.requestType || 'Billing & Records'}</span></td>
          <td><span class="badge badge-outline">${manager}</span></td>
          <td>
            <select class="form-select-sm status-select" onchange="Requests.updateStatus('${r.id}', this.value)">
              <option value="Requested" ${r.status === 'Requested' ? 'selected' : ''}>Requested</option>
              <option value="Pending" ${r.status === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Follow Up Needed" ${r.status === 'Follow Up Needed' ? 'selected' : ''}>Follow Up Needed</option>
              <option value="Received" ${r.status === 'Received' ? 'selected' : ''}>Received</option>
              <option value="Closed" ${r.status === 'Closed' ? 'selected' : ''}>Closed</option>
            </select>
          </td>
          <td>${r.initialRequestDate || r.requestDate || '-'}</td>
          <td>
            <span class="badge ${aging.badgeClass}">${aging.label}</span>
            <div style="font-size:0.75rem; color:var(--text-muted)">Next: ${r.nextFollowUpDate || r.nextFollowUp || 'Not scheduled'}</div>
          </td>
          <td>
            <div class="action-btn-group">
              <button class="btn btn-xs btn-primary" onclick="Requests.openRegisterFollowUpModal('${r.id}')" title="Register Follow Up">📞 Follow Up</button>
              <button class="btn btn-xs btn-success" onclick="Requests.quickMarkReceived('${r.id}')" title="Mark Received">✅ Received</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  /**
   * Updates the status of a request item.
   * @param {string} reqId
   * @param {string} newStatus
   */
  updateStatus: (reqId, newStatus) => {
    const reqs = Storage.getRequests();
    const r = reqs.find(item => item.id === reqId);
    if (!r) return;

    r.status = newStatus;
    if (newStatus === 'Received' || newStatus === 'Closed') {
      r.lastContactDate = Utils.formatDate(new Date());
    }
    Storage.saveRequest(r);

    const noteText = `Updated request status to ${newStatus}.`;
    NotesEngine.createNote(r.clientName, r.dol, noteText);
    Storage.addActivityLog('Request Status Updated', `${r.clientName} - ${r.provider}: Status changed to ${newStatus}`, 'Requests');
    Utils.showToast(`Request status updated to ${newStatus}`, 'success');

    Requests.renderSummaryHeader();
    Dashboard.init();
  },

  /**
   * Opens the Follow Up modal for a specific request.
   * @param {string} reqId
   */
  openRegisterFollowUpModal: (reqId) => {
    const reqs = Storage.getRequests();
    const r = reqs.find(item => item.id === reqId);
    if (!r) return;

    Modals.openFollowUpModal({
      title: 'Register Request Follow Up',
      clientName: r.clientName,
      dol: r.dol,
      providerOrIns: `${r.provider} (${r.requestType})`,
      type: 'Request',
      onSave: (data) => {
        const nextDate = Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000));
        
        r.lastContactDate = data.contactDate;
        r.lastFollowUpDate = data.contactDate;
        r.nextFollowUpDate = nextDate;
        r.status = data.outcome.includes('Received') ? 'Received' : 'Pending';
        
        const summary = `[${data.medium}] ${data.outcome}.${data.nextStep ? ' ' + data.nextStep : ''}`.trim();
        r.notes = (r.notes ? r.notes + '\n' : '') + summary;
        
        Storage.saveRequest(r);

        NotesEngine.createRichFollowUpNote({
          clientName: r.clientName,
          dol: r.dol,
          providerOrIns: `${r.provider} (${r.requestType})`,
          contactDate: data.contactDate,
          medium: data.medium,
          person: data.person,
          outcome: data.outcome,
          nextStep: data.nextStep,
          notes: data.notes,
          nextFollowUpDate: nextDate
        });

        Storage.addActivityLog('Follow Up Registered', `${r.clientName} - ${r.provider}: Follow up logged`, 'Requests');
        Utils.showToast('Follow-Up registered & notes generated!', 'success');

        Requests.renderSummaryHeader();
        Requests.renderRequestsTable();
        Dashboard.init();
      }
    });
  },

  /**
   * Quick action to mark a request as Received.
   * @param {string} reqId
   */
  quickMarkReceived: (reqId) => {
    const reqs = Storage.getRequests();
    const r = reqs.find(item => item.id === reqId);
    if (!r) return;

    r.status = 'Received';
    r.lastContactDate = Utils.formatDate(new Date());
    r.notes = (r.notes ? r.notes + '\n' : '') + `Received ${r.requestType} from ${r.provider}.`;
    Storage.saveRequest(r);

    const noteText = `Received ${r.requestType} from provider ${r.provider}. Completed.`;
    NotesEngine.createNote(r.clientName, r.dol, noteText);
    Storage.addActivityLog('Records Received', `${r.clientName} - ${r.provider}: Request marked received`, 'Requests');
    Utils.showToast(`Request marked as Received!`, 'success');

    Requests.renderSummaryHeader();
    Requests.renderRequestsTable();
    Dashboard.init();
  }
};

window.Requests = Requests;
