/**
 * Case Assistant OS - Case Details View Controller
 * Pure View Controller: Decoupled from Storage & data persistence.
 * Accepts ready-to-render caseData objects and delegates client logic exclusively to ClientHelper.
 */

const CaseDetails = {
  /**
   * Opens and renders the Case Details workspace for a provided caseData object.
   * Pure view method: Does not access Storage directly.
   * @param {Object} caseData Ready-to-render case data object
   */
  open: (caseData) => {
    if (!caseData || typeof caseData !== 'object') return;

    const modal = document.getElementById('case-modal');
    const modalBody = document.getElementById('case-modal-body');
    if (!modal || !modalBody) return;

    const primaryClientName = ClientHelper.formatSingleClient(caseData);

    modalBody.innerHTML = `
      <div class="case-details-workspace">
        <div class="modal-header-banner glass-card mb-3 p-3" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
          <div>
            <h2 style="margin:0; font-size:1.4rem;">📁 ${primaryClientName || 'Case Details'}</h2>
            <div style="font-size:0.85rem; color:var(--text-muted); margin-top:0.25rem;">
              <span><strong>File #:</strong> ${caseData.fileNumber || 'N/A'}</span> &bull; 
              <span><strong>DOL:</strong> ${caseData.dol || 'N/A'}</span> &bull; 
              <span><strong>Manager:</strong> ${caseData.caseManager || 'Erin Garcia'}</span>
            </div>
          </div>
          <span class="badge badge-info" style="font-size:0.9rem; padding:0.4rem 0.8rem;">${caseData.caseStatus || 'Active'}</span>
        </div>

        <div class="case-details-grid" style="display:grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
          <!-- Left Column -->
          <div style="display:flex; flex-direction:column; gap:1rem;">
            ${CaseDetails.renderCaseInfo(caseData)}
            ${CaseDetails.renderClients(caseData)}
            ${CaseDetails.renderTreatment(caseData)}
          </div>

          <!-- Right Column -->
          <div style="display:flex; flex-direction:column; gap:1rem;">
            ${CaseDetails.renderAITools(caseData)}
            ${CaseDetails.renderRequests(caseData)}
            ${CaseDetails.renderLiability(caseData)}
            ${CaseDetails.renderNotes(caseData)}
            ${CaseDetails.renderCommunications(caseData)}
          </div>
        </div>
      </div>
    `;

    modal.classList.add('active');
  },

  /**
   * Renders 🤖 AI Tools section inside Case Details.
   * Launches AI Workspace with linked case context.
   * @param {Object} caseData 
   * @returns {string} HTML string
   */
  renderAITools: (caseData) => {
    return `
      <div class="glass-card p-3" style="border: 1px solid var(--accent-primary);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.75rem;">
          <h4 style="margin:0; display:flex; align-items:center; gap:0.4rem; color:var(--accent-primary);">
            🤖 AI Document Intelligence Tools
          </h4>
          <span class="badge badge-success" style="font-size:0.65rem;">Active</span>
        </div>

        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:0.5rem;">
          <button class="btn btn-sm btn-primary" style="display:flex; align-items:center; justify-content:center; gap:0.4rem;" 
            onclick="CaseDetails.launchAIPropertyDamage('${caseData.id}')">
            🚗 Extract Property Damage
          </button>
          <button class="btn btn-sm btn-outline" style="opacity:0.6; cursor:not-allowed;" disabled title="Coming Soon">
            🏥 Medical Records (Soon)
          </button>
          <button class="btn btn-sm btn-outline" style="opacity:0.6; cursor:not-allowed;" disabled title="Coming Soon">
            🧾 Medical Bills (Soon)
          </button>
          <button class="btn btn-sm btn-outline" style="opacity:0.6; cursor:not-allowed;" disabled title="Coming Soon">
            🚔 Police Report (Soon)
          </button>
        </div>
      </div>
    `;
  },

  /**
   * Launches AI Workspace linked to target Case ID.
   * @param {string} caseId 
   */
  launchAIPropertyDamage: (caseId) => {
    const caseData = window.Storage ? Storage.getCases().find(c => c.id === caseId) : null;
    if (!caseData) return;

    if (window.Modals) Modals.closeAll();
    if (window.App) App.switchTab('tab-ai-workspace');
    if (window.AIWorkspace) {
      AIWorkspace.linkToCase(caseData);
    }
  },

  /**
   * Renders 📄 Case Information section.
   * @param {Object} caseData 
   * @returns {string} HTML string
   */
  renderCaseInfo: (caseData) => {
    return `
      <div class="glass-card p-3">
        <h4 style="margin-bottom:0.75rem; display:flex; align-items:center; gap:0.4rem;">📄 Case Information</h4>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.5rem; font-size:0.88rem;">
          <div><strong>Status:</strong> <span class="badge badge-sm badge-info">${caseData.caseStatus || 'Treating'}</span></div>
          <div><strong>Date of Loss:</strong> ${caseData.dol || 'N/A'}</div>
          <div><strong>Insurance:</strong> ${caseData.insurance || 'Unassigned'}</div>
          <div><strong>Claim Number:</strong> ${caseData.claimNumber || 'N/A'}</div>
          <div><strong>Adjuster:</strong> ${caseData.adjuster || 'N/A'}</div>
          <div><strong>Case Manager:</strong> ${caseData.caseManager || 'Erin Garcia'}</div>
        </div>
      </div>
    `;
  },

  /**
   * Renders 👥 Clients section using ClientHelper methods exclusively.
   * Dispatches client management actions (Add, Edit, Remove, Set Primary) to Cases controller.
   * @param {Object} caseData 
   * @returns {string} HTML string
   */
  renderClients: (caseData) => {
    const clients = ClientHelper.getClients(caseData);
    const hasMultiple = ClientHelper.hasMultipleClients(caseData);

    return `
      <div class="glass-card p-3">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.75rem;">
          <h4 style="margin:0; display:flex; align-items:center; gap:0.4rem;">
            👥 Clients ${hasMultiple ? `<span class="badge badge-sm badge-outline">${clients.length} Clients</span>` : ''}
          </h4>
          <button class="btn btn-xs btn-outline-excel" onclick="Cases.openAddClientModal('${caseData.id}')" title="Add Client">
            ➕ Add Client
          </button>
        </div>

        <div class="client-list" style="display:flex; flex-direction:column; gap:0.5rem;">
          ${clients.length === 0 ? '<p class="text-muted" style="font-size:0.85rem; margin:0;">No clients recorded.</p>' : clients.map(c => `
            <div class="client-item-card p-2 border-radius-sm" style="background:rgba(255,255,255,0.03); border:1px solid var(--glass-border); display:flex; justify-content:space-between; align-items:center;">
              <div>
                <strong style="font-size:0.9rem;">${ClientHelper.formatSingleClient(c)}</strong>
                ${c.isPrimary ? `<span class="badge badge-sm badge-success ml-2" style="font-size:0.72rem;">⭐ Primary</span>` : ''}
              </div>
              <div class="action-btn-group">
                ${!c.isPrimary ? `
                  <button class="btn btn-xs btn-outline" onclick="Cases.setPrimaryClient('${caseData.id}', '${c.id}')" title="Set Primary">⭐ Set Primary</button>
                ` : ''}
                <button class="btn btn-xs btn-outline" onclick="Cases.openEditClientModal('${caseData.id}', '${c.id}')" title="Edit Client">✏️ Edit</button>
                <button class="btn btn-xs btn-outline" onclick="Cases.removeClient('${caseData.id}', '${c.id}')" title="Remove Client">🗑️ Delete</button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  /**
   * Renders 🏥 Treatment section placeholder.
   * @param {Object} caseData 
   * @returns {string} HTML string
   */
  renderTreatment: (caseData) => {
    return `
      <div class="glass-card p-3">
        <h4 style="margin-bottom:0.5rem; display:flex; align-items:center; gap:0.4rem;">🏥 Medical Treatment</h4>
        <p class="text-muted" style="font-size:0.85rem; margin:0;">
          Medical treatment logs & provider tracking (Coming Soon).
        </p>
      </div>
    `;
  },

  /**
   * Renders 📋 Requests section placeholder.
   * Pure placeholder: Zero duplicated request fetching or logic.
   * @param {Object} caseData 
   * @returns {string} HTML string
   */
  renderRequests: (caseData) => {
    return `
      <div class="glass-card p-3">
        <h4 style="margin-bottom:0.5rem; display:flex; align-items:center; gap:0.4rem;">📋 Medical Requests</h4>
        <p class="text-muted" style="font-size:0.85rem; margin:0;">
          Medical/billing request module integration (Coming Soon).
        </p>
      </div>
    `;
  },

  /**
   * Renders 📝 Case Notes section by embedding NotesEngine & CaseSummary.
   * Auto-populates case context (Client Name, DOL, Insurance) when triggering follow-up modal.
   * @param {Object} caseData 
   * @returns {string} HTML string
   */
  renderNotes: (caseData) => {
    const primaryName = window.ClientHelper ? ClientHelper.formatSingleClient(caseData) : (caseData.clientName || 'Client');
    const containerId = `case-workspace-notes-list-${caseData.id}`;
    const escapedName = primaryName.replace(/'/g, "\\'");
    const escapedDOL = (caseData.dol || '').replace(/'/g, "\\'");
    const escapedIns = (caseData.insurance || 'Provider/Insurance').replace(/'/g, "\\'");

    setTimeout(() => {
      if (window.NotesEngine) {
        NotesEngine.renderCaseNotesList(containerId, caseData);
      }
    }, 0);

    return `
      <div class="glass-card p-3">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.75rem;">
          <h4 style="margin:0; display:flex; align-items:center; gap:0.4rem;">📝 Case Notes</h4>
          <button class="btn btn-xs btn-primary" onclick="Modals.openFollowUpModal({ title: 'Follow-Up Note: ${escapedName}', clientName: '${escapedName}', dol: '${escapedDOL}', providerOrIns: '${escapedIns}', onSave: (data) => { NotesEngine.createRichFollowUpNote({ clientName: '${escapedName}', dol: '${escapedDOL}', providerOrIns: '${escapedIns}', contactDate: data.contactDate, medium: data.medium, person: data.person, outcome: data.outcome, nextStep: data.nextStep, notes: data.notes, nextFollowUpDate: Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000)) }); const refreshedCase = Storage.getCases().find(c => c.id === '${caseData.id}'); if (refreshedCase && window.CaseDetails) { CaseDetails.open(refreshedCase); } } })">
            ⚡ Add Follow-Up Note
          </button>
        </div>

        <div id="${containerId}"></div>
      </div>
    `;
  },

  /**
   * Renders 📧 Communications section placeholder.
   * Pure placeholder: Zero email generators or duplicated templates.
   * @param {Object} caseData 
   * @returns {string} HTML string
   */
  renderCommunications: (caseData) => {
    return `
      <div class="glass-card p-3">
        <h4 style="margin-bottom:0.5rem; display:flex; align-items:center; gap:0.4rem;">📧 Communications</h4>
        <p class="text-muted" style="font-size:0.85rem; margin:0;">
          Communications Engine integration (Coming Soon).
        </p>
      </div>
    `;
  },

  /**
   * Renders ⚖ Liability section placeholder.
   * Pure placeholder: Zero duplicated liability logic.
   * @param {Object} caseData 
   * @returns {string} HTML string
   */
  renderLiability: (caseData) => {
    return `
      <div class="glass-card p-3">
        <h4 style="margin-bottom:0.5rem; display:flex; align-items:center; gap:0.4rem;">⚖️ Liability & Claims</h4>
        <p class="text-muted" style="font-size:0.85rem; margin:0;">
          Liability tracking module integration (Coming Soon).
        </p>
      </div>
    `;
  }
};

window.CaseDetails = CaseDetails;
