/**
 * Case Assistant OS - AI Response Parser & Sanitizer
 * Handles robust JSON extraction from LLM outputs, cleans markdown wrappers,
 * validates extracted fields, coerces raw numeric values, and enforces schema null fallbacks.
 */

const AIParser = {
  /**
   * Sanitizes raw string response from LLM by stripping code blocks and whitespace.
   * @param {string} rawText 
   * @returns {string} Clean JSON string candidate
   */
  cleanRawText: (rawText) => {
    if (!rawText || typeof rawText !== 'string') return '';

    let cleaned = rawText.trim();

    // Strip markdown code fence syntax (```json ... ``` or ``` ... ```)
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '');
    cleaned = cleaned.replace(/\s*```$/i, '');

    // Extract first valid JSON object boundaries { ... } if extraneous text surrounds it
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      cleaned = cleaned.substring(firstBrace, lastBrace + 1);
    }

    return cleaned.trim();
  },

  /**
   * Coerces raw string or numeric input into a clean number or null for numeric fields.
   * Strip currency symbols ($), commas, and spaces.
   * @param {*} val 
   * @param {boolean} isFloat - True for decimal numbers (e.g. estimate), false for integers (e.g. mileage, year)
   * @returns {number|null}
   */
  parseNumericValue: (val, isFloat = false) => {
    if (val === null || val === undefined || val === '' || String(val).toLowerCase() === 'null' || String(val).toLowerCase() === 'n/a') {
      return null;
    }
    if (typeof val === 'number' && !isNaN(val)) {
      return isFloat ? parseFloat(val.toFixed(2)) : Math.round(val);
    }
    // Convert string with possible $ or commas to clean number
    const str = String(val).replace(/[^0-9.-]/g, '');
    if (!str) return null;
    const num = isFloat ? parseFloat(str) : parseInt(str, 10);
    return isNaN(num) ? null : (isFloat ? parseFloat(num.toFixed(2)) : num);
  },

  /**
   * Parses raw LLM response text into a validated object matching the target schema.
   * @param {string|Object} rawInput - Raw string from model or already parsed object
   * @param {string} docType - Target schema document type (e.g. 'PROPERTY_DAMAGE')
   * @returns {Object} Cleaned object with all schema fields present (defaulting to null)
   */
  parse: (rawInput, docType = 'PROPERTY_DAMAGE') => {
    const defaultState = window.AISchemas ? AISchemas.createDefault(docType) : {};
    let parsedObj = null;

    if (typeof rawInput === 'object' && rawInput !== null) {
      parsedObj = rawInput;
    } else if (typeof rawInput === 'string') {
      const cleanedText = AIParser.cleanRawText(rawInput);
      try {
        parsedObj = JSON.parse(cleanedText);
      } catch (err) {
        console.error('[AIParser] JSON parsing error:', err, 'Raw input:', rawInput);
      }
    }

    if (!parsedObj || typeof parsedObj !== 'object' || Array.isArray(parsedObj)) {
      console.warn('[AIParser] Failed to extract valid JSON object. Returning default null schema.');
      return defaultState;
    }

    // Merge parsed fields into default null schema to guarantee all keys exist
    const sanitizedResult = { ...defaultState };
    const numericFloatKeys = ['estimate'];
    const numericIntKeys = ['mileage', 'year'];

    Object.keys(defaultState).forEach(key => {
      if (Object.prototype.hasOwnProperty.call(parsedObj, key)) {
        const val = parsedObj[key];
        if (val === null || val === undefined || val === '' || String(val).toLowerCase() === 'null' || String(val).toLowerCase() === 'n/a') {
          sanitizedResult[key] = null;
        } else if (numericFloatKeys.includes(key)) {
          sanitizedResult[key] = AIParser.parseNumericValue(val, true);
        } else if (numericIntKeys.includes(key)) {
          sanitizedResult[key] = AIParser.parseNumericValue(val, false);
        } else {
          sanitizedResult[key] = String(val).trim();
        }
      }
    });

    return sanitizedResult;
  }
};

if (typeof window !== 'undefined') {
  window.AIParser = AIParser;
}
