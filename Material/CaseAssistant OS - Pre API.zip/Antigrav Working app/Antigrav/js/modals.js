/**
 * Case Assistant OS - Centralized Modal Queue Manager & UI Dialogs
 * Manages dynamic custom modal overlays (Alerts, Confirmations, Follow-up forms, End-of-Day summary).
 */

const Modals = {
  /**
   * Closes all active modal dialogs.
   */
  closeAll: () => {
    const container = document.getElementById('custom-modal-container');
    if (container) container.innerHTML = '';
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
  },

  /**
   * Displays a custom alert modal replacing native window.alert.
   * @param {Object} params { title, message, type, okText }
   * @returns {Promise<boolean>}
   */
  alert: ({ title = 'Notificación', message = '', type = 'info', okText = 'Entendido' }) => {
    return new Promise((resolve) => {
      Modals.closeAll();
      const container = document.getElementById('custom-modal-container');
      if (!container) return resolve(true);

      let icon = 'ℹ️';
      if (type === 'success') icon = '✅';
      if (type === 'warning') icon = '⚠️';
      if (type === 'danger') icon = '🚨';

      container.innerHTML = `
        <div class="modal-overlay active">
          <div class="modal-box glass-card modal-sm">
            <div class="modal-header">
              <h3>${icon} ${title}</h3>
              <button class="btn-close" id="modal-close-x">&times;</button>
            </div>
            <div class="modal-body py-3">
              <p style="font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">${message}</p>
            </div>
            <div class="modal-footer" style="display:flex; justify-content:flex-end;">
              <button id="modal-btn-ok" class="btn btn-sm btn-primary">${okText}</button>
            </div>
          </div>
        </div>
      `;

      const close = () => {
        container.innerHTML = '';
        resolve(true);
      };

      const btnOk = document.getElementById('modal-btn-ok');
      const btnX = document.getElementById('modal-close-x');
      if (btnOk) btnOk.onclick = close;
      if (btnX) btnX.onclick = close;
    });
  },

  /**
   * Displays a custom confirmation modal replacing native window.confirm.
   * @param {Object} params { title, message, confirmText, cancelText, isDanger }
   * @returns {Promise<boolean>} Resolves true if confirmed, false if cancelled
   */
  confirm: ({ title = 'Confirmar Acción', message = '¿Estás seguro de continuar?', confirmText = 'Sí, continuar', cancelText = 'Cancelar', isDanger = false }) => {
    return new Promise((resolve) => {
      Modals.closeAll();
      const container = document.getElementById('custom-modal-container');
      if (!container) return resolve(false);

      const confirmBtnClass = isDanger ? 'btn-danger' : 'btn-primary';

      container.innerHTML = `
        <div class="modal-overlay active">
          <div class="modal-box glass-card modal-sm">
            <div class="modal-header">
              <h3>${isDanger ? '⚠️' : '❓'} ${title}</h3>
              <button class="btn-close" id="modal-close-x">&times;</button>
            </div>
            <div class="modal-body py-3">
              <p style="font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">${message}</p>
            </div>
            <div class="modal-footer" style="display:flex; justify-content:flex-end; gap:0.5rem;">
              <button id="modal-btn-cancel" class="btn btn-sm btn-outline">${cancelText}</button>
              <button id="modal-btn-confirm" class="btn btn-sm ${confirmBtnClass}">${confirmText}</button>
            </div>
          </div>
        </div>
      `;

      const cancel = () => { container.innerHTML = ''; resolve(false); };
      const confirm = () => { container.innerHTML = ''; resolve(true); };

      const btnCancel = document.getElementById('modal-btn-cancel');
      const btnX = document.getElementById('modal-close-x');
      const btnConfirm = document.getElementById('modal-btn-confirm');

      if (btnCancel) btnCancel.onclick = cancel;
      if (btnX) btnX.onclick = cancel;
      if (btnConfirm) btnConfirm.onclick = confirm;
    });
  },

  /**
   * Opens the interactive Follow Up modal form.
   * @param {Object} params { title, clientName, dol, providerOrIns, type, onSave }
   */
  openFollowUpModal: ({ title = 'Registrar Follow Up', clientName, dol, providerOrIns, type = 'Request', onSave }) => {
    Modals.closeAll();
    const container = document.getElementById('custom-modal-container');
    if (!container) return;

    const todayStr = Utils.formatDate(new Date());

    container.innerHTML = `
      <div class="modal-overlay active">
        <div class="modal-box glass-card modal-md">
          <div class="modal-header">
            <h3>📞 ${title}</h3>
            <button class="btn-close" id="followup-modal-close">&times;</button>
          </div>
          <div class="modal-body py-3">
            <div class="case-meta-summary mb-3 p-2 border-radius-sm" style="background: rgba(255,255,255,0.04); font-size:0.85rem;">
              <div><strong>Cliente:</strong> ${clientName} (${dol || 'Sin DOL'})</div>
              <div><strong>Provider/Seguro:</strong> ${providerOrIns}</div>
            </div>

            <form id="followup-form" onsubmit="return false;">
              <div class="form-grid-2">
                <div class="form-group mb-2">
                  <label class="form-label">Fecha de Contacto</label>
                  <input type="text" id="fu-date" class="form-control" value="${todayStr}" placeholder="MM/DD/YYYY">
                </div>
                <div class="form-group mb-2">
                  <label class="form-label">Medio Utilizado</label>
                  <select id="fu-medium" class="form-select">
                    <option value="Llamada">Llamada (Phone Call)</option>
                    <option value="Email">Email</option>
                    <option value="Fax">Fax</option>
                    <option value="Portal">Portal Web</option>
                    <option value="Mensaje">Mensaje / Text</option>
                    <option value="Otro">Otro</option>
                  </select>
                </div>
              </div>

              <div class="form-grid-2">
                <div class="form-group mb-2">
                  <label class="form-label">Persona Contactada</label>
                  <input type="text" id="fu-person" class="form-control" placeholder="Ej. Sarah (Records Dept), Adjuster John">
                </div>
                <div class="form-group mb-2">
                  <label class="form-label">Resultado</label>
                  <select id="fu-outcome" class="form-select">
                    <option value="Pending Records/Billing">Pendiente de Envío (Pending)</option>
                    <option value="In Process / Under Review">En Proceso (In Process)</option>
                    <option value="Payment / Fee Required">Requiere Pago (Fee Required)</option>
                    <option value="Completed / Received">Completado / Recibido</option>
                    <option value="Left Voicemail / No Answer">Sin Respuesta / Dejó Vocero</option>
                  </select>
                </div>
              </div>

              <div class="form-group mb-2">
                <label class="form-label">Próximo Paso / Observaciones</label>
                <input type="text" id="fu-nextstep" class="form-control" placeholder="Ej. Prometieron enviar facturas el viernes por Fax">
              </div>

              <div class="form-group mb-2">
                <label class="form-label">Notas Adicionales</label>
                <textarea id="fu-notes" class="form-control" rows="2" placeholder="Detalles o comentarios adicionales..."></textarea>
              </div>

              <div class="form-group mb-2">
                <label class="form-label">Programar Próximo Follow Up (Días)</label>
                <select id="fu-days-next" class="form-select">
                  <option value="5">En 5 días</option>
                  <option value="7" selected>En 7 días</option>
                  <option value="10">En 10 días</option>
                  <option value="14">En 14 días</option>
                  <option value="30">En 30 días</option>
                </select>
              </div>
            </form>
          </div>
          <div class="modal-footer" style="display:flex; justify-content:flex-end; gap:0.5rem;">
            <button id="followup-modal-cancel" class="btn btn-sm btn-outline">Cancelar</button>
            <button id="followup-modal-save" class="btn btn-sm btn-primary">💾 Guardar & Generar Nota</button>
          </div>
        </div>
      </div>
    `;

    const closeModal = () => { container.innerHTML = ''; };

    const btnClose = document.getElementById('followup-modal-close');
    const btnCancel = document.getElementById('followup-modal-cancel');
    const btnSave = document.getElementById('followup-modal-save');

    if (btnClose) btnClose.onclick = closeModal;
    if (btnCancel) btnCancel.onclick = closeModal;

    if (btnSave) {
      btnSave.onclick = () => {
        const fuDateEl = document.getElementById('fu-date');
        const fuMediumEl = document.getElementById('fu-medium');
        const fuPersonEl = document.getElementById('fu-person');
        const fuOutcomeEl = document.getElementById('fu-outcome');
        const fuNextStepEl = document.getElementById('fu-nextstep');
        const fuNotesEl = document.getElementById('fu-notes');
        const fuDaysNextEl = document.getElementById('fu-days-next');

        const contactDate = (fuDateEl ? fuDateEl.value.trim() : '') || todayStr;
        const medium = fuMediumEl ? fuMediumEl.value : 'Llamada';
        const person = (fuPersonEl ? fuPersonEl.value.trim() : '') || 'Staff';
        const outcome = fuOutcomeEl ? fuOutcomeEl.value : 'Pending';
        const nextStep = fuNextStepEl ? fuNextStepEl.value.trim() : '';
        const notes = fuNotesEl ? fuNotesEl.value.trim() : '';
        const daysNext = parseInt(fuDaysNextEl ? fuDaysNextEl.value : '7', 10) || 7;

        closeModal();
        if (onSave) {
          onSave({ contactDate, medium, person, outcome, nextStep, notes, daysNext });
        }
      };
    }
  },

  /**
   * Opens the End of Day Work Summary modal ("Finalizar Jornada").
   */
  openEndOfDayModal: () => {
    Modals.closeAll();
    const container = document.getElementById('custom-modal-container');
    if (!container) return;

    const sessionLogs = Storage.getSessionLogs();
    const todayStr = Utils.formatDate(new Date());

    const followUpsCount = sessionLogs.filter(l => l.action.toLowerCase().includes('follow up') || l.action.toLowerCase().includes('call')).length;
    const requestsCount = sessionLogs.filter(l => l.targetType === 'Requests').length;
    const liabilityCount = sessionLogs.filter(l => l.targetType === 'Liability').length;
    const notesCount = sessionLogs.filter(l => l.targetType === 'Notes').length;
    const importsCount = sessionLogs.filter(l => l.targetType === 'CSV').length;

    const summaryTextLines = [
      `=== RESUMEN DE JORNADA LABORAL - ${todayStr} ===`,
      `Case Assistant OS | KR Law Workspace`,
      ``,
      `• Follow-Ups Registrados: ${followUpsCount}`,
      `• Actividades de Requests: ${requestsCount}`,
      `• Gestiones de Liability: ${liabilityCount}`,
      `• Notas Generadas: ${notesCount}`,
      `• Importaciones CSV: ${importsCount}`,
      `• Total Acciones Realizadas: ${sessionLogs.length}`,
      ``,
      `--- DETALLE DE ACTIVIDAD EN SESIÓN ---`,
      ...sessionLogs.map(l => `[${l.targetType}] ${l.action}: ${l.details}`)
    ];

    const fullSummaryStr = summaryTextLines.join('\n');

    container.innerHTML = `
      <div class="modal-overlay active">
        <div class="modal-box glass-card modal-md">
          <div class="modal-header">
            <h3>🏁 Resumen de la Jornada Laboral</h3>
            <button class="btn-close" id="eod-modal-close">&times;</button>
          </div>
          <div class="modal-body py-3">
            <div class="kpi-grid mb-3">
              <div class="kpi-card glass-card">
                <span class="kpi-title">Follow-Ups</span>
                <span class="kpi-value" style="color:var(--accent-primary)">${followUpsCount}</span>
              </div>
              <div class="kpi-card glass-card">
                <span class="kpi-title">Requests</span>
                <span class="kpi-value" style="color:var(--status-success)">${requestsCount}</span>
              </div>
              <div class="kpi-card glass-card">
                <span class="kpi-title">Notas</span>
                <span class="kpi-value">${notesCount}</span>
              </div>
            </div>

            <div class="form-group mb-3">
              <label class="form-label">Reporte de Actividad del Día</label>
              <textarea id="eod-summary-text" class="form-control" rows="8" readonly style="font-family:monospace; font-size:0.82rem;">${fullSummaryStr}</textarea>
            </div>
          </div>
          <div class="modal-footer" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
            <button id="eod-reset-session" class="btn btn-sm btn-outline-casepeer">🧹 Iniciar Nueva Jornada</button>
            <div style="display:flex; gap:0.5rem;">
              <button id="eod-copy-btn" class="btn btn-sm btn-primary">📋 Copiar Resumen</button>
              <button id="eod-export-btn" class="btn btn-sm btn-outline-excel">📥 Exportar (.txt)</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const closeModal = () => { container.innerHTML = ''; };

    const btnClose = document.getElementById('eod-modal-close');
    const btnCopy = document.getElementById('eod-copy-btn');
    const btnExport = document.getElementById('eod-export-btn');
    const btnReset = document.getElementById('eod-reset-session');

    if (btnClose) btnClose.onclick = closeModal;

    if (btnCopy) {
      btnCopy.onclick = () => {
        Utils.copyToClipboard(fullSummaryStr, 'Resumen de Jornada');
      };
    }

    if (btnExport) {
      btnExport.onclick = () => {
        const blob = new Blob([fullSummaryStr], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Resumen_Jornada_${todayStr.replace(/\//g, '-')}.txt`;
        a.click();
        URL.revokeObjectURL(url);
        Utils.showToast('Resumen exportado a .txt', 'success');
      };
    }

    if (btnReset) {
      btnReset.onclick = async () => {
        const confirmed = await Modals.confirm({
          title: '🧹 Reiniciar Contador de Jornada',
          message: '¿Deseas vaciar el registro de sesión para comenzar un nuevo día de trabajo?',
          confirmText: 'Sí, Reiniciar Sesión'
        });
        if (confirmed) {
          Storage.resetSessionLogs();
          Utils.showToast('Registro de sesión reiniciado para el nuevo día', 'info');
          closeModal();
        }
      };
    }
  },

  /**
   * Opens the interactive Communication Modal.
   * Integrates with CommunicationEngine as a pure UI/presentation layer.
   * All fields are pre-populated from record but fully editable by the user.
   * @param {Object} params { title, templateKey, record }
   */
  openCommunicationModal: ({ title = 'Insurance Follow-Up', templateKey = 'insurance_followup', record = {} }) => {
    Modals.closeAll();
    const container = document.getElementById('custom-modal-container');
    if (!container) return;

    const initialClient = record.clientName || '';
    const initialIns = record.insurance3P || record.insurance1P || record.insuranceCompany || '';
    const initialDol = record.dol || record.dateOfLoss || '';
    const initialAdjuster = record.adjuster || record.adjusterName || '';
    const initialClaim = record.claimNumber || record.claimNo || '';

    container.innerHTML = `
      <div class="modal-overlay active">
        <div class="modal-box glass-card modal-md">
          <div class="modal-header">
            <h3>💬 ${title}</h3>
            <button class="btn-close" id="comm-modal-close">&times;</button>
          </div>
          <div class="modal-body py-3">
            <!-- Editable pre-populated metadata fields -->
            <div class="form-grid-3 mb-3">
              <div class="form-group mb-2">
                <label class="form-label">Client Name</label>
                <input type="text" id="comm-client-name" class="form-control" value="${initialClient.replace(/"/g, '&quot;')}" placeholder="Client Name">
              </div>
              <div class="form-group mb-2">
                <label class="form-label">Insurance Company</label>
                <input type="text" id="comm-insurance-company" class="form-control" value="${initialIns.replace(/"/g, '&quot;')}" placeholder="Insurance Company">
              </div>
              <div class="form-group mb-2">
                <label class="form-label">Date of Loss</label>
                <input type="text" id="comm-date-of-loss" class="form-control" value="${initialDol.replace(/"/g, '&quot;')}" placeholder="MM/DD/YYYY">
              </div>
            </div>

            <!-- Editable pre-populated inputs -->
            <div class="form-grid-2 mb-3">
              <div class="form-group mb-2">
                <label class="form-label">Adjuster Name</label>
                <input type="text" id="comm-adjuster-name" class="form-control" value="${initialAdjuster.replace(/"/g, '&quot;')}" placeholder="Adjuster Name">
              </div>
              <div class="form-group mb-2">
                <label class="form-label">Claim Number</label>
                <input type="text" id="comm-claim-number" class="form-control" value="${initialClaim.replace(/"/g, '&quot;')}" placeholder="Claim Number">
              </div>
            </div>

            <!-- Tone options -->
            <div class="form-group mb-3">
              <label class="form-label">Tone</label>
              <div class="comm-tone-group" style="display:flex; gap:1.25rem; align-items:center; background:rgba(255,255,255,0.03); padding:0.6rem 0.9rem; border-radius:var(--radius-sm); border:1px solid var(--glass-border);">
                <label style="cursor:pointer; display:flex; align-items:center; gap:0.4rem; font-size:0.88rem;">
                  <input type="radio" name="comm-tone" value="friendly"> Friendly
                </label>
                <label style="cursor:pointer; display:flex; align-items:center; gap:0.4rem; font-size:0.88rem;">
                  <input type="radio" name="comm-tone" value="professional" checked> Professional (default)
                </label>
                <label style="cursor:pointer; display:flex; align-items:center; gap:0.4rem; font-size:0.88rem;">
                  <input type="radio" name="comm-tone" value="firm"> Firm
                </label>
              </div>
            </div>

            <!-- Action Button -->
            <div class="mb-3" style="display:flex; justify-content:flex-end;">
              <button id="comm-btn-generate" class="btn btn-sm btn-primary">⚡ Generate</button>
            </div>

            <hr style="border:0; border-top:1px solid var(--glass-border); margin:1rem 0;">

            <!-- Generated Content: Subject -->
            <div class="form-group mb-3">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.35rem;">
                <label class="form-label mb-0">Subject</label>
                <button id="comm-btn-copy-subject" class="btn btn-xs btn-outline">📋 Copy Subject</button>
              </div>
              <input type="text" id="comm-output-subject" class="form-control" readonly style="font-weight:500;">
            </div>

            <!-- Generated Content: Body -->
            <div class="form-group mb-3">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.35rem;">
                <label class="form-label mb-0">Body</label>
                <button id="comm-btn-copy-body" class="btn btn-xs btn-outline">📋 Copy Body</button>
              </div>
              <textarea id="comm-output-body" class="form-control" rows="8" readonly style="font-family:inherit; font-size:0.85rem; line-height:1.5;"></textarea>
            </div>
          </div>

          <div class="modal-footer" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
            <button id="comm-modal-cancel" class="btn btn-sm btn-outline">Cancelar</button>
            <button id="comm-btn-copy-entire" class="btn btn-sm btn-primary">✉️ Copy Entire Email</button>
          </div>
        </div>
      </div>
    `;

    const closeModal = () => { container.innerHTML = ''; };

    const btnClose = document.getElementById('comm-modal-close');
    const btnCancel = document.getElementById('comm-modal-cancel');
    const btnGenerate = document.getElementById('comm-btn-generate');
    const btnCopySubject = document.getElementById('comm-btn-copy-subject');
    const btnCopyBody = document.getElementById('comm-btn-copy-body');
    const btnCopyEntire = document.getElementById('comm-btn-copy-entire');

    const clientInput = document.getElementById('comm-client-name');
    const insuranceInput = document.getElementById('comm-insurance-company');
    const dolInput = document.getElementById('comm-date-of-loss');
    const adjusterInput = document.getElementById('comm-adjuster-name');
    const claimInput = document.getElementById('comm-claim-number');
    const subjectOutput = document.getElementById('comm-output-subject');
    const bodyOutput = document.getElementById('comm-output-body');

    const generateCommunication = () => {
      const selectedToneEl = document.querySelector('input[name="comm-tone"]:checked');
      const tone = selectedToneEl ? selectedToneEl.value : 'professional';

      const clientNameVal = clientInput ? clientInput.value.trim() : '';
      const insuranceVal = insuranceInput ? insuranceInput.value.trim() : '';
      const dolVal = dolInput ? dolInput.value.trim() : '';
      const adjNameVal = adjusterInput ? adjusterInput.value.trim() : '';
      const claimNoVal = claimInput ? claimInput.value.trim() : '';

      const daysPending = record.lastContactDate ? Utils.daysElapsedSince(record.lastContactDate) : (record.daysPending || null);
      const activeMgr = window.Storage ? Storage.getActiveCaseManager() : 'ALL';
      const caseManager = (activeMgr && activeMgr !== 'ALL') ? activeMgr : (record.caseManager || 'Case Assistant');

      const caseData = {
        clientName: clientNameVal,
        insuranceCompany: insuranceVal,
        dateOfLoss: dolVal,
        adjusterName: adjNameVal,
        claimNumber: claimNoVal,
        policyNumber: record.policyNumber || record.policyNo || '',
        pendingItem: 'Liability status',
        daysPending: daysPending,
        caseManager: caseManager
      };

      try {
        const result = CommunicationEngine.generate(templateKey, caseData, { tone: tone });
        if (subjectOutput) subjectOutput.value = result.subject || '';
        if (bodyOutput) bodyOutput.value = result.body || '';
      } catch (err) {
        console.error('Error generating communication via CommunicationEngine:', err);
        Utils.showToast('Error generating communication: ' + err.message, 'danger');
      }
    };

    if (btnClose) btnClose.onclick = closeModal;
    if (btnCancel) btnCancel.onclick = closeModal;
    if (btnGenerate) btnGenerate.onclick = generateCommunication;

    // Auto-update on tone change
    const toneRadios = container.querySelectorAll('input[name="comm-tone"]');
    toneRadios.forEach(radio => radio.addEventListener('change', generateCommunication));

    if (btnCopySubject) {
      btnCopySubject.onclick = () => {
        const subj = subjectOutput ? subjectOutput.value : '';
        if (subj) Utils.copyToClipboard(subj, 'Subject');
      };
    }

    if (btnCopyBody) {
      btnCopyBody.onclick = () => {
        const bodyText = bodyOutput ? bodyOutput.value : '';
        if (bodyText) Utils.copyToClipboard(bodyText, 'Body');
      };
    }

    if (btnCopyEntire) {
      btnCopyEntire.onclick = () => {
        const subj = subjectOutput ? subjectOutput.value : '';
        const bodyText = bodyOutput ? bodyOutput.value : '';
        const entireEmail = `Subject: ${subj}\n\n${bodyText}`;
        Utils.copyToClipboard(entireEmail, 'Entire Email');
      };
    }

    // Trigger initial generation on modal load
    generateCommunication();
  },

  /**
   * Opens the interactive Client Form modal (Add / Edit Client).
   * @param {Object} params { title, client, onSave }
   */
  openClientFormModal: ({ title = 'Client Details', client = {}, onSave }) => {
    Modals.closeAll();
    const container = document.getElementById('custom-modal-container');
    if (!container) return;

    const initialFirstName = (client.firstName || '').replace(/"/g, '&quot;');
    const initialLastName = (client.lastName || '').replace(/"/g, '&quot;');
    const initialIsPrimary = Boolean(client.isPrimary);

    container.innerHTML = `
      <div class="modal-overlay active">
        <div class="modal-box glass-card modal-sm">
          <div class="modal-header">
            <h3>👤 ${title}</h3>
            <button class="btn-close" id="client-modal-close">&times;</button>
          </div>
          <div class="modal-body py-3">
            <form id="client-form" onsubmit="return false;">
              <div class="form-group mb-3">
                <label class="form-label">First Name <span class="text-danger">*</span></label>
                <input type="text" id="client-first-name" class="form-control" value="${initialFirstName}" placeholder="e.g. William" required>
              </div>

              <div class="form-group mb-3">
                <label class="form-label">Last Name <span class="text-danger">*</span></label>
                <input type="text" id="client-last-name" class="form-control" value="${initialLastName}" placeholder="e.g. Atkins" required>
              </div>

              <div class="form-group mb-3">
                <label style="cursor:pointer; display:flex; align-items:center; gap:0.5rem; font-size:0.88rem;">
                  <input type="checkbox" id="client-is-primary" ${initialIsPrimary ? 'checked' : ''}>
                  ⭐ Set as Primary Client
                </label>
              </div>
            </form>
          </div>
          <div class="modal-footer" style="display:flex; justify-content:flex-end; gap:0.5rem;">
            <button id="client-modal-cancel" class="btn btn-sm btn-outline">Cancelar</button>
            <button id="client-modal-save" class="btn btn-sm btn-primary">💾 Guardar Cliente</button>
          </div>
        </div>
      </div>
    `;

    const closeModal = () => { container.innerHTML = ''; };

    const btnClose = document.getElementById('client-modal-close');
    const btnCancel = document.getElementById('client-modal-cancel');
    const btnSave = document.getElementById('client-modal-save');

    if (btnClose) btnClose.onclick = closeModal;
    if (btnCancel) btnCancel.onclick = closeModal;

    if (btnSave) {
      btnSave.onclick = () => {
        const firstNameEl = document.getElementById('client-first-name');
        const lastNameEl = document.getElementById('client-last-name');
        const isPrimaryEl = document.getElementById('client-is-primary');

        const firstName = firstNameEl ? firstNameEl.value.trim() : '';
        const lastName = lastNameEl ? lastNameEl.value.trim() : '';
        const isPrimary = isPrimaryEl ? isPrimaryEl.checked : false;

        if (!firstName && !lastName) {
          Utils.showToast('Please enter at least First Name or Last Name', 'warning');
          return;
        }

        closeModal();
        if (onSave) {
          onSave({ firstName, lastName, isPrimary });
        }
      };
    }
  }
};

window.Modals = Modals;
