/**
 * Case Assistant v1.5 - Medical Records & Billing Requests Controller
 */

const Requests = {
  activeSearch: '',
  activeProviderFilter: '',
  activeStatusFilter: '',
  activeTypeFilter: '',
  activeAgingFilter: '',

  init: () => {
    Requests.renderRequestsTable();
    Requests.setupFilters();
  },

  setupFilters: () => {
    const searchInput = document.getElementById('req-search-input');
    const providerSelect = document.getElementById('req-filter-provider');
    const statusSelect = document.getElementById('req-filter-status');
    const typeSelect = document.getElementById('req-filter-type');
    const agingSelect = document.getElementById('req-filter-aging');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        Requests.activeSearch = e.target.value.toLowerCase().trim();
        Requests.renderRequestsTable();
      });
    }

    if (providerSelect) {
      providerSelect.addEventListener('change', (e) => {
        Requests.activeProviderFilter = e.target.value;
        Requests.renderRequestsTable();
      });
    }

    if (statusSelect) {
      statusSelect.addEventListener('change', (e) => {
        Requests.activeStatusFilter = e.target.value.toLowerCase();
        Requests.renderRequestsTable();
      });
    }

    if (typeSelect) {
      typeSelect.addEventListener('change', (e) => {
        Requests.activeTypeFilter = e.target.value.toLowerCase();
        Requests.renderRequestsTable();
      });
    }

    if (agingSelect) {
      agingSelect.addEventListener('change', (e) => {
        Requests.activeAgingFilter = e.target.value;
        Requests.renderRequestsTable();
      });
    }
  },

  // Render Requests Table with Multi-criteria Filtering
  renderRequestsTable: () => {
    const container = document.getElementById('requests-table-body');
    if (!container) return;

    let reqs = Storage.getRequests();

    // Populate Provider dropdown
    const providerSelect = document.getElementById('req-filter-provider');
    if (providerSelect && providerSelect.options.length <= 1) {
      const providers = Array.from(new Set(reqs.map(r => r.provider).filter(Boolean))).sort();
      providers.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p;
        opt.textContent = p;
        providerSelect.appendChild(opt);
      });
    }

    // Apply Multi-criteria Filters
    if (Requests.activeSearch) {
      const q = Requests.activeSearch;
      reqs = reqs.filter(r => 
        (r.clientName || '').toLowerCase().includes(q) ||
        (r.provider || '').toLowerCase().includes(q) ||
        (r.dol || '').toLowerCase().includes(q) ||
        (r.status || '').toLowerCase().includes(q) ||
        (r.requestType || '').toLowerCase().includes(q) ||
        (r.caseManager || r.leadAttorney || '').toLowerCase().includes(q)
      );
    }

    if (Requests.activeProviderFilter) {
      reqs = reqs.filter(r => r.provider === Requests.activeProviderFilter);
    }

    if (Requests.activeStatusFilter) {
      reqs = reqs.filter(r => (r.status || '').toLowerCase() === Requests.activeStatusFilter);
    }

    if (Requests.activeTypeFilter) {
      reqs = reqs.filter(r => (r.requestType || '').toLowerCase().includes(Requests.activeTypeFilter));
    }

    if (Requests.activeAgingFilter) {
      reqs = reqs.filter(r => {
        const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
        return aging.level === Requests.activeAgingFilter;
      });
    }

    if (reqs.length === 0) {
      container.innerHTML = `
        <tr>
          <td colspan="8" class="text-center text-muted py-4">
            No se encontraron solicitudes médicas con los criterios seleccionados.
          </td>
        </tr>
      `;
      return;
    }

    container.innerHTML = reqs.map(r => {
      const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);

      return `
        <tr id="req-row-${r.id}">
          <td>
            <strong>${r.clientName}</strong>
            <div style="font-size:0.75rem; color:var(--text-muted)">DOL: ${r.dol || 'N/A'}</div>
          </td>
          <td>🏥 <strong>${r.provider}</strong></td>
          <td><span class="badge badge-info">${r.requestType || 'Billing & Records'}</span></td>
          <td>
            <select class="form-select-sm status-select" onchange="Requests.updateStatus('${r.id}', this.value)">
              <option value="Requested" ${r.status === 'Requested' ? 'selected' : ''}>Requested</option>
              <option value="Pending" ${r.status === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Follow Up Needed" ${r.status === 'Follow Up Needed' ? 'selected' : ''}>Follow Up Needed</option>
              <option value="Received" ${r.status === 'Received' ? 'selected' : ''}>Received</option>
              <option value="Closed" ${r.status === 'Closed' ? 'selected' : ''}>Closed</option>
            </select>
          </td>
          <td>${r.initialRequestDate || r.requestDate || '-'}</td>
          <td>
            <span class="badge ${aging.badgeClass}">${aging.label}</span>
            <div style="font-size:0.75rem; color:var(--text-muted)">Próx: ${r.nextFollowUpDate || r.nextFollowUp || 'No programado'}</div>
          </td>
          <td>
            <div style="font-size:0.8rem; max-width:180px;" title="${r.notes || ''}">
              ${r.notes ? r.notes.substring(0, 35) + '...' : '<span class="text-muted">Sin notas</span>'}
            </div>
          </td>
          <td>
            <div class="action-btn-group">
              <button class="btn btn-xs btn-primary" onclick="Requests.openRegisterFollowUpModal('${r.id}')" title="Registrar Follow Up">📞 Follow Up</button>
              <button class="btn btn-xs btn-success" onclick="Requests.quickMarkReceived('${r.id}')" title="Marcar Recibido">✅ Recibido</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  // Update Status Dropdown
  updateStatus: (reqId, newStatus) => {
    const reqs = Storage.getRequests();
    const r = reqs.find(item => item.id === reqId);
    if (!r) return;

    r.status = newStatus;
    if (newStatus === 'Received' || newStatus === 'Closed') {
      r.lastContactDate = Utils.formatDate(new Date());
    }
    Storage.saveRequest(r);

    const noteText = `Updated request status to ${newStatus}.`;
    NotesEngine.createNote(r.clientName, r.dol, noteText);
    Storage.addActivityLog('Request Status Updated', `${r.clientName} - ${r.provider}: Estado cambiado a ${newStatus}`, 'Requests');
    Utils.showToast(`Estado de solicitud cambiado a ${newStatus}`, 'success');

    Dashboard.init();
  },

  // Open "Registrar Follow Up" Custom Modal
  openRegisterFollowUpModal: (reqId) => {
    const reqs = Storage.getRequests();
    const r = reqs.find(item => item.id === reqId);
    if (!r) return;

    Modals.openFollowUpModal({
      title: 'Registrar Follow Up de Request',
      clientName: r.clientName,
      dol: r.dol,
      providerOrIns: `${r.provider} (${r.requestType})`,
      type: 'Request',
      onSave: (data) => {
        const nextDate = Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000));
        
        r.lastContactDate = data.contactDate;
        r.lastFollowUpDate = data.contactDate;
        r.nextFollowUpDate = nextDate;
        r.status = data.outcome.includes('Received') ? 'Received' : 'Pending';
        
        const summary = `[${data.medium}] ${data.outcome}. ${data.nextStep || ''}`.trim();
        r.notes = (r.notes ? r.notes + '\n' : '') + summary;
        
        Storage.saveRequest(r);

        // Generate Rich Dual Notes
        NotesEngine.createRichFollowUpNote({
          clientName: r.clientName,
          dol: r.dol,
          providerOrIns: `${r.provider} (${r.requestType})`,
          contactDate: data.contactDate,
          medium: data.medium,
          person: data.person,
          outcome: data.outcome,
          nextStep: data.nextStep,
          notes: data.notes,
          nextFollowUpDate: nextDate
        });

        Storage.addActivityLog('Follow Up Registered', `${r.clientName} - ${r.provider}: Follow up registrado.`, 'Requests');
        Utils.showToast('Follow-Up registrado y notas creadas en el portapapeles!', 'success');

        Requests.renderRequestsTable();
        Dashboard.init();
      }
    });
  },

  // 1-Click Quick Mark Received
  quickMarkReceived: (reqId) => {
    const reqs = Storage.getRequests();
    const r = reqs.find(item => item.id === reqId);
    if (!r) return;

    r.status = 'Received';
    r.lastContactDate = Utils.formatDate(new Date());
    r.notes = (r.notes ? r.notes + '\n' : '') + `Received ${r.requestType} from ${r.provider}.`;
    Storage.saveRequest(r);

    const noteText = `Received ${r.requestType} from provider ${r.provider}. Completed.`;
    NotesEngine.createNote(r.clientName, r.dol, noteText);
    Storage.addActivityLog('Records Received', `${r.clientName} - ${r.provider}: Solicitud recibida.`, 'Requests');
    Utils.showToast(`¡Solicitud marcada como Recibida!`, 'success');

    Requests.renderRequestsTable();
    Dashboard.init();
  }
};

window.Requests = Requests;
