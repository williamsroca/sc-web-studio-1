/**
 * Case Assistant OS - Master Application Controller
 * Handles application lifecycle initialization, tab routing, global case manager filtering,
 * keyboard shortcuts, theme toggling, global search modal, and activity feed rendering.
 */

const App = {
  /**
   * Application Entry Point.
   */
  init: async () => {
    console.log('Initializing Case Assistant OS...');

    await CSVImporter.seedLocalFilesIfEmpty();

    App.setupTabs();
    App.setupGlobalManagerSelector();
    App.setupKeyboardShortcuts();

    IntegrationManager.init();
    if (window.AIManager) AIManager.init();
    if (window.AIWorkspace) AIWorkspace.init();

    Dashboard.init();
    Cases.init();
    Requests.init();
    Liability.init();
    Settings.init();
    NotesEngine.renderNotesDrawer();
    App.renderActivityTab();
  },

  // ==========================================
  // GLOBAL CASE MANAGER DROPDOWN SELECTOR
  // ==========================================

  setupGlobalManagerSelector: () => {
    const selector = document.getElementById('global-active-manager');
    if (!selector) return;

    const currentManager = Storage.getActiveCaseManager();
    
    const cases = Storage.getCases();
    const reqs = Storage.getRequests();
    const liab = Storage.getLiabilityItems();
    const allManagers = Array.from(new Set([
      ...cases.map(c => c.caseManager || c.attorney || c.primary),
      ...reqs.map(r => r.caseManager || r.leadAttorney),
      ...liab.map(l => l.caseManager || l.leadAttorney)
    ].filter(Boolean))).sort();

    selector.innerHTML = `<option value="ALL">All Case Managers</option>`;
    allManagers.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m;
      opt.textContent = m;
      if (m.toLowerCase() === currentManager.toLowerCase()) opt.selected = true;
      selector.appendChild(opt);
    });
  },

  handleGlobalManagerChange: (managerValue) => {
    Storage.setActiveCaseManager(managerValue);
    Utils.showToast(`Active global filter: ${managerValue === 'ALL' ? 'All Case Managers' : managerValue}`, 'info');

    Dashboard.init();
    Cases.renderSummaryHeader();
    Cases.renderCasesTable();
    Requests.renderSummaryHeader();
    Requests.renderRequestsTable();
    Liability.renderSummaryHeader();
    Liability.renderLiabilityTable();
  },

  // ==========================================
  // TAB NAVIGATION & ROUTING
  // ==========================================

  setupTabs: () => {
    const navItems = document.querySelectorAll('.nav-item');
    const tabContents = document.querySelectorAll('.tab-content');

    navItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const tabId = item.getAttribute('data-tab');

        navItems.forEach(n => n.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));

        item.classList.add('active');
        const activeTab = document.getElementById(tabId);
        if (activeTab) {
          activeTab.classList.add('active');
        }

        if (tabId === 'tab-dashboard') Dashboard.init();
        if (tabId === 'tab-cases') Cases.init();
        if (tabId === 'tab-requests') Requests.init();
        if (tabId === 'tab-liability') Liability.init();
        if (tabId === 'tab-ai-workspace' && window.AIWorkspace) AIWorkspace.init();
        if (tabId === 'tab-settings') Settings.renderStats();
        if (tabId === 'tab-activity') App.renderActivityTab();
      });
    });
  },

  switchTab: (tabId) => {
    const navItem = document.querySelector(`.nav-item[data-tab="${tabId}"]`);
    if (navItem) navItem.click();
  },

  // ==========================================
  // KEYBOARD SHORTCUTS & THEME TOGGLE
  // ==========================================

  setupKeyboardShortcuts: () => {
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        Modals.closeAll();
      }

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        App.openGlobalSearch();
      }

      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
        return;
      }

      const key = e.key.toLowerCase();
      if (key === 'n') {
        e.preventDefault();
        App.quickCreateNoteModal();
      } else if (key === 'd') {
        App.switchTab('tab-dashboard');
      } else if (key === 'c') {
        App.switchTab('tab-cases');
      } else if (key === 'r') {
        App.switchTab('tab-requests');
      } else if (key === 'l') {
        App.switchTab('tab-liability');
      }
    });
  },

  toggleTheme: () => {
    const html = document.documentElement;
    const current = html.getAttribute('data-theme');
    const next = current === 'light' ? 'dark' : 'light';
    html.setAttribute('data-theme', next);
    Utils.showToast(`Theme switched to ${next} mode`, 'info');
  },

  // ==========================================
  // CSV IMPORT & QUICK NOTE MODAL TRIGGERS
  // ==========================================

  openImportModal: () => {
    document.getElementById('csv-import-modal')?.classList.add('active');
  },

  handleCSVFileUpload: (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const modeSelect = document.getElementById('csv-import-mode');
    const importMode = modeSelect ? modeSelect.value : 'merge';

    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target.result;
      CSVImporter.importCSVText(text, file.name, false, importMode);
      document.getElementById('csv-import-modal')?.classList.remove('active');
      
      App.setupGlobalManagerSelector();
      Dashboard.init();
      Cases.init();
      Requests.init();
      Liability.init();
      App.renderActivityTab();
    };
    reader.readAsText(file);
  },

  quickCreateNoteModal: () => {
    Modals.openFollowUpModal({
      title: 'Generate Quick Note / Follow Up',
      clientName: 'Quick Client',
      dol: Utils.formatDate(new Date()),
      providerOrIns: 'Provider/Insurance',
      onSave: (data) => {
        NotesEngine.createRichFollowUpNote({
          clientName: 'Quick Note',
          dol: Utils.formatDate(new Date()),
          providerOrIns: 'Case',
          contactDate: data.contactDate,
          medium: data.medium,
          person: data.person,
          outcome: data.outcome,
          nextStep: data.nextStep,
          notes: data.notes,
          nextFollowUpDate: Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000))
        });
        Utils.showToast('Note generated in slide-out drawer!', 'success');
      }
    });
  },

  // ==========================================
  // GLOBAL SEARCH MODAL (Ctrl+K)
  // ==========================================

  openGlobalSearch: () => {
    const modal = document.getElementById('global-search-modal');
    const input = document.getElementById('global-search-input');
    const resultsContainer = document.getElementById('global-search-results');

    if (!modal || !input || !resultsContainer) return;
    modal.classList.add('active');
    input.value = '';
    input.focus();

    input.oninput = () => {
      const q = input.value.toLowerCase().trim();
      if (!q) {
        resultsContainer.innerHTML = '';
        return;
      }

      const cases = Storage.getCases().filter(c => 
        (c.clientName || '').toLowerCase().includes(q) ||
        (c.insurance || '').toLowerCase().includes(q) ||
        (c.claimNumber || '').toLowerCase().includes(q)
      );

      const reqs = Storage.getRequests().filter(r => 
        (r.clientName || '').toLowerCase().includes(q) ||
        (r.provider || '').toLowerCase().includes(q)
      );

      const liab = Storage.getLiabilityItems().filter(l => 
        (l.clientName || '').toLowerCase().includes(q) ||
        (l.insurance3P || '').toLowerCase().includes(q)
      );

      resultsContainer.innerHTML = `
        <div style="display:flex; flex-direction:column; gap:0.5rem; max-height:400px; overflow-y:auto;">
          ${cases.map(c => `
            <div class="priority-item glass-card" style="cursor:pointer;" onclick="document.getElementById('global-search-modal').classList.remove('active'); Cases.openCaseDetails('${c.id}');">
              <div class="priority-item-header">
                <strong>📁 Case: ${c.clientName}</strong>
                <span class="badge badge-info">DOL: ${c.dol}</span>
              </div>
              <div class="priority-item-sub">Insurance: ${c.insurance || 'Pending'} | Status: ${c.caseStatus}</div>
            </div>
          `).join('')}

          ${reqs.map(r => `
            <div class="priority-item glass-card" style="cursor:pointer;" onclick="document.getElementById('global-search-modal').classList.remove('active'); App.switchTab('tab-requests');">
              <div class="priority-item-header">
                <strong>🏥 Request: ${r.provider}</strong>
                <span class="badge badge-warning">${r.status}</span>
              </div>
              <div class="priority-item-sub">Client: ${r.clientName} (${r.requestType})</div>
            </div>
          `).join('')}

          ${liab.map(l => `
            <div class="priority-item glass-card" style="cursor:pointer;" onclick="document.getElementById('global-search-modal').classList.remove('active'); App.switchTab('tab-liability');">
              <div class="priority-item-header">
                <strong>🛡️ Liability: ${l.insurance3P || 'Pending'}</strong>
                <span class="badge badge-success">${l.liabilityStatus}</span>
              </div>
              <div class="priority-item-sub">Client: ${l.clientName}</div>
            </div>
          `).join('')}

          ${cases.length === 0 && reqs.length === 0 && liab.length === 0 ? '<p class="text-muted p-2">No matching records found.</p>' : ''}
        </div>
      `;
    };
  },

  // ==========================================
  // ACTIVITY & IMPORT LOGS TAB
  // ==========================================

  renderActivityTab: () => {
    const importContainer = document.getElementById('import-history-list');
    const activityContainer = document.getElementById('activity-full-list');

    if (importContainer) {
      const history = Storage.getImportHistory();
      if (history.length === 0) {
        importContainer.innerHTML = '<p class="text-muted">No manual imports performed yet.</p>';
      } else {
        importContainer.innerHTML = history.map(h => `
          <div class="priority-item glass-card mb-2">
            <div class="priority-item-header">
              <strong>📥 ${h.fileName}</strong>
              <span class="text-muted" style="font-size:0.78rem">${Utils.getRelativeTimeString(h.timestamp)}</span>
            </div>
            <div class="priority-item-sub">
              Added: <strong>${h.addedCount || 0}</strong> | Updated: <strong>${h.updatedCount || 0}</strong> | Notes Kept: <strong>${h.preservedNotesCount || 0}</strong>
            </div>
          </div>
        `).join('');
      }
    }

    if (activityContainer) {
      const logs = Storage.getActivityLogs();
      if (logs.length === 0) {
        activityContainer.innerHTML = '<p class="text-muted">No logs recorded.</p>';
      } else {
        activityContainer.innerHTML = logs.map(l => `
          <div class="activity-item">
            <span class="activity-dot"></span>
            <div class="activity-content">
              <div class="activity-title"><strong>[${l.targetType}] ${l.action}</strong> <small class="text-muted">(${Utils.getRelativeTimeString(l.timestamp)})</small></div>
              <div class="activity-desc">${l.details}</div>
            </div>
          </div>
        `).join('');
      }
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

window.App = App;
