/**
 * Case Assistant v1.6.0 - Outlook / Microsoft 365 Email Verification Placeholder
 */

const OutlookIntegration = {
  // Check sent emails by Erin to detect if a follow-up email was sent
  checkSentEmailsForRequest: async (clientName, providerName) => {
    console.log(`[Outlook Email Verification] Checking sent emails for ${clientName} to ${providerName}...`);
    
    // Architecture ready: returns simulation status
    return {
      emailSent: false,
      lastSentDate: null,
      subject: null,
      providerReplied: false,
      verificationStatus: 'Pendiente de Email'
    };
  },

  // Log sent email manually or via Webhook
  registerSentEmail: (reqId, emailSubject, sentDate = new Date()) => {
    const reqs = Storage.getRequests();
    const r = reqs.find(item => item.id === reqId);
    if (!r) return null;

    r.lastEmailSentDate = Utils.formatDate(sentDate);
    r.lastEmailSubject = emailSubject;
    r.emailVerificationStatus = 'Verificado';
    Storage.saveRequest(r);

    Storage.addActivityLog('Email Verified', `Email de seguimiento verificado para ${r.clientName} (${r.provider})`, 'Integrations');
    return r;
  }
};

window.OutlookIntegration = OutlookIntegration;
