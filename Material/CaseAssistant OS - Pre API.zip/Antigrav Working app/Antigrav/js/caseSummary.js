/**
 * Case Assistant OS - Case Summary Utility
 * Reusable, standalone module for formatting and copying case summary data.
 * Independent from DOM & Storage; accepts direct inputs and delegates clipboard copy.
 */

const CaseSummary = {
  /**
   * Formats Client Name + DOL for Excel Cell 1 on a single line.
   * Format:
   * LastName, FirstName - DOL MM/DD/YYYY
   * 
   * @param {string} clientName 
   * @param {string} dol 
   * @returns {string}
   */
  formatNameAndDOL: (clientName, dol) => {
    const cleanName = (clientName || '').trim();
    const cleanDOL = (dol || '').trim();

    if (cleanName && cleanDOL) {
      return `${cleanName} - DOL ${cleanDOL}`;
    }
    if (cleanName) {
      return `${cleanName} - DOL`;
    }
    if (cleanDOL) {
      return `DOL ${cleanDOL}`;
    }
    return '';
  },

  /**
   * Formats Case Note for Excel Cell 2.
   * Flattens note into a single line by replacing line breaks with spaces,
   * collapsing multiple consecutive spaces, and trimming whitespace.
   * 
   * @param {string} noteText 
   * @returns {string}
   */
  formatNote: (noteText) => {
    if (!noteText) return '';
    return noteText
      .replace(/[\r\n]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  },

  /**
   * Copies formatted Name + DOL to system clipboard.
   * 
   * @param {string} clientName 
   * @param {string} dol 
   * @returns {Promise<boolean>}
   */
  copyNameAndDOL: (clientName, dol) => {
    const formatted = CaseSummary.formatNameAndDOL(clientName, dol);
    return Utils.copyToClipboard(formatted, 'Name + DOL');
  },

  /**
   * Copies formatted Note text to system clipboard.
   * 
   * @param {string} noteText 
   * @returns {Promise<boolean>}
   */
  copyNote: (noteText) => {
    const formatted = CaseSummary.formatNote(noteText);
    return Utils.copyToClipboard(formatted, 'Note');
  }
};

window.CaseSummary = CaseSummary;
