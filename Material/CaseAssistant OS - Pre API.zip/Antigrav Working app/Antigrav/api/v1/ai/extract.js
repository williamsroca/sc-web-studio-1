/**
 * Case Assistant OS - AI Extraction Serverless Proxy Endpoint
 * Route: POST /api/v1/ai/extract
 * Validates request payloads, injects secret GEMINI_API_KEY, calls Gemini Flash REST API,
 * processes multi-file uploads, executes Package Merger algorithm, and returns standard envelope.
 */

const Validator = require('../../lib/validator');
const GeminiClient = require('../../lib/gemini');
const Merger = require('../../lib/merger');

/**
 * Creates standardized JSON error response object.
 */
function createErrorResponse(statusCode, code, message, details = {}) {
  return {
    status: 'error',
    statusCode: statusCode,
    requestId: 'req_err_' + Math.random().toString(36).substr(2, 9),
    timestamp: new Date().toISOString(),
    error: {
      code: code,
      message: message,
      details: details
    }
  };
}

/**
 * Core Request Processor compatible with Node.js HTTP req/res (Express/Connect/Hostinger/Vercel/Netlify).
 */
async function handleExtractRequest(req, res) {
  const startTime = Date.now();

  // 1. Enforce CORS Headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-App-Token');

  // Handle OPTIONS preflight request
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }

  // 2. Enforce HTTP Method
  if (req.method !== 'POST') {
    res.statusCode = 405;
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify(createErrorResponse(405, 'METHOD_NOT_ALLOWED', 'Only HTTP POST requests are supported.')));
  }

  // Parse Body if string
  let body = req.body;
  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch (err) {
      res.statusCode = 400;
      res.setHeader('Content-Type', 'application/json');
      return res.end(JSON.stringify(createErrorResponse(400, 'INVALID_JSON_BODY', 'Failed to parse request JSON body.')));
    }
  }

  // 3. Request Validation
  const validation = Validator.validateRequest(body);
  if (!validation.isValid) {
    const errObj = validation.error;
    res.statusCode = errObj.statusCode;
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify(createErrorResponse(errObj.statusCode, errObj.code, errObj.message, errObj.details)));
  }

  const { documentType, files } = body;

  try {
    const processedDocuments = [];

    // 4. Process each uploaded file sequentially
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const fileId = f.id || `file_${i + 1}_${Date.now()}`;
      const fileName = f.fileName || `document_${i + 1}.pdf`;

      // Prompt for extraction
      const prompt = `You are a legal document data extraction assistant. Analyze this document and extract the following 14 fields as raw JSON (raw numbers for estimate/mileage/year, null for missing fields):
{
  "insurance": "Insurance company name or null",
  "owner": "Vehicle owner full name or null",
  "year": 2022 (raw integer year or null),
  "make": "Vehicle make or null",
  "model": "Vehicle model or null",
  "color": "Vehicle color or null",
  "plate": "License plate number or null",
  "vin": "17-character VIN number or null",
  "mileage": 45210 (raw integer mileage or null),
  "claimNumber": "Insurance claim number or null",
  "policyNumber": "Insurance policy number or null",
  "bodyShop": "Repair shop name or null",
  "estimate": 5582.19 (raw decimal repair total without $ or commas, or null),
  "notes": "Concise summary of damages or null"
}`;

      // Call Gemini API via server client
      const result = await GeminiClient.extractDocument({
        prompt,
        base64Data: f.base64Data,
        mimeType: f.mimeType
      });

      processedDocuments.push({
        fileId: fileId,
        fileName: fileName,
        documentType: documentType === 'AUTO_DETECT' ? 'PROPERTY_DAMAGE' : documentType,
        status: 'success',
        extractedData: result.parsedData || {}
      });
    }

    // 5. Execute Package Merger Algorithm for multi-file package
    const mergedData = Merger.mergePackage(processedDocuments);

    // 6. Return Standard Success Envelope
    const totalProcessingTimeMs = Date.now() - startTime;

    const responseEnvelope = {
      status: 'success',
      statusCode: 200,
      requestId: 'req_' + Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      processingTimeMs: totalProcessingTimeMs,
      providerUsed: {
        name: 'gemini',
        model: GeminiClient.MODEL_NAME
      },
      documents: processedDocuments,
      mergedData: mergedData
    };

    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify(responseEnvelope));

  } catch (err) {
    console.error('[AI Extract Proxy Error]:', err);
    const statusCode = err.statusCode || 500;
    const errorCode = err.code || 'PROXY_INTERNAL_ERROR';

    res.statusCode = statusCode;
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify(createErrorResponse(statusCode, errorCode, err.message || 'An internal error occurred during document extraction.')));
  }
}

module.exports = handleExtractRequest;
