/**
 * Case Assistant OS - AI Provider Abstract Base Class / Interface
 * Defines the contract that all AI provider adapters (Gemini, Claude, OpenAI, Local) must implement.
 */

class AIProvider {
  /**
   * @param {string} providerName - Unique identifier for the provider (e.g. 'gemini', 'claude')
   */
  constructor(providerName = 'abstract') {
    this.name = providerName;
  }

  /**
   * Abstract method for executing document data extraction.
   * Must be overridden by provider implementations.
   * @param {Object} options
   * @param {Object} options.filePayload - Container for base64 file data, mimeType, and fileName
   * @param {string} options.prompt - Complete extraction prompt text
   * @param {string} options.docType - Document type identifier
   * @returns {Promise<string|Object>} Raw output string or parsed JSON object from model/proxy
   */
  async executeExtraction({ filePayload, prompt, docType }) {
    throw new Error(`[AIProvider] Method 'executeExtraction' not implemented in provider '${this.name}'.`);
  }
}

if (typeof window !== 'undefined') {
  window.AIProvider = AIProvider;
}
