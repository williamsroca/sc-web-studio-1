/**
 * Case Assistant v1.5 - Utility Functions & Aging Calculator
 */

const Utils = {
  // Generate Unique ID
  generateId: () => {
    return 'id_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
  },

  // Format Date to MM/DD/YYYY
  formatDate: (dateInput) => {
    if (!dateInput) return '';
    const date = new Date(dateInput);
    if (isNaN(date.getTime())) return String(dateInput);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  },

  // Parse MM/DD/YYYY or YYYY-MM-DD to Date object
  parseDate: (str) => {
    if (!str) return null;
    str = String(str).trim();
    if (str.includes('/')) {
      const parts = str.split('/');
      if (parts.length === 3) {
        let m = parseInt(parts[0], 10) - 1;
        let d = parseInt(parts[1], 10);
        let y = parseInt(parts[2], 10);
        if (y < 100) y += 2000;
        return new Date(y, m, d);
      }
    }
    const d = new Date(str);
    return isNaN(d.getTime()) ? null : d;
  },

  // Days Difference from Today (positive = past, negative = future)
  daysElapsedSince: (dateStr) => {
    const target = Utils.parseDate(dateStr);
    if (!target) return null;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    target.setHours(0, 0, 0, 0);
    const diffTime = today - target;
    return Math.floor(diffTime / (1000 * 60 * 60 * 24));
  },

  // Days difference to target date
  daysFromToday: (dateStr) => {
    const target = Utils.parseDate(dateStr);
    if (!target) return 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    target.setHours(0, 0, 0, 0);
    const diffTime = target - today;
    return Math.round(diffTime / (1000 * 60 * 60 * 24));
  },

  // Compare two date strings: returns true if dateA is newer (or equal) to dateB
  isNewerDate: (dateAStr, dateBStr) => {
    const dateA = Utils.parseDate(dateAStr);
    const dateB = Utils.parseDate(dateBStr);
    if (!dateA && !dateB) return false;
    if (dateA && !dateB) return true;
    if (!dateA && dateB) return false;
    return dateA.getTime() >= dateB.getTime();
  },

  /**
   * AUTOMATED AGING LOGIC FOR REQUESTS & FOLLOW-UPS
   * 0 - 14 days:  Green (Al día / On Track)
   * 15 - 19 days: Yellow (Primer recordatorio / 15d)
   * 20 - 29 days: Orange (Prioridad alta / 20d)
   * 30+ days:     Red (Overdue / 30+d)
   */
  calculateRequestAging: (lastContactDateStr, requestDateStr, statusStr) => {
    const s = (statusStr || '').toLowerCase();
    if (s === 'received' || s === 'closed' || s === 'complete') {
      return {
        days: 0,
        level: 'completed',
        label: 'Completado',
        color: '#10b981',
        bg: 'rgba(16, 185, 129, 0.15)',
        badgeClass: 'badge-success'
      };
    }

    const refDateStr = lastContactDateStr || requestDateStr;
    if (!refDateStr) {
      return {
        days: 999,
        level: 'unknown',
        label: 'Fecha desconocida / Revisar',
        color: '#ef4444',
        bg: 'rgba(239, 68, 68, 0.18)',
        badgeClass: 'badge-danger'
      };
    }

    const days = Utils.daysElapsedSince(refDateStr);

    if (days === null) {
      return {
        days: 999,
        level: 'unknown',
        label: 'Fecha desconocida',
        color: '#ef4444',
        bg: 'rgba(239, 68, 68, 0.18)',
        badgeClass: 'badge-danger'
      };
    }

    if (days >= 30) {
      return {
        days,
        level: 'overdue',
        label: `${days}d - Overdue (30+d)`,
        color: '#ef4444',
        bg: 'rgba(239, 68, 68, 0.2)',
        badgeClass: 'badge-danger'
      };
    }

    if (days >= 20) {
      return {
        days,
        level: 'high_priority',
        label: `${days}d - Prioridad Alta (20d)`,
        color: '#f97316',
        bg: 'rgba(249, 115, 22, 0.2)',
        badgeClass: 'badge-orange'
      };
    }

    if (days >= 15) {
      return {
        days,
        level: 'reminder',
        label: `${days}d - 1er Recordatorio (15d)`,
        color: '#f59e0b',
        bg: 'rgba(245, 158, 11, 0.2)',
        badgeClass: 'badge-warning'
      };
    }

    return {
      days,
      level: 'on_track',
      label: `${days}d - Al día`,
      color: '#10b981',
      bg: 'rgba(16, 185, 129, 0.15)',
      badgeClass: 'badge-success'
    };
  },

  // Relative Time String
  getRelativeTimeString: (dateStr) => {
    const days = Utils.daysFromToday(dateStr);
    if (days === 0) return 'Hoy';
    if (days === 1) return 'Mañana';
    if (days === -1) return 'Ayer';
    if (days < 0) return `Hace ${Math.abs(days)} días`;
    return `En ${days} días`;
  },

  // Toast Notification Manager
  showToast: (message, type = 'info', duration = 3500) => {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type} glass-card`;
    
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    if (type === 'warning') icon = '⚠️';
    if (type === 'danger') icon = '🚨';

    toast.innerHTML = `
      <span class="toast-icon">${icon}</span>
      <span class="toast-message">${message}</span>
      <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    `;

    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },

  // Copy text to clipboard
  copyToClipboard: async (text, label = 'Contenido') => {
    try {
      await navigator.clipboard.writeText(text);
      Utils.showToast(`${label} copiado al portapapeles!`, 'success');
      return true;
    } catch (err) {
      console.error('Failed to copy: ', err);
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      Utils.showToast(`${label} copiado!`, 'success');
      return true;
    }
  },

  // Robust CSV Line Parser
  parseCSV: (csvText) => {
    const lines = [];
    let currentLine = [];
    let currentCell = '';
    let insideQuotes = false;

    for (let i = 0; i < csvText.length; i++) {
      const char = csvText[i];
      const nextChar = csvText[i + 1];

      if (char === '"') {
        if (insideQuotes && nextChar === '"') {
          currentCell += '"';
          i++;
        } else {
          insideQuotes = !insideQuotes;
        }
      } else if (char === ',' && !insideQuotes) {
        currentLine.push(currentCell.trim());
        currentCell = '';
      } else if ((char === '\r' || char === '\n') && !insideQuotes) {
        if (char === '\r' && nextChar === '\n') i++;
        currentLine.push(currentCell.trim());
        if (currentLine.some(cell => cell.length > 0)) {
          lines.push(currentLine);
        }
        currentLine = [];
        currentCell = '';
      } else {
        currentCell += char;
      }
    }
    if (currentCell.length > 0 || currentLine.length > 0) {
      currentLine.push(currentCell.trim());
      lines.push(currentLine);
    }
    return lines;
  },

  // Standardize Client Name and DOL extraction
  extractClientAndDOL: (rawCaseStr) => {
    if (!rawCaseStr) return { clientName: '', dol: '', raw: '' };
    const clean = rawCaseStr.trim();
    const parts = clean.split(' - ');
    if (parts.length >= 2) {
      const clientName = parts[0].replace(/"/g, '').trim();
      let dolPart = parts[1].replace(/"/g, '').trim();
      if (dolPart.toLowerCase().startsWith('dol ')) {
        dolPart = dolPart.substring(4).trim();
      }
      const dolMatch = dolPart.match(/\d{2}\/\d{2}\/\d{4}/);
      const dol = dolMatch ? dolMatch[0] : dolPart.split(' ')[0];
      return { clientName, dol, raw: clean };
    }
    return { clientName: clean, dol: '', raw: clean };
  }
};

window.Utils = Utils;
