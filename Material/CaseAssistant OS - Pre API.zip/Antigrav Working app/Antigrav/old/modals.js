/**
 * Case Assistant v1.5 - Custom Modal UI Manager
 * Eliminates native browser dialogs (alert, confirm, prompt)
 */

const Modals = {
  // Custom Alert Modal
  alert: ({ title = 'Notificación', message = '', type = 'info', okText = 'Entendido' }) => {
    return new Promise((resolve) => {
      const container = document.getElementById('custom-modal-container');
      if (!container) return resolve();

      let icon = 'ℹ️';
      if (type === 'success') icon = '✅';
      if (type === 'warning') icon = '⚠️';
      if (type === 'danger') icon = '🚨';

      container.innerHTML = `
        <div class="modal-overlay active">
          <div class="modal-box glass-card modal-sm">
            <div class="modal-header">
              <h3>${icon} ${title}</h3>
            </div>
            <div class="modal-body py-3">
              <p style="font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">${message}</p>
            </div>
            <div class="modal-footer" style="display:flex; justify-content:flex-end;">
              <button id="modal-btn-ok" class="btn btn-sm btn-primary">${okText}</button>
            </div>
          </div>
        </div>
      `;

      document.getElementById('modal-btn-ok').onclick = () => {
        container.innerHTML = '';
        resolve(true);
      };
    });
  },

  // Custom Confirmation Modal
  confirm: ({ title = 'Confirmar Acción', message = '¿Estás seguro de continuar?', confirmText = 'Sí, continuar', cancelText = 'Cancelar', isDanger = false }) => {
    return new Promise((resolve) => {
      const container = document.getElementById('custom-modal-container');
      if (!container) return resolve(false);

      const confirmBtnClass = isDanger ? 'btn-danger' : 'btn-primary';

      container.innerHTML = `
        <div class="modal-overlay active">
          <div class="modal-box glass-card modal-sm">
            <div class="modal-header">
              <h3>${isDanger ? '⚠️' : '❓'} ${title}</h3>
            </div>
            <div class="modal-body py-3">
              <p style="font-size: 0.95rem; color: var(--text-main); line-height: 1.5;">${message}</p>
            </div>
            <div class="modal-footer" style="display:flex; justify-content:flex-end; gap:0.5rem;">
              <button id="modal-btn-cancel" class="btn btn-sm btn-outline">${cancelText}</button>
              <button id="modal-btn-confirm" class="btn btn-sm ${confirmBtnClass}">${confirmText}</button>
            </div>
          </div>
        </div>
      `;

      document.getElementById('modal-btn-cancel').onclick = () => {
        container.innerHTML = '';
        resolve(false);
      };

      document.getElementById('modal-btn-confirm').onclick = () => {
        container.innerHTML = '';
        resolve(true);
      };
    });
  },

  // Open "Registrar Follow Up" Dedicated Form Modal
  openFollowUpModal: ({ title = 'Registrar Follow Up', clientName, dol, providerOrIns, type = 'Request', onSave }) => {
    const container = document.getElementById('custom-modal-container');
    if (!container) return;

    const todayStr = Utils.formatDate(new Date());

    container.innerHTML = `
      <div class="modal-overlay active">
        <div class="modal-box glass-card modal-md">
          <div class="modal-header">
            <h3>📞 ${title}</h3>
            <button class="btn-close" id="followup-modal-close">&times;</button>
          </div>
          <div class="modal-body py-3">
            <div class="case-meta-summary mb-3 p-2 border-radius-sm" style="background: rgba(255,255,255,0.04); font-size:0.85rem;">
              <div><strong>Cliente:</strong> ${clientName} (${dol || 'Sin DOL'})</div>
              <div><strong>Provider/Seguro:</strong> ${providerOrIns}</div>
            </div>

            <form id="followup-form" onsubmit="return false;">
              <div class="form-grid-2">
                <div class="form-group mb-2">
                  <label class="form-label">Fecha de Contacto</label>
                  <input type="text" id="fu-date" class="form-control" value="${todayStr}" placeholder="MM/DD/YYYY">
                </div>
                <div class="form-group mb-2">
                  <label class="form-label">Medio Utilizado</label>
                  <select id="fu-medium" class="form-select">
                    <option value="Llamada">Llamada (Phone Call)</option>
                    <option value="Email">Email</option>
                    <option value="Fax">Fax</option>
                    <option value="Portal">Portal Web</option>
                    <option value="Mensaje">Mensaje / Text</option>
                    <option value="Otro">Otro</option>
                  </select>
                </div>
              </div>

              <div class="form-grid-2">
                <div class="form-group mb-2">
                  <label class="form-label">Persona Contactada</label>
                  <input type="text" id="fu-person" class="form-control" placeholder="Ej. Sarah (Records Dept), Adjuster John">
                </div>
                <div class="form-group mb-2">
                  <label class="form-label">Resultado</label>
                  <select id="fu-outcome" class="form-select">
                    <option value="Pending Records/Billing">Pendiente de Envío (Pending)</option>
                    <option value="In Process / Under Review">En Proceso (In Process)</option>
                    <option value="Payment / Fee Required">Requiere Pago (Fee Required)</option>
                    <option value="Completed / Received">Completado / Recibido</option>
                    <option value="Left Voicemail / No Answer">Sin Respuesta / Dejó Vocero</option>
                  </select>
                </div>
              </div>

              <div class="form-group mb-2">
                <label class="form-label">Próximo Paso / Observaciones</label>
                <input type="text" id="fu-nextstep" class="form-control" placeholder="Ej. Prometieron enviar facturas el viernes por Fax">
              </div>

              <div class="form-group mb-2">
                <label class="form-label">Notas Adicionales</label>
                <textarea id="fu-notes" class="form-control" rows="2" placeholder="Detalles o comentarios adicionales..."></textarea>
              </div>

              <div class="form-group mb-2">
                <label class="form-label">Programar Próximo Follow Up (Días)</label>
                <select id="fu-days-next" class="form-select">
                  <option value="5">En 5 días</option>
                  <option value="7" selected>En 7 días</option>
                  <option value="10">En 10 días</option>
                  <option value="14">En 14 días</option>
                  <option value="30">En 30 días</option>
                </select>
              </div>
            </form>
          </div>
          <div class="modal-footer" style="display:flex; justify-content:flex-end; gap:0.5rem;">
            <button id="followup-modal-cancel" class="btn btn-sm btn-outline">Cancelar</button>
            <button id="followup-modal-save" class="btn btn-sm btn-primary">💾 Guardar & Generar Nota</button>
          </div>
        </div>
      </div>
    `;

    const closeModal = () => { container.innerHTML = ''; };

    document.getElementById('followup-modal-close').onclick = closeModal;
    document.getElementById('followup-modal-cancel').onclick = closeModal;

    document.getElementById('followup-modal-save').onclick = () => {
      const contactDate = document.getElementById('fu-date').value.trim() || todayStr;
      const medium = document.getElementById('fu-medium').value;
      const person = document.getElementById('fu-person').value.trim() || 'Staff';
      const outcome = document.getElementById('fu-outcome').value;
      const nextStep = document.getElementById('fu-nextstep').value.trim();
      const notes = document.getElementById('fu-notes').value.trim();
      const daysNext = parseInt(document.getElementById('fu-days-next').value, 10) || 7;

      closeModal();
      if (onSave) {
        onSave({ contactDate, medium, person, outcome, nextStep, notes, daysNext });
      }
    };
  }
};

window.Modals = Modals;
