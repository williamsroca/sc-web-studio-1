# Case Assistant OS — Release Process & Checklist

This document details the step-by-step release checklist and Git execution commands for publishing releases of **Case Assistant OS**.

---

## Pre-Release Verification Checklist

Before creating a release, complete and verify every item below:

- [ ] **Feature Verification**: All new sprint features and helper methods function as expected.
- [ ] **Console Audit**: Browser developer tools console shows 0 uncaught errors or warnings.
- [ ] **Backward Compatibility**: Legacy single-client cases and CSV files load and display correctly without data loss.
- [ ] **Copy & Note Workflows**: `Copy Excel`, `Copy Name + DOL`, and `Copy Note` paste correctly into single Excel cells.
- [ ] **Modal Audits**: Modals open/close cleanly without stack overlays or backdrop freezes.
- [ ] **Version File Alignment**: `VERSION.md` contains the target release version string (e.g. `1.7.0`).
- [ ] **Changelog Alignment**: `CHANGELOG.md` includes structured release notes under `## [X.Y.Z] - YYYY-MM-DD`.

---

## Release Command Execution Steps

Execute the following commands sequentially from the terminal:

### 1. Check Working Tree Status
```bash
git status
```
Ensure all modified and untracked files are accounted for.

### 2. Stage & Commit Changes
```bash
git add .
git commit -m "release: v1.7.0 - Multi-Client Foundation & Project Documentation"
```

### 3. Push Development Branch
```bash
git push origin refactor
```

### 4. Merge into Production (`main`)
```bash
git checkout main
git pull origin main
git merge refactor
```

### 5. Tag Release
```bash
git tag -a v1.7.0 -m "Release v1.7.0 - Multi-Client Foundation & Project Documentation"
git push origin main
git push origin v1.7.0
```

### 6. Create GitHub Release
1. Navigate to the GitHub repository **Releases** tab.
2. Select **Draft a new release**.
3. Choose tag `v1.7.0`.
4. Copy-paste release notes from `CHANGELOG.md`.
5. Click **Publish release**.
