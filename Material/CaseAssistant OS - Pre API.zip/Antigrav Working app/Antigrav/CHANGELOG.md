# Changelog - Case Assistant

All notable changes to **Case Assistant** will be documented in this file using [Semantic Versioning](https://semver.org/).

---

## [1.7.4] - 2026-07-29

### Added
- **Notes Workspace Migration (`CaseDetails.renderNotes`)**: Embedded the existing `NotesEngine` and `CaseSummary` modules directly into the Case Details Workspace with zero duplicated business logic.
- **Auto-Populated Case Context**: Automatically populates `clientName`, `dol`, and `providerOrIns` from `caseData` when generating follow-up notes inside Case Details.
- **Embedded Note Cards & Copy Actions**: Rendered contextual note history cards with single-cell Excel copy actions (`📋 Copy Excel`, `📋 Copy Name + DOL`, `📋 Copy Note`) inside Case Details.

---

## [1.7.3] - 2026-07-29

### Added
- **Client Management UI (`Modals.openClientFormModal`)**: Interactive glassmorphic modal dialog allowing Case Managers to Add, Edit, Remove, and Set Primary clients dynamically inside the Case Details workspace.
- **Controller Action Dispatcher (`Cases.handleClientAction`)**: Centralized action dispatcher delegating array operations to `ClientHelper`, persisting to `Storage`, and refreshing both Case Details and Cases portfolio table views in real-time.
- **Client Cards UI Enhancements**: Rendered co-client action buttons (`➕ Add Client`, `✏ Edit`, `🗑 Delete`, `⭐ Set Primary`) with primary client badges (`⭐ Primary`).

---

## [1.7.2] - 2026-07-29

### Changed
- **Decoupled `CaseDetails` from `Storage`**: Converted `CaseDetails` into a pure View controller (`CaseDetails.open(caseData)`). `CaseDetails` accepts pre-fetched `caseData` and zero direct `Storage` calls exist within `caseDetails.js`.
- **Eliminated Technical Debt & Duplicate Logic**: Removed temporary duplicate textareas, duplicate save buttons, and duplicate email generator buttons from `CaseDetails`. Sections now render clean, standardized component placeholders ready for composer integration in v1.7.3.

---

## [1.7.1] - 2026-07-29

### Added
- **Case Details Foundation (`js/caseDetails.js`)**: Dedicated, modular controller (`window.CaseDetails`) establishing the central workspace for every case.
- **Modular Section Hooks**: Extensible section render functions (`renderCaseInfo`, `renderClients`, `renderTreatment`, `renderRequests`, `renderNotes`, `renderCommunications`, `renderLiability`).
- **Clients Section Integration**: Leveraged `ClientHelper` for multi-client rendering, primary client badges (`⭐ Primary`), and UI placeholders (`➕ Add Client`, `✏ Edit`, `🗑 Remove`, `⭐ Set Primary`).

---

## [1.7.0] - 2026-07-29

### Added
- **Multi-Client Foundation (`js/clientHelper.js`)**: Decoupled, independent helper utility (`window.ClientHelper`) providing robust data management for cases with 0, 1, or multiple clients, while preserving 100% backward compatibility for legacy single-client cases.
- **Project Documentation Suite (`README.md`, `docs/`)**: Professional documentation suite including root `README.md` and detailed architectural guides in `docs/`:
  - `docs/Architecture.md`: Detailed module responsibilities & interaction maps.
  - `docs/GitWorkflow.md`: Branching, testing, and Git workflow procedures.
  - `docs/Roadmap.md`: Release history and future sprint roadmap (`v1.7.1` - `v1.7.3`).
  - `docs/ReleaseProcess.md`: Release verification checklist & step-by-step release commands.

---

## [1.6.6] - 2026-07-29

### Added
- **Case Summary Optimizer Utility (`js/caseSummary.js`)**: Decoupled, independent module responsible for generating single-line Excel cell ready text.
- **Single-Line Excel Cell Copy Buttons**: Integrated `📋 Copy Name + DOL` (`LastName, FirstName - DOL MM/DD/YYYY`) and `📋 Copy Note` (flattens notes into single-line text without newlines or extra spaces for single Excel cell pasting).

### Changed
- **Notes Module UI**: Removed `📋 Copy CasePeer` button to streamline actions for Excel workflows (`Copy Excel`, `Copy Name + DOL`, `Copy Note`).

---

## [1.6.0] - 2026-07-22

### Added
- **Global Active Case Manager Selector**: Topbar switcher that filters the entire application state (Dashboard KPIs, priority panels, charts, cases, requests, liability).
- **End of Day Summary ("Finalizar Jornada")**: Modal report summarizing session activity (follow-ups, requests updated, notes generated) with 1-click clipboard copy, `.txt` export, and session reset.
- **API Integration Architecture (`js/integrations/`)**: Modular architecture with placeholders for Google Calendar, Outlook/Microsoft 365, Gmail, and CasePeer APIs.
- **Automated Email Verification Placeholder (`outlook.js`)**: Architecture to detect Erin's sent follow-up emails and suppress duplicate task alerts.
- **Centralized Modal Queue Manager (`js/modals.js`)**: Single-responsibility focus manager preventing stacked/overlapping dialogs.
- **Version Tracking**: `VERSION.md` and `CHANGELOG.md` files.

### Changed
- **Full Dark Mode Contrast Audit**: High-contrast `<option>` backgrounds (`#161b22`) and crisp text (`#f0f6fc`) across all form elements, selects, and datalists.
- **Project Structure**: Organized legacy files into `old/` subfolder.

---

## [1.5.1] - 2026-07-22

### Added
- Case Manager filter dropdown in Requests module.
- High-contrast dropdown styling for Dark Mode.

---

## [1.5.0] - 2026-07-22

### Added
- Automated Request Aging Calculator (15/20/30 days thresholds).
- Custom Glassmorphic Modal Framework eliminating native browser dialogs (`alert`, `confirm`, `prompt`).
- Portable Desktop Launcher (`start_app.bat`).
- Linear/Notion corporate visual aesthetic.
- Rich CasePeer & Excel Dual Note auto-generator.
- Non-degrading CSV date merging engine.
- Settings tab with JSON backup export/import and danger zone data wipe.

---

## [1.0.0] - 2026-07-22

### Initial Release
- Personal workspace dashboard for KR Law Case Assistants.
- Glassmorphism design system.
- Initial CSV seeding (`Erin's Case List - Liability Pending.csv`, `MedicalRequestsReport.csv`, `MyCasesReport.csv`).
- Canvas chart visualization.
