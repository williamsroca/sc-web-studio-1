/**
 * Case Assistant OS - Document Extractor Engine
 * Reads native File objects (single or multiple), constructs file payloads, interacts with AI Providers,
 * and handles structured JSON response envelopes (documents[] and mergedData).
 */

const AIExtractor = {
  /**
   * Helper utility to convert a DOM File object into a Base64 payload.
   * @param {File} file - Native browser File object
   * @returns {Promise<{ base64Data: string, mimeType: string, fileName: string, sizeBytes: number }>}
   */
  readFileAsBase64: (file) => {
    return new Promise((resolve, reject) => {
      if (!file) return reject(new Error('[AIExtractor] No file provided for reading.'));

      const reader = new FileReader();

      reader.onload = () => {
        const dataUrl = reader.result;
        const base64Parts = dataUrl.split(',');
        const base64Data = base64Parts[1] || '';
        const mimeType = file.type || 'application/pdf';

        resolve({
          id: `file_${Math.random().toString(36).substr(2, 7)}_${Date.now()}`,
          base64Data,
          mimeType,
          fileName: file.name,
          sizeBytes: file.size || Math.ceil((base64Data.length * 3) / 4)
        });
      };

      reader.onerror = (err) => {
        reject(new Error(`[AIExtractor] Failed to read file '${file.name}': ${err}`));
      };

      reader.readAsDataURL(file);
    });
  },

  /**
   * Main generic extraction handler supporting single or multiple files.
   * @param {File|Array<File>} filesInput - Single DOM File or Array of File objects
   * @param {string} docType - Target document classification (e.g. 'PROPERTY_DAMAGE')
   * @param {AIProvider} provider - Configured AIProvider instance
   * @returns {Promise<Object>} Object containing { documents: [], mergedData: {} }
   */
  extractDocument: async (filesInput, docType = 'PROPERTY_DAMAGE', provider) => {
    if (!filesInput) {
      throw new Error('[AIExtractor] File or files array argument is required.');
    }
    if (!provider) {
      throw new Error('[AIExtractor] Active AI Provider is required.');
    }

    const files = Array.isArray(filesInput) ? filesInput : [filesInput];
    if (files.length === 0) {
      throw new Error('[AIExtractor] At least one file must be provided.');
    }

    console.log(`[AIExtractor] Processing ${files.length} document(s) for type '${docType}' using provider '${provider.name}'...`);

    // Step 1: Read all files to Base64 payloads
    const filePayloads = await Promise.all(files.map(f => AIExtractor.readFileAsBase64(f)));

    // Step 2: Retrieve prompt for document type
    const prompt = window.AIPromptTemplates ? AIPromptTemplates.getPrompt(docType) : '';

    // Step 3: Execute extraction via Provider
    const responseEnvelope = await provider.executeExtraction({
      filePayload: filePayloads,
      prompt,
      docType
    });

    console.log(`[AIExtractor] Extraction complete for ${files.length} document(s):`, responseEnvelope);

    return responseEnvelope;
  },

  /**
   * Specialized Extractor wrapper for Property Damage estimates / packages.
   * @param {File|Array<File>} files 
   * @param {AIProvider} provider 
   * @returns {Promise<Object>} Response envelope containing documents[] and mergedData
   */
  extractPropertyDamage: async (files, provider) => {
    return AIExtractor.extractDocument(files, 'PROPERTY_DAMAGE', provider);
  }
};

if (typeof window !== 'undefined') {
  window.AIExtractor = AIExtractor;
}
