/**
 * Case Assistant OS - Dashboard & Priority Hub Controller
 * Manages KPI metrics calculation, daily progress bar, priority action panels, and HTML Canvas charts.
 * Supports Global Active Case Manager filtering & Interactive KPI Card Navigation.
 */

const Dashboard = {
  /**
   * Initializes or refreshes all dashboard views and sets up click navigation on KPI cards.
   */
  init: () => {
    Dashboard.renderKPIs();
    Dashboard.renderPanels();
    Dashboard.renderCharts();
    Dashboard.setupKpiNavigation();
  },

  /**
   * Filters an array of items by the currently selected Global Active Case Manager.
   * Delegates directly to Utils.filterByActiveCaseManager (Single Source of Truth).
   * @param {Array} items
   * @returns {Array}
   */
  filterByActiveManager: (items) => {
    return Utils.filterByActiveCaseManager(items);
  },

  // ==========================================
  // KPI METRICS CALCULATION (SINGLE SOURCE OF TRUTH)
  // ==========================================

  renderKPIs: () => {
    const allCases = Storage.getCases();
    const allRequests = Storage.getRequests();
    const allLiability = Storage.getLiabilityItems();

    const cases = Dashboard.filterByActiveManager(allCases);
    const requests = Dashboard.filterByActiveManager(allRequests);
    const liability = Dashboard.filterByActiveManager(allLiability);

    const totalCases = cases.length;
    const activeCases = cases.filter(c => (c.caseStatus || '').toLowerCase() === 'treating' || (c.caseStatus || '').toLowerCase() === 'intake').length;
    
    const totalRequests = requests.length;
    let openRequests = 0;
    let completedRequests = 0;
    let overdue30d = 0;
    let highPriority20d = 0;
    let reminder15d = 0;

    requests.forEach(r => {
      const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
      if (aging.level === 'completed') {
        completedRequests++;
      } else {
        openRequests++;
        if (aging.level === 'overdue' || aging.level === 'unknown') overdue30d++;
        if (aging.level === 'high_priority') highPriority20d++;
        if (aging.level === 'reminder') reminder15d++;
      }
    });

    const uniqueProviders = new Set(requests.map(r => r.provider).filter(Boolean)).size;

    // Single Source of Truth for Liability Metrics (Reusing Liability.getMetrics)
    const liabMetrics = window.Liability && typeof window.Liability.getMetrics === 'function' ? 
      window.Liability.getMetrics(liability) : { pending: 0, accepted: 0 };

    const liabPending = liabMetrics.pending;
    const liabAccepted = liabMetrics.accepted;

    const inactiveCases = cases.filter(c => {
      if (!c.lastTouched) return true;
      const days = Utils.daysElapsedSince(c.lastTouched);
      return days === null || days > 14;
    }).length;

    const progressPct = totalRequests > 0 ? Math.round((completedRequests / totalRequests) * 100) : 0;

    const setVal = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setVal('kpi-total-cases', totalCases);
    setVal('kpi-active-cases', activeCases);
    setVal('kpi-total-requests', totalRequests);
    setVal('kpi-open-requests', openRequests);
    setVal('kpi-completed-requests', completedRequests);
    setVal('kpi-providers-count', uniqueProviders);
    setVal('kpi-liability-pending', liabPending);
    setVal('kpi-liability-accepted', liabAccepted);
    setVal('kpi-overdue-followups', overdue30d);
    setVal('kpi-high-priority', highPriority20d + reminder15d);
    setVal('kpi-inactive-cases', inactiveCases);

    const progressBar = document.getElementById('daily-progress-bar');
    if (progressBar) progressBar.style.width = `${progressPct}%`;
    setVal('daily-progress-text', `${progressPct}% completed (${completedRequests}/${totalRequests} requests)`);
  },

  // ==========================================
  // INTERACTIVE KPI CARD NAVIGATION
  // ==========================================

  setupKpiNavigation: () => {
    const kpiCards = document.querySelectorAll('.kpi-card');
    kpiCards.forEach(card => {
      card.style.cursor = 'pointer';
    });

    const bindKpi = (elementId, tabId, filterFn) => {
      const el = document.getElementById(elementId);
      if (!el) return;
      const card = el.closest('.kpi-card');
      if (card) {
        card.onclick = () => {
          App.switchTab(tabId);
          if (filterFn) filterFn();
        };
      }
    };

    bindKpi('kpi-total-cases', 'tab-cases', () => Cases.setFilterStatus(''));
    bindKpi('kpi-active-cases', 'tab-cases', () => Cases.setFilterStatus('treating'));
    bindKpi('kpi-total-requests', 'tab-requests', () => Requests.setFilterStatus(''));
    bindKpi('kpi-open-requests', 'tab-requests', () => Requests.setFilterStatus('pending'));
    bindKpi('kpi-completed-requests', 'tab-requests', () => Requests.setFilterStatus('received'));
    bindKpi('kpi-liability-pending', 'tab-liability', () => Liability.setFilterStatus('pending'));
    bindKpi('kpi-liability-accepted', 'tab-liability', () => Liability.setFilterStatus('accepted'));
    bindKpi('kpi-overdue-followups', 'tab-requests', () => Requests.setFilterAging('overdue'));
    bindKpi('kpi-providers-count', 'tab-requests', () => Requests.setFilterProvider(''));
  },

  // ==========================================
  // ACTION PANELS RENDERING
  // ==========================================

  renderPanels: () => {
    const requests = Dashboard.filterByActiveManager(Storage.getRequests());
    const liability = Dashboard.filterByActiveManager(Storage.getLiabilityItems());
    const activity = Storage.getActivityLogs();

    // 1. Follow-Up Required Today Panel
    const todayList = document.getElementById('panel-today-list');
    if (todayList) {
      const dueItems = requests.filter(r => {
        const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
        if (aging.level === 'completed') return false;
        return aging.days >= 15 || (r.nextFollowUpDate && Utils.daysFromToday(r.nextFollowUpDate) <= 0);
      }).sort((a, b) => {
        const agingA = Utils.calculateRequestAging(a.lastContactDate, a.initialRequestDate, a.status);
        const agingB = Utils.calculateRequestAging(b.lastContactDate, b.initialRequestDate, b.status);
        return agingB.days - agingA.days;
      }).slice(0, 6);

      if (dueItems.length === 0) {
        todayList.innerHTML = `<div class="empty-state-sm">🎉 Excellent! No pending requests require follow-up today.</div>`;
      } else {
        todayList.innerHTML = dueItems.map(r => {
          const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
          return `
            <div class="priority-item glass-card">
              <div class="priority-item-header">
                <strong>${r.clientName}</strong>
                <span class="badge ${aging.badgeClass}">${aging.label}</span>
              </div>
              <div class="priority-item-sub">
                🏥 <strong>${r.provider}</strong> (${r.requestType}) | CM: ${r.caseManager || r.leadAttorney || 'Erin Garcia'}
              </div>
              <div class="priority-item-actions mt-1">
                <button class="btn btn-xs btn-primary" onclick="Requests.openRegisterFollowUpModal('${r.id}')">📞 Register Follow-Up</button>
                <button class="btn btn-xs btn-success" onclick="Requests.quickMarkReceived('${r.id}')">✅ Received</button>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // 2. Overdue Requests Panel (30+ Days)
    const overdueList = document.getElementById('panel-overdue-list');
    if (overdueList) {
      const overdueItems = requests.filter(r => {
        const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
        return aging.level === 'overdue' || aging.level === 'unknown';
      }).slice(0, 5);

      if (overdueItems.length === 0) {
        overdueList.innerHTML = `<div class="empty-state-sm">✨ Zero overdue requests > 30 days.</div>`;
      } else {
        overdueList.innerHTML = overdueItems.map(r => {
          const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
          return `
            <div class="priority-item border-left-danger glass-card">
              <div class="priority-item-header">
                <strong>${r.clientName}</strong>
                <span class="badge badge-danger">${aging.days === 999 ? 'No Date' : `${aging.days}d Overdue`}</span>
              </div>
              <div class="priority-item-sub">Provider: ${r.provider} (${r.requestType})</div>
              <div class="mt-1">
                <button class="btn btn-xs btn-danger" onclick="Requests.openRegisterFollowUpModal('${r.id}')">🚨 Resolve Overdue</button>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // 3. Waiting on Provider Panel
    const waitingProviderList = document.getElementById('panel-waiting-provider');
    if (waitingProviderList) {
      const stalledReqs = requests.filter(r => {
        const s = (r.status || '').toLowerCase();
        return s === 'requested' || s === 'pending';
      }).slice(0, 5);

      waitingProviderList.innerHTML = stalledReqs.map(r => {
        const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
        return `
          <div class="priority-item glass-card">
            <div class="priority-item-header">
              <span>🏥 <strong>${r.provider}</strong></span>
              <span class="badge ${aging.badgeClass}">${aging.label}</span>
            </div>
            <div class="priority-item-sub">Client: ${r.clientName} | Days: ${aging.days === 999 ? 'Unknown' : `${aging.days} days`}</div>
          </div>
        `;
      }).join('');
    }

    // 4. Waiting on Insurance Panel
    const waitingInsList = document.getElementById('panel-waiting-insurance');
    if (waitingInsList) {
      const stalledIns = liability.filter(l => {
        const s = (l.liabilityStatus || '').toLowerCase();
        return s.includes('pending') || !l.lastContactDate;
      }).slice(0, 5);

      waitingInsList.innerHTML = stalledIns.map(l => `
        <div class="priority-item glass-card">
          <div class="priority-item-header">
            <span>🛡️ <strong>${l.insurance3P || l.insurance1P || 'Unassigned Insurer'}</strong></span>
            <span class="badge ${l.lastContactDate ? 'badge-warning' : 'badge-danger'}">${l.lastContactDate ? l.liabilityStatus : 'No Date'}</span>
          </div>
          <div class="priority-item-sub">Client: ${l.clientName} | Last Contact: ${l.lastContactDate || 'No record'}</div>
          <div class="mt-1">
            <button class="btn btn-xs btn-outline" onclick="Liability.openRegisterFollowUpModal('${l.id}')">📞 Contact</button>
          </div>
        </div>
      `).join('');
    }

    // 5. Activity Feed Panel
    const activityFeed = document.getElementById('panel-activity-feed');
    if (activityFeed) {
      const recent = activity.slice(0, 6);
      if (recent.length === 0) {
        activityFeed.innerHTML = `<div class="empty-state-sm">No recent activity.</div>`;
      } else {
        activityFeed.innerHTML = recent.map(a => `
          <div class="activity-item">
            <span class="activity-dot"></span>
            <div class="activity-content">
              <div class="activity-title"><strong>[${a.targetType}] ${a.action}</strong> <small class="text-muted">(${Utils.getRelativeTimeString(a.timestamp)})</small></div>
              <div class="activity-desc">${a.details}</div>
            </div>
          </div>
        `).join('');
      }
    }
  },

  // ==========================================
  // HTML CANVAS CHARTS RENDERING
  // ==========================================

  renderCharts: () => {
    Dashboard.drawRequestsPieChart();
    Dashboard.drawTopProvidersBarChart();
  },

  /**
   * Renders the Aging Pie Chart using HTML5 Canvas.
   */
  drawRequestsPieChart: () => {
    const canvas = document.getElementById('chart-requests-status');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const requests = Dashboard.filterByActiveManager(Storage.getRequests());

    const counts = {
      'On Track (0-14d)': 0,
      'Recordatorio (15-19d)': 0,
      'Prioridad Alta (20-29d)': 0,
      'Overdue (30+d)': 0,
      'Completado': 0
    };

    requests.forEach(r => {
      const aging = Utils.calculateRequestAging(r.lastContactDate, r.initialRequestDate, r.status);
      if (aging.level === 'completed') counts['Completado']++;
      else if (aging.level === 'overdue' || aging.level === 'unknown') counts['Overdue (30+d)']++;
      else if (aging.level === 'high_priority') counts['Prioridad Alta (20-29d)']++;
      else if (aging.level === 'reminder') counts['Recordatorio (15-19d)']++;
      else counts['On Track (0-14d)']++;
    });

    const total = requests.length || 1;
    const data = [
      { label: 'On Track', value: counts['On Track (0-14d)'], color: '#10b981' },
      { label: '15d Reminder', value: counts['Recordatorio (15-19d)'], color: '#f59e0b' },
      { label: '20d High Priority', value: counts['Prioridad Alta (20-29d)'], color: '#f97316' },
      { label: '30d+ Overdue', value: counts['Overdue (30+d)'], color: '#ef4444' },
      { label: 'Completed', value: counts['Completado'], color: '#3b82f6' }
    ];

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 20;

    let startAngle = 0;
    data.forEach(slice => {
      if (slice.value === 0) return;
      const sliceAngle = (slice.value / total) * 2 * Math.PI;

      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
      ctx.arc(centerX, centerY, radius * 0.55, startAngle + sliceAngle, startAngle, true);
      ctx.closePath();
      ctx.fillStyle = slice.color;
      ctx.fill();

      startAngle += sliceAngle;
    });

    const legendEl = document.getElementById('chart-requests-legend');
    if (legendEl) {
      legendEl.innerHTML = data.map(d => `
        <span class="chart-legend-item">
          <span class="chart-legend-color" style="background:${d.color}"></span>
          ${d.label}: <strong>${d.value}</strong>
        </span>
      `).join('');
    }
  },

  /**
   * Renders the Top Providers Bar Chart using HTML5 Canvas.
   */
  drawTopProvidersBarChart: () => {
    const canvas = document.getElementById('chart-top-providers');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const requests = Dashboard.filterByActiveManager(Storage.getRequests());

    const providerCounts = {};
    requests.forEach(r => {
      const s = (r.status || '').toLowerCase();
      if (s !== 'received' && s !== 'closed' && s !== 'complete' && r.provider) {
        providerCounts[r.provider] = (providerCounts[r.provider] || 0) + 1;
      }
    });

    const sorted = Object.entries(providerCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (sorted.length === 0) return;

    const maxCount = sorted[0][1] || 1;
    const barHeight = 20;
    const gap = 12;
    let y = 10;

    sorted.forEach(([provider, count]) => {
      const barWidth = ((canvas.width - 140) * count) / maxCount;
      const shortName = provider.length > 18 ? provider.substring(0, 16) + '..' : provider;

      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.font = '12px Inter, sans-serif';
      ctx.fillText(shortName, 5, y + 14);

      const grad = ctx.createLinearGradient(120, 0, 120 + barWidth, 0);
      grad.addColorStop(0, '#6366f1');
      grad.addColorStop(1, '#a855f7');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.roundRect(110, y, Math.max(barWidth, 6), barHeight, 4);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px Inter, sans-serif';
      ctx.fillText(String(count), 120 + Math.max(barWidth, 6), y + 14);

      y += barHeight + gap;
    });
  }
};

window.Dashboard = Dashboard;
