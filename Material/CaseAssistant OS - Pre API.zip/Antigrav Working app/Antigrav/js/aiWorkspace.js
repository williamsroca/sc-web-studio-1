/**
 * Case Assistant OS - AI Workspace Controller (Phase 5 AI & Cases Integration Edition)
 * Comprehensive UI Controller for Document Intelligence.
 * Features: Multi-file drag & drop, manual document role selection, document reordering,
 * native PDF/Image preview tab viewer, progressive loading state, editable review screen,
 * visual confidence indicators (🟢/🟡/🔴), edit tracking & reset actions, conflict resolution,
 * quick-copy toolbar, extraction history persistence, reload recovery, and
 * HUMAN-IN-THE-LOOP CASE INTEGRATION (selective review-before-saving comparison & audit trails).
 */

const AIWorkspace = {
  activeTool: 'PROPERTY_DAMAGE',
  selectedFiles: [],
  isExtracting: false,
  extractionResult: null,
  activePreviewFileIdx: 0,
  filePreviewUrls: [],
  activeTabSubView: 'workspace', // 'workspace' or 'history'
  linkedCaseContext: null, // Context when launched from a Case

  /**
   * Initializes AI Workspace UI Component & restores persistent workspace state if available.
   */
  init: () => {
    console.log('[AIWorkspace] Initializing AI Workspace UI Controller...');

    // Restore persistent workspace state on reload
    if (!AIWorkspace.extractionResult && window.Storage) {
      const savedExtraction = Storage.getAICurrentExtraction();
      if (savedExtraction && savedExtraction.extractionResult) {
        console.log('[AIWorkspace] Restored current extraction state from LocalStorage.');
        AIWorkspace.extractionResult = savedExtraction.extractionResult;
      }
    }

    AIWorkspace.renderWorkspace();
  },

  /**
   * Links AI Workspace to a specific Case for direct review & selective data import.
   * @param {Object} caseData 
   */
  linkToCase: (caseData) => {
    if (!caseData) return;
    const clientName = window.ClientHelper ? ClientHelper.formatSingleClient(caseData) : (caseData.clientName || 'Client');
    AIWorkspace.linkedCaseContext = {
      caseId: caseData.id,
      clientName: clientName,
      dol: caseData.dol || '',
      fileNumber: caseData.fileNumber || '',
      claimNumber: caseData.claimNumber || '',
      insurance: caseData.insurance || ''
    };
    AIWorkspace.activeTabSubView = 'workspace';
    AIWorkspace.renderWorkspace();
    if (window.Utils) Utils.showToast(`AI Workspace linked to Case: ${clientName}`, 'info');
  },

  unlinkCase: () => {
    AIWorkspace.linkedCaseContext = null;
    AIWorkspace.renderWorkspace();
    if (window.Utils) Utils.showToast('Unlinked case from AI Workspace.', 'info');
  },

  /**
   * Switches the active AI Tool or Sub-View (Workspace vs History).
   * @param {string} toolKey 
   */
  switchTool: (toolKey) => {
    if (toolKey === 'HISTORY') {
      AIWorkspace.activeTabSubView = 'history';
      AIWorkspace.renderWorkspace();
      return;
    }

    if (toolKey !== 'PROPERTY_DAMAGE') {
      if (window.Utils) {
        Utils.showToast(`Tool '${toolKey}' will be available in future AI Extractor expansions.`, 'info');
      }
      return;
    }

    AIWorkspace.activeTabSubView = 'workspace';
    AIWorkspace.activeTool = toolKey;
    AIWorkspace.renderWorkspace();
  },

  /**
   * Main workspace renderer
   */
  renderWorkspace: () => {
    const container = document.getElementById('tab-ai-workspace');
    if (!container) return;

    container.innerHTML = `
      <!-- LINKED CASE CONTEXT BANNER -->
      ${AIWorkspace.linkedCaseContext ? `
        <div class="glass-card mb-2 p-2" style="background: rgba(99, 102, 241, 0.12); border: 1px solid var(--accent-primary); display:flex; justify-content:space-between; align-items:center;">
          <span style="font-size:0.85rem;">
            🔗 <strong>LINKED CASE CONTEXT:</strong> <strong>${AIWorkspace.linkedCaseContext.clientName}</strong> 
            (File #: ${AIWorkspace.linkedCaseContext.fileNumber || 'N/A'} | DOL: ${AIWorkspace.linkedCaseContext.dol || 'N/A'})
          </span>
          <button class="btn btn-xs btn-outline" onclick="AIWorkspace.unlinkCase()">❌ Unlink Case</button>
        </div>
      ` : ''}

      <!-- AI WORKSPACE HEADER -->
      <div class="glass-card mb-3" style="padding: 1.25rem 1.5rem; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.75rem;">
        <div>
          <h2 style="display:flex; align-items:center; gap:0.5rem; margin:0;">
            <span style="font-size:1.5rem;">🤖</span> AI Workspace — Document Intelligence
          </h2>
          <p class="text-muted" style="margin:0.25rem 0 0 0; font-size:0.85rem;">
            Automated legal document extraction, multi-file package merging, source traceability & conflict resolution.
          </p>
        </div>

        <div style="display:flex; gap:0.5rem; align-items:center;">
          <button class="btn btn-sm ${AIWorkspace.activeTabSubView === 'workspace' ? 'btn-primary' : 'btn-outline'}" onclick="AIWorkspace.switchTool('PROPERTY_DAMAGE')">
            🛠️ Workspace
          </button>
          <button class="btn btn-sm ${AIWorkspace.activeTabSubView === 'history' ? 'btn-primary' : 'btn-outline'}" onclick="AIWorkspace.switchTool('HISTORY')">
            📜 History (${window.Storage ? Storage.getAIExtractionHistory().length : 0})
          </button>

          ${AIWorkspace.extractionResult && AIWorkspace.activeTabSubView === 'workspace' ? `
            <button class="btn btn-sm btn-outline" onclick="AIWorkspace.resetExtraction()">🔄 New Upload</button>
            <button class="btn btn-sm btn-outline-excel" onclick="AIWorkspace.copyFullSummary()">📋 Copy All Summary</button>
          ` : ''}
        </div>
      </div>

      <!-- AI WORKSPACE GRID LAYOUT (Tools Sidebar + Main Panel) -->
      <div class="ai-workspace-grid">
        
        <!-- LEFT SIDEBAR: AVAILABLE AI TOOLS -->
        <aside class="glass-card ai-tools-sidebar">
          <h4 class="ai-tools-heading">Available AI Tools</h4>
          <ul class="ai-tools-list">
            <li class="ai-tool-item ${AIWorkspace.activeTool === 'PROPERTY_DAMAGE' && AIWorkspace.activeTabSubView === 'workspace' ? 'active' : ''}" onclick="AIWorkspace.switchTool('PROPERTY_DAMAGE')">
              <span class="ai-tool-icon">🚗</span>
              <div class="ai-tool-info">
                <strong>Property Damage</strong>
                <small>Intake, Estimates & Photos</small>
              </div>
              <span class="badge badge-success" style="font-size:0.65rem;">Active</span>
            </li>

            <li class="ai-tool-item disabled" onclick="AIWorkspace.switchTool('MEDICAL_RECORDS')">
              <span class="ai-tool-icon">🏥</span>
              <div class="ai-tool-info">
                <strong>Medical Records</strong>
                <small>Narratives & Treatments</small>
              </div>
              <span class="badge badge-secondary" style="font-size:0.65rem;">Soon</span>
            </li>

            <li class="ai-tool-item disabled" onclick="AIWorkspace.switchTool('MEDICAL_BILLS')">
              <span class="ai-tool-icon">🧾</span>
              <div class="ai-tool-info">
                <strong>Medical Bills</strong>
                <small>Ledgers & Lien Summaries</small>
              </div>
              <span class="badge badge-secondary" style="font-size:0.65rem;">Soon</span>
            </li>

            <li class="ai-tool-item disabled" onclick="AIWorkspace.switchTool('POLICE_REPORTS')">
              <span class="ai-tool-icon">🚔</span>
              <div class="ai-tool-info">
                <strong>Police Reports</strong>
                <small>Traffic Collision Audits</small>
              </div>
              <span class="badge badge-secondary" style="font-size:0.65rem;">Soon</span>
            </li>

            <li class="ai-tool-item disabled" onclick="AIWorkspace.switchTool('DEMAND_LETTERS')">
              <span class="ai-tool-icon">📄</span>
              <div class="ai-tool-info">
                <strong>Demand Letters</strong>
                <small>Policy Limits & Damages</small>
              </div>
              <span class="badge badge-secondary" style="font-size:0.65rem;">Soon</span>
            </li>

            <li class="ai-tool-item disabled" onclick="AIWorkspace.switchTool('MRI_REPORTS')">
              <span class="ai-tool-icon">🩻</span>
              <div class="ai-tool-info">
                <strong>MRI & Radiology</strong>
                <small>Diagnostic Impressions</small>
              </div>
              <span class="badge badge-secondary" style="font-size:0.65rem;">Soon</span>
            </li>

            <li class="ai-tool-item disabled" onclick="AIWorkspace.switchTool('DEC_PAGES')">
              <span class="ai-tool-icon">📋</span>
              <div class="ai-tool-info">
                <strong>Declarations Pages</strong>
                <small>1P/3P Coverage Limits</small>
              </div>
              <span class="badge badge-secondary" style="font-size:0.65rem;">Soon</span>
            </li>
          </ul>
        </aside>

        <!-- MAIN WORKSPACE PANEL -->
        <main class="glass-card ai-workspace-main">
          ${AIWorkspace.renderMainPanelContent()}
        </main>

      </div>

      <!-- MODALS & POPOVERS CONTAINER -->
      <div id="ai-conflict-modal-container"></div>
    `;

    if (AIWorkspace.activeTabSubView === 'workspace' && !AIWorkspace.extractionResult && !AIWorkspace.isExtracting) {
      AIWorkspace.setupDropzoneEventListeners();
    }
  },

  /**
   * Renders main workspace body depending on subview and state.
   */
  renderMainPanelContent: () => {
    if (AIWorkspace.activeTabSubView === 'history') {
      return AIWorkspace.renderHistoryPanel();
    }

    if (AIWorkspace.isExtracting) {
      return AIWorkspace.renderProcessingState();
    }

    if (AIWorkspace.extractionResult) {
      return AIWorkspace.renderEditableReviewScreen();
    }

    return AIWorkspace.renderUploadInterface();
  },

  // ==========================================
  // 1. EXTRACTION HISTORY COMPONENT
  // ==========================================

  renderHistoryPanel: () => {
    const history = window.Storage ? Storage.getAIExtractionHistory() : [];

    return `
      <div class="ai-panel-header mb-3" style="display:flex; justify-content:space-between; align-items:center;">
        <div>
          <h3>📜 Extraction History</h3>
          <p class="text-muted" style="font-size:0.85rem;">Review past document extractions saved in local browser storage.</p>
        </div>
        ${history.length > 0 ? `
          <button class="btn btn-sm btn-outline-danger" onclick="AIWorkspace.clearHistory()">🗑️ Clear History</button>
        ` : ''}
      </div>

      ${history.length === 0 ? `
        <p class="text-muted" style="text-align:center; padding:2rem;">No previous extractions recorded yet.</p>
      ` : `
        <div style="display:flex; flex-direction:column; gap:0.75rem;">
          ${history.map(h => {
            const relTime = window.Utils ? Utils.getRelativeTimeString(h.timestamp) : new Date(h.timestamp).toLocaleString();
            const fileCount = (h.fileNames || []).length;
            const fileStr = fileCount > 0 ? h.fileNames.join(', ') : 'Document Package';

            return `
              <div class="priority-item glass-card mb-1">
                <div class="priority-item-header">
                  <strong>🚗 ${h.workflow || 'PROPERTY_DAMAGE'}</strong>
                  <span class="badge badge-success">${h.status}</span>
                </div>
                <div class="priority-item-sub" style="margin-top:0.25rem;">
                  Files: <strong>${fileStr}</strong> (${fileCount} file${fileCount === 1 ? '' : 's'}) | <small class="text-muted">${relTime}</small>
                </div>
                <div style="display:flex; justify-content:flex-end; gap:0.5rem; margin-top:0.5rem;">
                  <button class="btn btn-xs btn-outline" onclick="AIWorkspace.loadHistoryEntry('${h.id}')">📂 Open Extraction</button>
                  <button class="btn btn-xs btn-outline-danger" onclick="AIWorkspace.deleteHistoryEntry('${h.id}')">🗑️ Delete</button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `}
    `;
  },

  loadHistoryEntry: (id) => {
    const history = window.Storage ? Storage.getAIExtractionHistory() : [];
    const entry = history.find(h => h.id === id);
    if (!entry || !entry.envelope) return;

    AIWorkspace.extractionResult = entry.envelope;
    AIWorkspace.activeTabSubView = 'workspace';
    AIWorkspace.renderWorkspace();

    if (window.Utils) Utils.showToast('Loaded historical extraction into review screen.', 'success');
  },

  deleteHistoryEntry: (id) => {
    if (window.Storage) Storage.deleteAIExtractionHistory(id);
    AIWorkspace.renderWorkspace();
    if (window.Utils) Utils.showToast('Deleted extraction record.', 'info');
  },

  clearHistory: () => {
    if (window.Storage) Storage.clearAIExtractionHistory();
    AIWorkspace.renderWorkspace();
    if (window.Utils) Utils.showToast('Cleared all extraction history.', 'info');
  },

  // ==========================================
  // UPLOAD INTERFACE & DOCUMENT MANAGEMENT
  // ==========================================

  renderUploadInterface: () => {
    return `
      <div class="ai-panel-header mb-3">
        <h3>🚗 Property Damage Package Extractor</h3>
        <p class="text-muted" style="font-size:0.85rem;">
          Upload 1 to 5 complementary files (Client Intake, Body Shop Estimate, Insurance Appraisal, Photos).
          AI extracts facts, merges records, detects conflicts, and attaches source traceability.
        </p>
      </div>

      <!-- DRAG AND DROP ZONE -->
      <div id="ai-upload-dropzone" class="ai-dropzone mb-3">
        <div class="ai-dropzone-icon">📁</div>
        <h4>Drag & Drop Property Damage Files Here</h4>
        <p class="text-muted" style="font-size:0.82rem; margin-bottom:1rem;">
          Supports PDF, PNG, JPG, WEBP (Max 5 files, total size under 10 MB)
        </p>
        <button class="btn btn-sm btn-outline" onclick="document.getElementById('ai-file-input').click()">
          📂 Browse Files
        </button>
        <input type="file" id="ai-file-input" accept=".pdf,.png,.jpg,.jpeg,.webp" multiple style="display:none;" onchange="AIWorkspace.handleFileInputChange(event)">
      </div>

      <!-- SELECTED FILES CARDS LIST -->
      <div id="ai-files-list" class="ai-files-grid mb-3">
        ${AIWorkspace.renderSelectedFileCards()}
      </div>

      <!-- ACTION BUTTON -->
      <div style="display:flex; justify-content:flex-end;">
        <button id="btn-extract-package" class="btn btn-primary btn-lg" 
          ${AIWorkspace.selectedFiles.length === 0 ? 'disabled' : ''} 
          onclick="AIWorkspace.startExtraction()">
          🚀 Extract Package (${AIWorkspace.selectedFiles.length} file${AIWorkspace.selectedFiles.length === 1 ? '' : 's'})
        </button>
      </div>
    `;
  },

  renderSelectedFileCards: () => {
    if (AIWorkspace.selectedFiles.length === 0) {
      return `<p class="text-muted" style="text-align:center; padding:1rem; font-size:0.85rem;">No files added yet. Drag and drop or browse files above.</p>`;
    }

    const docRoleOptions = [
      'Intake Form',
      'Body Shop Estimate',
      'Insurance Estimate',
      'Vehicle Photos',
      'Other'
    ];

    return AIWorkspace.selectedFiles.map((fileObj, idx) => {
      const file = fileObj.file || fileObj;
      const role = fileObj.role || 'Intake Form';
      const sizeKb = (file.size / 1024).toFixed(1);
      let icon = '📄';
      if (file.type.includes('image')) icon = '🖼️';
      if (file.type.includes('pdf')) icon = '📕';

      return `
        <div class="ai-file-card glass-card">
          <div class="ai-file-icon">${icon}</div>
          <div class="ai-file-details">
            <strong class="ai-file-name" title="${file.name}">${file.name}</strong>
            <span class="ai-file-meta">${sizeKb} KB | ${file.type || 'Document'}</span>
          </div>

          <!-- DOCUMENT ROLE SELECTOR -->
          <div style="margin-left:auto; display:flex; align-items:center; gap:0.4rem;">
            <select class="form-select-sm" style="font-size:0.75rem;" onchange="AIWorkspace.setDocumentRole(${idx}, this.value)">
              ${docRoleOptions.map(opt => `<option value="${opt}" ${role === opt ? 'selected' : ''}>📄 ${opt}</option>`).join('')}
            </select>

            <!-- REORDER BUTTONS -->
            <button class="btn-file-action" ${idx === 0 ? 'disabled' : ''} onclick="AIWorkspace.reorderFile(${idx}, -1)" title="Move Up">⬆️</button>
            <button class="btn-file-action" ${idx === AIWorkspace.selectedFiles.length - 1 ? 'disabled' : ''} onclick="AIWorkspace.reorderFile(${idx}, 1)" title="Move Down">⬇️</button>

            <!-- REMOVE BUTTON -->
            <button class="btn-file-remove" onclick="AIWorkspace.removeFile(${idx})" title="Remove File">&times;</button>
          </div>
        </div>
      `;
    }).join('');
  },

  setupDropzoneEventListeners: () => {
    const dropzone = document.getElementById('ai-upload-dropzone');
    if (!dropzone) return;

    ['dragenter', 'dragover'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropzone.classList.add('drag-over');
      }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropzone.classList.remove('drag-over');
      }, false);
    });

    dropzone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files && files.length > 0) {
        AIWorkspace.handleFileSelection(Array.from(files));
      }
    });
  },

  handleFileInputChange: (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      AIWorkspace.handleFileSelection(files);
    }
  },

  handleFileSelection: (newFiles) => {
    const validMimes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
    const filtered = [];

    newFiles.forEach(f => {
      const mime = (f.type || '').toLowerCase();
      if (!mime || validMimes.some(m => mime.includes(m.replace('image/', '').replace('application/', '')))) {
        filtered.push({
          file: f,
          role: f.name.toLowerCase().includes('estimate') ? 'Body Shop Estimate' : 'Intake Form'
        });
      } else if (window.Utils) {
        Utils.showToast(`Skipped file '${f.name}': Unsupported format. Accepted: PDF, PNG, JPG, WEBP.`, 'warning');
      }
    });

    const combined = [...AIWorkspace.selectedFiles, ...filtered];

    if (combined.length > 5) {
      if (window.Utils) {
        Utils.showToast('Maximum 5 files allowed per extraction request. Truncated excess files.', 'warning');
      }
      AIWorkspace.selectedFiles = combined.slice(0, 5);
    } else {
      AIWorkspace.selectedFiles = combined;
    }

    AIWorkspace.renderWorkspace();
  },

  setDocumentRole: (index, roleName) => {
    if (AIWorkspace.selectedFiles[index]) {
      AIWorkspace.selectedFiles[index].role = roleName;
    }
  },

  reorderFile: (index, direction) => {
    const targetIdx = index + direction;
    if (targetIdx < 0 || targetIdx >= AIWorkspace.selectedFiles.length) return;
    const temp = AIWorkspace.selectedFiles[index];
    AIWorkspace.selectedFiles[index] = AIWorkspace.selectedFiles[targetIdx];
    AIWorkspace.selectedFiles[targetIdx] = temp;
    AIWorkspace.renderWorkspace();
  },

  removeFile: (index) => {
    AIWorkspace.selectedFiles.splice(index, 1);
    AIWorkspace.renderWorkspace();
  },

  // ==========================================
  // PROCESSING STATE COMPONENT
  // ==========================================

  renderProcessingState: () => {
    return `
      <div class="ai-processing-container">
        <div class="ai-spinner"></div>
        <h3 style="margin-top:1.5rem;">Processing Property Damage Package...</h3>
        <p id="ai-processing-status" class="text-muted" style="font-size:0.9rem; margin-top:0.5rem;">
          Uploading document payloads...
        </p>

        <div class="progress-container mt-3" style="max-width:400px; margin-left:auto; margin-right:auto;">
          <div id="ai-processing-bar" class="progress-bar-fill" style="width: 15%; transition: width 0.4s ease;"></div>
        </div>
      </div>
    `;
  },

  startExtraction: async () => {
    if (AIWorkspace.selectedFiles.length === 0) return;

    AIWorkspace.isExtracting = true;
    AIWorkspace.renderWorkspace();

    const statusEl = document.getElementById('ai-processing-status');
    const barEl = document.getElementById('ai-processing-bar');

    const updateProgress = (text, percent) => {
      if (statusEl) statusEl.textContent = text;
      if (barEl) barEl.style.width = `${percent}%`;
    };

    const statusMessages = [
      { text: 'Uploading document payloads...', pct: 20 },
      { text: 'Analyzing document text & imagery...', pct: 40 },
      { text: 'Extracting structured legal fields...', pct: 60 },
      { text: 'Cross-comparing document sources...', pct: 80 },
      { text: 'Resolving conflicts & compiling package...', pct: 95 }
    ];

    let msgIdx = 0;
    const progressTimer = setInterval(() => {
      if (msgIdx < statusMessages.length) {
        updateProgress(statusMessages[msgIdx].text, statusMessages[msgIdx].pct);
        msgIdx++;
      }
    }, 1200);

    try {
      if (!window.AIManager) {
        throw new Error('AIManager subsystem is not initialized.');
      }

      // Convert file objects for extractor
      const rawFiles = AIWorkspace.selectedFiles.map(fObj => fObj.file || fObj);

      // Generate object URLs for document previewing
      AIWorkspace.filePreviewUrls = rawFiles.map(f => ({
        name: f.name,
        type: f.type,
        url: URL.createObjectURL(f)
      }));
      AIWorkspace.activePreviewFileIdx = 0;

      const resultEnvelope = await AIManager.extractPropertyDamage(rawFiles);
      clearInterval(progressTimer);
      updateProgress('Finalizing review screen...', 100);

      setTimeout(() => {
        AIWorkspace.isExtracting = false;
        AIWorkspace.extractionResult = resultEnvelope;

        // Save to extraction history and persistence
        const fileNames = rawFiles.map(f => f.name);
        if (window.Storage) {
          Storage.addAIExtractionHistory('PROPERTY_DAMAGE', fileNames, resultEnvelope);
          Storage.saveAICurrentExtraction({ fileNames, extractionResult: resultEnvelope });
        }

        AIWorkspace.renderWorkspace();
        if (window.Utils) {
          Utils.showToast('Property Damage Package extracted successfully!', 'success');
        }
      }, 400);

    } catch (err) {
      clearInterval(progressTimer);
      console.error('[AIWorkspace] Extraction failed:', err);
      AIWorkspace.isExtracting = false;
      AIWorkspace.renderWorkspace();

      const errMsg = err.message || 'Failed to complete document extraction.';
      if (window.Utils) {
        Utils.showToast(`Extraction Error: ${errMsg}`, 'danger');
      }
    }
  },

  // ==========================================
  // EDITABLE REVIEW SCREEN & PHASE 5 CASE APPLY
  // ==========================================

  renderEditableReviewScreen: () => {
    const envelope = AIWorkspace.extractionResult;
    const merged = envelope.mergedData || {};
    const isLinked = !!AIWorkspace.linkedCaseContext;

    return `
      <div class="ai-review-header mb-3">
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
          <div>
            <h3>📋 Property Damage Package Review</h3>
            <span class="text-muted" style="font-size:0.8rem;">
              Processed <strong>${(envelope.documents || []).length}</strong> document(s) in <strong>${envelope.processingTimeMs || 0}ms</strong>.
            </span>
          </div>

          <div style="display:flex; gap:0.4rem; align-items:center;">
            ${isLinked ? `
              <button class="btn btn-sm btn-primary" onclick="AIWorkspace.openApplyToCaseModal()">
                📥 Apply to Case (${AIWorkspace.linkedCaseContext.clientName})
              </button>
            ` : ''}

            <button class="btn btn-xs btn-outline" onclick="AIWorkspace.resetAllFields()" title="Restore all original AI extracted values">
              🔄 Reset All Fields
            </button>
            <button class="btn btn-xs btn-outline-excel" onclick="AIWorkspace.copyFullSummary()">
              📋 Copy Package Summary
            </button>
          </div>
        </div>

        <!-- QUICK COPY TOOLBAR -->
        <div class="ai-quick-copy-bar mt-2">
          <span class="text-muted" style="font-size:0.75rem; font-weight:600;">⚡ QUICK COPY:</span>
          <button class="btn-quick-copy" onclick="AIWorkspace.quickCopy('claimNumber')" title="Copy Claim Number">📋 Claim #</button>
          <button class="btn-quick-copy" onclick="AIWorkspace.quickCopy('vin')" title="Copy VIN">📋 VIN</button>
          <button class="btn-quick-copy" onclick="AIWorkspace.quickCopy('plate')" title="Copy License Plate">📋 Plate</button>
          <button class="btn-quick-copy" onclick="AIWorkspace.quickCopy('estimate')" title="Copy Repair Estimate">📋 Estimate</button>
          <button class="btn-quick-copy" onclick="AIWorkspace.quickCopy('insurance')" title="Copy Insurance">📋 Insurance</button>
          <button class="btn-quick-copy" onclick="AIWorkspace.quickCopy('owner')" title="Copy Owner">📋 Owner</button>
          <button class="btn-quick-copy" onclick="AIWorkspace.quickCopy('vehicle')" title="Copy Vehicle Year Make Model">📋 Vehicle</button>
        </div>
      </div>

      <!-- NATIVE DOCUMENT PREVIEW CONTAINER -->
      ${AIWorkspace.renderDocumentPreviewContainer()}

      <!-- EDITABLE FIELDS GRID -->
      <div class="ai-fields-grid">
        ${AIWorkspace.renderFieldCard('insurance', 'Insurance Company', merged.insurance, 'text', 'e.g. State Farm')}
        ${AIWorkspace.renderFieldCard('owner', 'Registered Owner', merged.owner, 'text', 'e.g. John Doe')}
        ${AIWorkspace.renderFieldCard('year', 'Year', merged.year, 'number', 'e.g. 2022')}
        ${AIWorkspace.renderFieldCard('make', 'Make', merged.make, 'text', 'e.g. Toyota')}
        ${AIWorkspace.renderFieldCard('model', 'Model', merged.model, 'text', 'e.g. Camry')}
        ${AIWorkspace.renderFieldCard('color', 'Color', merged.color, 'text', 'e.g. Silver')}
        ${AIWorkspace.renderFieldCard('plate', 'License Plate', merged.plate, 'text', 'e.g. 7XYZ89')}
        ${AIWorkspace.renderFieldCard('vin', 'VIN', merged.vin, 'text', 'e.g. 4T1B11HK5MU123456')}
        ${AIWorkspace.renderFieldCard('mileage', 'Mileage (mi)', merged.mileage, 'number', 'e.g. 45210')}
        ${AIWorkspace.renderFieldCard('claimNumber', 'Claim Number', merged.claimNumber, 'text', 'e.g. 987654321-A')}
        ${AIWorkspace.renderFieldCard('policyNumber', 'Policy Number', merged.policyNumber, 'text', 'e.g. POL-8839201')}
        ${AIWorkspace.renderFieldCard('bodyShop', 'Body Shop / Repair Facility', merged.bodyShop, 'text', 'e.g. Caliber Collision')}
        ${AIWorkspace.renderFieldCard('estimate', 'Repair Estimate ($)', merged.estimate, 'number', 'e.g. 5582.19', true)}
      </div>

      <!-- NOTES FULL WIDTH FIELD -->
      <div class="ai-field-card glass-card full-width mt-3 ${merged.notes?.isModified ? 'modified-field' : ''}">
        <div class="ai-field-header">
          <div style="display:flex; align-items:center; gap:0.4rem;">
            <label class="form-label" style="margin:0;">Repair Notes & Structural Damage Summary</label>
            ${merged.notes?.isModified ? '<span class="badge badge-warning" style="font-size:0.65rem;">✏️ Edited</span>' : ''}
          </div>
          <div style="display:flex; align-items:center; gap:0.4rem;">
            ${AIWorkspace.renderConfidenceBadge(merged.notes?.confidence)}
            ${AIWorkspace.renderSourceBadge('notes', merged.notes)}
          </div>
        </div>
        <textarea id="ai-input-notes" class="form-control" rows="3" 
          onchange="AIWorkspace.updateFieldValue('notes', this.value)"
          placeholder="Summary of damages...">${merged.notes?.userValue !== undefined ? merged.notes.userValue : (merged.notes?.value || '')}</textarea>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:0.5rem;">
          ${merged.notes?.isModified ? `<button class="btn btn-xs btn-outline" onclick="AIWorkspace.resetField('notes')">🔄 Reset Note</button>` : '<span></span>'}
          <button class="btn btn-sm btn-outline" onclick="AIWorkspace.copyField('notes')">📋 Copy Notes</button>
        </div>
      </div>
    `;
  },

  // ==========================================
  // PHASE 5: REVIEW BEFORE SAVING COMPARISON MODAL
  // ==========================================

  openApplyToCaseModal: () => {
    if (!AIWorkspace.linkedCaseContext || !AIWorkspace.extractionResult) return;
    const caseId = AIWorkspace.linkedCaseContext.caseId;
    const currentCase = window.Storage ? Storage.getCases().find(c => c.id === caseId) : null;
    if (!currentCase) {
      if (window.Utils) Utils.showToast('Linked case record not found in Storage.', 'danger');
      return;
    }

    const merged = AIWorkspace.extractionResult.mergedData || {};
    const modalContainer = document.getElementById('ai-conflict-modal-container');
    if (!modalContainer) return;

    // Helper to extract value
    const getAiVal = (key) => {
      const node = merged[key];
      if (!node) return null;
      return node.isModified ? node.userValue : node.value;
    };

    const comparisons = [
      { key: 'insurance', label: 'Insurance Company', current: currentCase.insurance || 'Unassigned', ai: getAiVal('insurance') },
      { key: 'claimNumber', label: 'Claim Number', current: currentCase.claimNumber || 'Unassigned', ai: getAiVal('claimNumber') },
      { key: 'policyNumber', label: 'Policy Number', current: currentCase.policyNumber || 'Unassigned', ai: getAiVal('policyNumber') },
      { key: 'estimate', label: 'Repair Estimate ($)', current: currentCase.propertyDamageAmount ? `$${currentCase.propertyDamageAmount}` : 'Unassigned', ai: getAiVal('estimate') ? `$${getAiVal('estimate')}` : null, rawAi: getAiVal('estimate') },
      { key: 'bodyShop', label: 'Body Shop / Location', current: currentCase.bodyShop || 'Unassigned', ai: getAiVal('bodyShop') },
      { key: 'vin', label: 'VIN Number', current: currentCase.vin || 'Unassigned', ai: getAiVal('vin') },
      { key: 'plate', label: 'License Plate', current: currentCase.plate || 'Unassigned', ai: getAiVal('plate') },
      { key: 'notes', label: 'Damage Notes', current: currentCase.propertyDamageNotes || 'None', ai: getAiVal('notes') }
    ];

    modalContainer.innerHTML = `
      <div class="modal-overlay active">
        <div class="modal-box glass-card modal-md">
          <div class="modal-header">
            <h3>📥 Selective Import to Case: ${AIWorkspace.linkedCaseContext.clientName}</h3>
            <button class="btn-close" onclick="document.getElementById('ai-conflict-modal-container').innerHTML=''">&times;</button>
          </div>

          <div class="modal-body py-2">
            <p class="text-muted" style="font-size:0.85rem; margin-bottom:1rem;">
              Review and select which AI extracted values to save into the case record. Unchecked fields will remain unchanged.
            </p>

            <div style="display:flex; flex-direction:column; gap:0.75rem; max-height:400px; overflow-y:auto;">
              ${comparisons.map((c, idx) => {
                const hasAiVal = c.ai !== null && c.ai !== undefined && c.ai !== '';
                const isDifferent = hasAiVal && String(c.current).toLowerCase().trim() !== String(c.ai).toLowerCase().trim();

                return `
                  <div class="priority-item glass-card p-2" style="border-left: 4px solid ${isDifferent ? 'var(--status-warning)' : 'var(--glass-border)'}">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.3rem;">
                      <strong>${c.label}</strong>
                      ${isDifferent ? '<span class="badge badge-warning" style="font-size:0.65rem;">Updated Value Found</span>' : ''}
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:0.5rem; font-size:0.82rem;" class="mb-2">
                      <div class="p-1 rounded" style="background:rgba(255,255,255,0.02);">
                        <small class="text-muted" style="display:block;">Current Case Value:</small>
                        <span>${c.current}</span>
                      </div>
                      <div class="p-1 rounded" style="background:rgba(99,102,241,0.08);">
                        <small class="text-muted" style="display:block;">Proposed AI Value:</small>
                        <strong style="color:${hasAiVal ? 'var(--accent-primary)' : 'var(--text-muted)'}">${c.ai || 'null (No Data)'}</strong>
                      </div>
                    </div>

                    <div style="display:flex; align-items:center; gap:0.5rem;">
                      <label style="font-size:0.8rem; cursor:pointer; display:flex; align-items:center; gap:0.3rem;">
                        <input type="checkbox" id="ai-chk-field-${c.key}" ${hasAiVal && isDifferent ? 'checked' : ''} ${!hasAiVal ? 'disabled' : ''}>
                        Apply AI Value to Case
                      </label>
                    </div>
                  </div>
                `;
              }).join('')}
            </div>
          </div>

          <div class="modal-footer" style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem;">
            <span class="text-muted" style="font-size:0.8rem;">Select fields above to approve import.</span>
            <div style="display:flex; gap:0.5rem;">
              <button class="btn btn-sm btn-outline" onclick="document.getElementById('ai-conflict-modal-container').innerHTML=''">Cancel</button>
              <button class="btn btn-sm btn-primary" onclick="AIWorkspace.saveApprovedChangesToCase('${caseId}')">💾 Apply Approved Changes to Case</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  saveApprovedChangesToCase: (caseId) => {
    const currentCase = window.Storage ? Storage.getCases().find(c => c.id === caseId) : null;
    if (!currentCase) return;

    const merged = AIWorkspace.extractionResult?.mergedData || {};
    const getAiVal = (key) => {
      const node = merged[key];
      if (!node) return null;
      return node.isModified ? node.userValue : node.value;
    };

    const fieldsToCheck = [
      { key: 'insurance', targetProp: 'insurance' },
      { key: 'claimNumber', targetProp: 'claimNumber' },
      { key: 'policyNumber', targetProp: 'policyNumber' },
      { key: 'estimate', targetProp: 'propertyDamageAmount', rawKey: 'estimate' },
      { key: 'bodyShop', targetProp: 'bodyShop' },
      { key: 'vin', targetProp: 'vin' },
      { key: 'plate', targetProp: 'plate' },
      { key: 'notes', targetProp: 'propertyDamageNotes' }
    ];

    const updatedFieldsList = [];

    fieldsToCheck.forEach(item => {
      const chk = document.getElementById(`ai-chk-field-${item.key}`);
      if (chk && chk.checked) {
        const val = getAiVal(item.key);
        if (val !== null && val !== undefined) {
          currentCase[item.targetProp] = val;
          updatedFieldsList.push(item.key);
        }
      }
    });

    if (updatedFieldsList.length === 0) {
      if (window.Utils) Utils.showToast('No fields were selected for update.', 'info');
      document.getElementById('ai-conflict-modal-container').innerHTML = '';
      return;
    }

    // Attach Audit Log Entry to Case
    if (!currentCase.aiExtractionLogs) currentCase.aiExtractionLogs = [];
    const auditEntry = {
      timestamp: new Date().toISOString(),
      action: 'AI Property Damage Package Applied',
      updatedFields: updatedFieldsList,
      sourceDocuments: AIWorkspace.filePreviewUrls.map(f => f.name)
    };
    currentCase.aiExtractionLogs.unshift(auditEntry);

    // Save to Storage
    Storage.saveCase(currentCase);

    // Add Global Activity Log Entry
    Storage.addActivityLog('AI Case Update', `Updated ${updatedFieldsList.length} field(s) (${updatedFieldsList.join(', ')}) for case ${currentCase.clientName}`, 'Case');

    document.getElementById('ai-conflict-modal-container').innerHTML = '';

    if (window.Utils) {
      Utils.showToast(`Successfully updated ${updatedFieldsList.length} field(s) in Case #${currentCase.fileNumber || caseId}!`, 'success');
    }

    // Reopen CaseDetails workspace view with fresh updated case data!
    setTimeout(() => {
      if (window.CaseDetails) {
        CaseDetails.open(currentCase);
      }
    }, 500);
  },

  // ==========================================
  // DOCUMENT PREVIEW CONTAINER
  // ==========================================

  renderDocumentPreviewContainer: () => {
    if (!AIWorkspace.filePreviewUrls || AIWorkspace.filePreviewUrls.length === 0) return '';

    const activePrev = AIWorkspace.filePreviewUrls[AIWorkspace.activePreviewFileIdx] || AIWorkspace.filePreviewUrls[0];

    return `
      <div class="glass-card mb-3 p-2" style="padding:0.75rem;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
          <strong style="font-size:0.8rem; color:var(--text-muted);">📄 DOCUMENT PREVIEW VIEWER:</strong>
          
          <!-- TAB SWITCHER FOR UPLOADED FILES -->
          <div style="display:flex; gap:0.3rem; overflow-x:auto;">
            ${AIWorkspace.filePreviewUrls.map((p, idx) => `
              <button class="btn btn-xs ${idx === AIWorkspace.activePreviewFileIdx ? 'btn-primary' : 'btn-outline'}" 
                onclick="AIWorkspace.setActivePreviewTab(${idx})" title="${p.name}">
                📄 ${p.name.length > 18 ? p.name.substring(0, 15) + '...' : p.name}
              </button>
            `).join('')}
          </div>
        </div>

        <div style="width:100%; height:220px; border-radius:var(--radius-sm); border:1px solid var(--glass-border); overflow:hidden; background:#000;">
          ${activePrev.type.includes('pdf') ? `
            <iframe src="${activePrev.url}#toolbar=0" style="width:100%; height:100%; border:none;"></iframe>
          ` : `
            <img src="${activePrev.url}" style="width:100%; height:100%; object-fit:contain;" alt="${activePrev.name}">
          `}
        </div>
      </div>
    `;
  },

  setActivePreviewTab: (index) => {
    AIWorkspace.activePreviewFileIdx = index;
    AIWorkspace.renderWorkspace();
  },

  // ==========================================
  // CONFIDENCE VISUALIZATION & FIELD RENDERING
  // ==========================================

  renderFieldCard: (fieldKey, label, fieldData, inputType = 'text', placeholder = '', isCurrency = false) => {
    const isModified = fieldData?.isModified;
    const rawVal = isModified ? fieldData.userValue : fieldData?.value;
    const displayVal = rawVal !== null && rawVal !== undefined ? rawVal : '';
    const formattedDisplay = (isCurrency && rawVal !== null && rawVal !== undefined && rawVal !== '') ? 
      `$${Number(rawVal).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '';

    return `
      <div class="ai-field-card glass-card ${isModified ? 'modified-field' : ''}">
        <div class="ai-field-header">
          <div style="display:flex; align-items:center; gap:0.3rem;">
            <label class="form-label" style="margin:0;">${label}</label>
            ${isModified ? '<span class="badge badge-warning" style="font-size:0.6rem;">✏️ Edited</span>' : ''}
          </div>
          <div style="display:flex; align-items:center; gap:0.3rem;">
            ${AIWorkspace.renderConfidenceBadge(fieldData?.confidence)}
            ${AIWorkspace.renderSourceBadge(fieldKey, fieldData)}
          </div>
        </div>

        <div class="input-group">
          <input type="${inputType}" id="ai-input-${fieldKey}" class="form-control form-control-sm" 
            value="${displayVal}" 
            placeholder="${placeholder}"
            onchange="AIWorkspace.updateFieldValue('${fieldKey}', this.value)">
          <button class="btn btn-sm btn-outline" onclick="AIWorkspace.copyField('${fieldKey}')" title="Copy field">
            📋
          </button>
        </div>

        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:0.25rem;">
          ${formattedDisplay ? `<small class="text-muted" style="font-size:0.75rem;">Display: <strong>${formattedDisplay}</strong></small>` : '<span></span>'}
          ${isModified ? `<button class="btn btn-xs btn-outline" style="font-size:0.65rem;" onclick="AIWorkspace.resetField('${fieldKey}')" title="Reset to AI suggestion">🔄 Reset</button>` : ''}
        </div>
      </div>
    `;
  },

  renderConfidenceBadge: (confidence) => {
    if (confidence === null || confidence === undefined) return '';
    const num = Math.round(confidence * 100);

    if (num >= 90) {
      return `<span class="badge confidence-high" title="High Confidence (${num}%)">🟢 ${num}%</span>`;
    }
    if (num >= 70) {
      return `<span class="badge confidence-med" title="Medium Confidence (${num}%)">🟡 ${num}%</span>`;
    }
    return `<span class="badge confidence-low" title="Low Confidence (${num}%)">🔴 ${num}%</span>`;
  },

  renderSourceBadge: (fieldKey, fieldData) => {
    if (!fieldData) return '';

    if (fieldData.isVerified) {
      return `<span class="badge badge-success" style="font-size:0.65rem;">✅ Verified</span>`;
    }

    if (fieldData.hasConflict) {
      return `
        <button class="badge badge-danger badge-interactive" onclick="AIWorkspace.openConflictResolver('${fieldKey}')" title="Conflict detected! Click to resolve.">
          🚨 Conflict
        </button>
      `;
    }

    if (fieldData.source) {
      const sourceStr = Array.isArray(fieldData.sources) && fieldData.sources.length > 1 ?
        `${fieldData.sources.length} Sources` : fieldData.source;

      return `
        <span class="badge badge-info" style="font-size:0.65rem;" title="Source: ${fieldData.sources ? fieldData.sources.join(', ') : fieldData.source}">
          📄 ${sourceStr}
        </span>
      `;
    }

    return `<span class="badge badge-secondary" style="font-size:0.65rem;">None</span>`;
  },

  // ==========================================
  // FIELD EDITING & RESET ACTIONS
  // ==========================================

  updateFieldValue: (fieldKey, newVal) => {
    if (!AIWorkspace.extractionResult || !AIWorkspace.extractionResult.mergedData) return;
    const node = AIWorkspace.extractionResult.mergedData[fieldKey];
    if (node) {
      node.isModified = true;
      node.userValue = newVal === '' ? null : newVal;

      if (window.Storage) {
        Storage.saveAICurrentExtraction({ extractionResult: AIWorkspace.extractionResult });
      }
    }
    AIWorkspace.renderWorkspace();
  },

  resetField: (fieldKey) => {
    if (!AIWorkspace.extractionResult || !AIWorkspace.extractionResult.mergedData) return;
    const node = AIWorkspace.extractionResult.mergedData[fieldKey];
    if (node) {
      delete node.isModified;
      delete node.userValue;

      if (window.Storage) {
        Storage.saveAICurrentExtraction({ extractionResult: AIWorkspace.extractionResult });
      }
    }
    AIWorkspace.renderWorkspace();
    if (window.Utils) Utils.showToast(`Reset field '${fieldKey}' to AI suggestion.`, 'info');
  },

  resetAllFields: () => {
    if (!AIWorkspace.extractionResult || !AIWorkspace.extractionResult.mergedData) return;
    const merged = AIWorkspace.extractionResult.mergedData;
    Object.keys(merged).forEach(k => {
      delete merged[k].isModified;
      delete merged[k].userValue;
    });

    if (window.Storage) {
      Storage.saveAICurrentExtraction({ extractionResult: AIWorkspace.extractionResult });
    }
    AIWorkspace.renderWorkspace();
    if (window.Utils) Utils.showToast('Reset all fields to original AI extracted values.', 'info');
  },

  // ==========================================
  // CONFLICT RESOLUTION
  // ==========================================

  openConflictResolver: (fieldKey) => {
    const node = AIWorkspace.extractionResult?.mergedData?.[fieldKey];
    if (!node || !node.hasConflict) return;

    const modalContainer = document.getElementById('ai-conflict-modal-container');
    if (!modalContainer) return;

    const primaryValue = node.value;
    const conflicts = node.conflicts || [];

    const allOptions = [
      { value: primaryValue, source: node.source, confidence: node.confidence, isPrimary: true },
      ...conflicts.map(c => ({ value: c.value, source: c.source, confidence: c.confidence || 0.90, isPrimary: false }))
    ];

    modalContainer.innerHTML = `
      <div class="modal-overlay active">
        <div class="modal-box glass-card modal-sm">
          <div class="modal-header">
            <h3>🚨 Resolve Conflict: '${fieldKey}'</h3>
            <button class="btn-close" onclick="document.getElementById('ai-conflict-modal-container').innerHTML=''">&times;</button>
          </div>
          <div class="modal-body py-3">
            <p style="font-size:0.85rem; color:var(--text-muted);">
              Different values were extracted across documents. Choose the correct value or verify current selection:
            </p>

            <div style="display:flex; flex-direction:column; gap:0.5rem;">
              ${allOptions.map((opt) => `
                <div class="priority-item glass-card" style="cursor:pointer; border-left: 4px solid ${opt.isPrimary ? 'var(--accent-primary)' : 'var(--status-warning)'};"
                  onclick="AIWorkspace.resolveConflict('${fieldKey}', '${opt.value}', '${opt.source}')">
                  <div class="priority-item-header">
                    <strong>${opt.value}</strong>
                    ${AIWorkspace.renderConfidenceBadge(opt.confidence)}
                  </div>
                  <div class="priority-item-sub">Source: 📄 ${opt.source}</div>
                </div>
              `).join('')}
            </div>
          </div>
          <div class="modal-footer" style="display:flex; justify-content:space-between; gap:0.5rem;">
            <button class="btn btn-sm btn-outline-success" onclick="AIWorkspace.markAsVerified('${fieldKey}')">✅ Mark Current as Verified</button>
            <button class="btn btn-sm btn-outline" onclick="document.getElementById('ai-conflict-modal-container').innerHTML=''">Cancel</button>
          </div>
        </div>
      </div>
    `;
  },

  resolveConflict: (fieldKey, selectedValue, sourceDoc) => {
    const node = AIWorkspace.extractionResult?.mergedData?.[fieldKey];
    if (node) {
      node.value = selectedValue;
      node.source = sourceDoc;
      node.hasConflict = false;
      node.conflicts = [];
      node.isVerified = true;

      if (window.Storage) {
        Storage.saveAICurrentExtraction({ extractionResult: AIWorkspace.extractionResult });
      }
    }

    document.getElementById('ai-conflict-modal-container').innerHTML = '';
    AIWorkspace.renderWorkspace();

    if (window.Utils) {
      Utils.showToast(`Conflict resolved: '${fieldKey}' set to '${selectedValue}'`, 'success');
    }
  },

  markAsVerified: (fieldKey) => {
    const node = AIWorkspace.extractionResult?.mergedData?.[fieldKey];
    if (node) {
      node.hasConflict = false;
      node.conflicts = [];
      node.isVerified = true;

      if (window.Storage) {
        Storage.saveAICurrentExtraction({ extractionResult: AIWorkspace.extractionResult });
      }
    }

    document.getElementById('ai-conflict-modal-container').innerHTML = '';
    AIWorkspace.renderWorkspace();

    if (window.Utils) {
      Utils.showToast(`Field '${fieldKey}' marked as manually verified.`, 'success');
    }
  },

  // ==========================================
  // QUICK COPY TOOLBAR ACTIONS
  // ==========================================

  quickCopy: (copyKey) => {
    if (!AIWorkspace.extractionResult || !AIWorkspace.extractionResult.mergedData) return;
    const merged = AIWorkspace.extractionResult.mergedData;
    const getVal = (key) => {
      const node = merged[key];
      if (!node) return '';
      return node.isModified ? node.userValue : node.value;
    };

    let copyText = '';
    let label = copyKey;

    switch (copyKey) {
      case 'claimNumber':
        copyText = getVal('claimNumber');
        label = 'Claim #';
        break;
      case 'vin':
        copyText = getVal('vin');
        label = 'VIN';
        break;
      case 'plate':
        copyText = getVal('plate');
        label = 'Plate';
        break;
      case 'estimate':
        const rawEst = getVal('estimate');
        copyText = rawEst ? `$${Number(rawEst).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '';
        label = 'Estimate';
        break;
      case 'insurance':
        copyText = getVal('insurance');
        label = 'Insurance';
        break;
      case 'owner':
        copyText = getVal('owner');
        label = 'Owner';
        break;
      case 'vehicle':
        const yr = getVal('year') || '';
        const mk = getVal('make') || '';
        const md = getVal('model') || '';
        copyText = `${yr} ${mk} ${md}`.trim();
        label = 'Vehicle';
        break;
      default:
        copyText = getVal(copyKey);
    }

    if (!copyText) {
      if (window.Utils) Utils.showToast(`Field '${label}' is empty.`, 'warning');
      return;
    }

    if (window.Utils) {
      Utils.copyToClipboard(copyText, `Copied ${label}: ${copyText}`);
    }
  },

  copyField: (fieldKey) => {
    const node = AIWorkspace.extractionResult?.mergedData?.[fieldKey];
    const val = node?.isModified ? node.userValue : node?.value;

    if (!val) {
      if (window.Utils) Utils.showToast(`Field '${fieldKey}' is empty.`, 'warning');
      return;
    }

    if (window.Utils) {
      Utils.copyToClipboard(String(val), `Copied ${fieldKey}: ${val}`);
    }
  },

  copyFullSummary: () => {
    if (!AIWorkspace.extractionResult || !AIWorkspace.extractionResult.mergedData) return;

    const merged = AIWorkspace.extractionResult.mergedData;
    const getVal = (key) => {
      const node = merged[key];
      if (!node) return 'Pending/N/A';
      const val = node.isModified ? node.userValue : node.value;
      return val !== null && val !== undefined && val !== '' ? val : 'Pending/N/A';
    };

    const rawEst = merged.estimate?.isModified ? merged.estimate.userValue : merged.estimate?.value;
    const estVal = rawEst ? `$${Number(rawEst).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : 'Pending';

    const summaryText = `PROPERTY DAMAGE PACKAGE SUMMARY
===============================
Insurance Company: ${getVal('insurance')}
Claim Number:      ${getVal('claimNumber')}
Policy Number:     ${getVal('policyNumber')}

Registered Owner:  ${getVal('owner')}
Vehicle:           ${getVal('year')} ${getVal('make')} ${getVal('model')} (${getVal('color')})
VIN:               ${getVal('vin')}
License Plate:     ${getVal('plate')}
Odometer Mileage:  ${getVal('mileage')}

Body Shop:         ${getVal('bodyShop')}
Repair Estimate:   ${estVal}

Damage Notes:
${getVal('notes')}
===============================`;

    if (window.Utils) {
      Utils.copyToClipboard(summaryText, 'Copied complete Property Damage Package summary!');
    }
  },

  resetExtraction: () => {
    AIWorkspace.selectedFiles = [];
    AIWorkspace.extractionResult = null;
    AIWorkspace.isExtracting = false;
    if (window.Storage) Storage.clearAICurrentExtraction();
    AIWorkspace.renderWorkspace();
  }
};

if (typeof window !== 'undefined') {
  window.AIWorkspace = AIWorkspace;
}
