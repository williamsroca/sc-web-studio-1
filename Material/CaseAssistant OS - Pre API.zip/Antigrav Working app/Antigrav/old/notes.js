/**
 * Case Assistant v1.5 - Rich Dual Note Generator
 */

const NotesEngine = {
  // Generate Rich Structured CasePeer & Excel Notes
  createRichFollowUpNote: ({ clientName, dol, providerOrIns, contactDate, medium, person, outcome, nextStep, notes, nextFollowUpDate }) => {
    const cleanClient = (clientName || '').trim();
    const cleanDOL = (dol || '').trim();
    const cleanDate = (contactDate || Utils.formatDate(new Date())).trim();
    const cleanProvider = (providerOrIns || 'Provider/Insurance').trim();

    // 1. Excel Report Format: [Client Name + DOL - Note]
    let clientHeader = cleanClient;
    if (cleanDOL) clientHeader += ` ${cleanDOL}`;

    const summaryShort = `${medium || 'Follow up'} with ${cleanProvider}: ${outcome || 'Updated'}. ${nextStep || ''}`.trim();
    const excelNote = clientHeader ? `${clientHeader} - ${summaryShort}` : summaryShort;

    // 2. Rich CasePeer Format (Structured & Copy-ready for CasePeer)
    const casePeerNoteLines = [
      `[${cleanDate}] - ${cleanProvider}`,
      `Medio: ${medium || 'N/A'} | Persona Contactada: ${person || 'Staff'}`,
      `Resultado: ${outcome || 'En proceso'}`,
      nextStep ? `Próximo paso: ${nextStep}` : null,
      notes ? `Observaciones: ${notes}` : null,
      nextFollowUpDate ? `Próximo Follow-Up: ${nextFollowUpDate}` : null
    ].filter(Boolean);

    const casePeerNote = casePeerNoteLines.join('\n');

    // Save to history drawer
    const savedEntry = Storage.addNoteHistory(cleanClient, cleanDOL, summaryShort, excelNote, casePeerNote);
    Storage.addActivityLog('Follow-Up Note Created', `${cleanClient} (${cleanProvider}): Nota de seguimiento registrada`, 'Notes');
    
    NotesEngine.renderNotesDrawer();
    NotesEngine.openDrawer();

    return { excelNote, casePeerNote, entry: savedEntry };
  },

  // Standard Quick Note
  createNote: (clientName, dol, noteText, options = { saveToHistory: true, autoOpenDrawer: true }) => {
    if (!noteText || !noteText.trim()) return null;

    const cleanClient = (clientName || '').trim();
    const cleanDOL = (dol || '').trim();
    const cleanText = noteText.trim();

    let clientPart = cleanClient;
    if (cleanDOL) clientPart += ` ${cleanDOL}`;
    const excelNote = clientPart ? `${clientPart} - ${cleanText}` : cleanText;
    const casePeerNote = cleanText;

    let savedEntry = null;
    if (options.saveToHistory) {
      savedEntry = Storage.addNoteHistory(cleanClient, cleanDOL, cleanText, excelNote, casePeerNote);
      Storage.addActivityLog('Quick Note Created', `Nota para ${cleanClient || 'General'}: "${cleanText.substring(0, 35)}..."`, 'Notes');
      NotesEngine.renderNotesDrawer();
      if (options.autoOpenDrawer) NotesEngine.openDrawer();
    }

    return { excelNote, casePeerNote, entry: savedEntry };
  },

  openDrawer: () => {
    document.getElementById('notes-drawer')?.classList.add('active');
    document.getElementById('notes-drawer-backdrop')?.classList.add('active');
  },

  closeDrawer: () => {
    document.getElementById('notes-drawer')?.classList.remove('active');
    document.getElementById('notes-drawer-backdrop')?.classList.remove('active');
  },

  toggleDrawer: () => {
    const drawer = document.getElementById('notes-drawer');
    if (drawer?.classList.contains('active')) NotesEngine.closeDrawer();
    else NotesEngine.openDrawer();
  },

  renderNotesDrawer: () => {
    const container = document.getElementById('notes-drawer-list');
    if (!container) return;

    const notes = Storage.getNotesHistory();
    if (notes.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <span style="font-size:2rem; display:block; margin-bottom:0.5rem;">📝</span>
          <p class="text-muted" style="font-size: 0.88rem;">No hay notas generadas aún.<br>Cada actualización manual creará notas aquí.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = notes.map((item) => `
      <div class="note-card glass-card mb-3">
        <div class="note-header">
          <span class="note-title">${item.clientName ? item.clientName : 'Nota General'} ${item.dol ? `<small class="text-muted">(${item.dol})</small>` : ''}</span>
          <span class="note-time">${Utils.getRelativeTimeString(item.timestamp)}</span>
        </div>
        
        <div class="note-body" style="white-space: pre-wrap; font-family: monospace; font-size: 0.82rem; background: rgba(0,0,0,0.15); padding: 0.5rem; border-radius: 4px; margin: 0.4rem 0;">${item.casePeerNote || item.text}</div>
        
        <div class="note-actions">
          <button class="btn btn-xs btn-outline-excel" onclick="Utils.copyToClipboard('${(item.excelNote || '').replace(/'/g, "\\'").replace(/\n/g, ' ')}', 'Nota Excel')">
            📋 Copiar Excel
          </button>
          <button class="btn btn-xs btn-outline-casepeer" onclick="Utils.copyToClipboard('${(item.casePeerNote || '').replace(/'/g, "\\'").replace(/\n/g, '\\n')}', 'Nota CasePeer')">
            📋 Copiar CasePeer
          </button>
        </div>
      </div>
    `).join('');
  }
};

window.NotesEngine = NotesEngine;
