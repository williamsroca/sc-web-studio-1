/**
 * Case Assistant OS - Client Helper Utility
 * Independent, standalone helper module for managing multi-client case data models.
 * Pure logic only: Zero DOM, zero rendering, zero clipboard, zero storage dependencies.
 */

const ClientHelper = {
  /**
   * Generates a unique client ID.
   * @returns {string}
   */
  generateClientId: () => {
    return `client_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  },

  /**
   * Parses a raw name string into structured firstName and lastName.
   * Handles "LastName, FirstName" and "FirstName LastName".
   * @param {string} rawName 
   * @returns {{ firstName: string, lastName: string }}
   */
  parseClientName: (rawName) => {
    if (!rawName || typeof rawName !== 'string') {
      return { firstName: '', lastName: '' };
    }
    const clean = rawName.trim();
    if (!clean) return { firstName: '', lastName: '' };

    if (clean.includes(',')) {
      const parts = clean.split(',').map(p => p.trim());
      return {
        lastName: parts[0] || '',
        firstName: parts.slice(1).join(' ') || ''
      };
    }

    const parts = clean.split(/\s+/);
    if (parts.length === 1) {
      return { firstName: parts[0], lastName: '' };
    }

    return {
      firstName: parts.slice(0, -1).join(' '),
      lastName: parts[parts.length - 1] || ''
    };
  },

  /**
   * Returns array of clients for a case.
   * Automatically adapts legacy single-client case objects (clientName / firstName / lastName)
   * into a client array without mutating the original object.
   * @param {Object} caseData 
   * @returns {Array<{ id: string, firstName: string, lastName: string, isPrimary: boolean }>}
   */
  getClients: (caseData) => {
    if (!caseData || typeof caseData !== 'object') return [];

    if (Array.isArray(caseData.clients) && caseData.clients.length > 0) {
      return caseData.clients.map((c, idx) => ({
        id: c.id || `client_${idx}`,
        firstName: (c.firstName || '').trim(),
        lastName: (c.lastName || '').trim(),
        isPrimary: Boolean(c.isPrimary || (idx === 0 && !caseData.clients.some(cl => cl.isPrimary)))
      }));
    }

    // Legacy single client extraction
    const rawName = caseData.clientName || caseData.name || '';
    const fName = caseData.firstName || caseData.clientFirstName || '';
    const lName = caseData.lastName || caseData.clientLastName || '';

    let firstName = fName;
    let lastName = lName;

    if (!firstName && !lastName && rawName) {
      const parsed = ClientHelper.parseClientName(rawName);
      firstName = parsed.firstName;
      lastName = parsed.lastName;
    }

    if (!firstName && !lastName) {
      return [];
    }

    return [{
      id: caseData.clientId || `client_legacy_primary`,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      isPrimary: true
    }];
  },

  /**
   * Resolves the primary client for a case.
   * @param {Object} caseData 
   * @returns {{ id: string, firstName: string, lastName: string, isPrimary: boolean }|null}
   */
  getPrimaryClient: (caseData) => {
    const clients = ClientHelper.getClients(caseData);
    if (clients.length === 0) return null;
    const primary = clients.find(c => c.isPrimary);
    return primary || clients[0];
  },

  /**
   * Checks if a case contains multiple clients.
   * @param {Object} caseData 
   * @returns {boolean}
   */
  hasMultipleClients: (caseData) => {
    return ClientHelper.getClients(caseData).length > 1;
  },

  /**
   * Formats a client or case's primary client as "LastName, FirstName".
   * @param {Object} caseDataOrClient 
   * @returns {string}
   */
  formatSingleClient: (caseDataOrClient) => {
    if (!caseDataOrClient) return '';

    let client = caseDataOrClient;
    if (!client.firstName && !client.lastName && (client.clients || client.clientName)) {
      client = ClientHelper.getPrimaryClient(caseDataOrClient);
    }

    if (!client) {
      return (caseDataOrClient.clientName || '').trim();
    }

    const fName = (client.firstName || '').trim();
    const lName = (client.lastName || '').trim();

    if (lName && fName) return `${lName}, ${fName}`;
    if (lName) return lName;
    if (fName) return fName;
    return (caseDataOrClient.clientName || '').trim();
  },

  /**
   * Formats all clients in a case as a multiline string ("LastName, FirstName\nLastName, FirstName").
   * @param {Object} caseData 
   * @returns {string}
   */
  formatClientList: (caseData) => {
    const clients = ClientHelper.getClients(caseData);
    if (clients.length === 0) return (caseData?.clientName || '').trim();

    return clients.map(c => ClientHelper.formatSingleClient(c)).filter(Boolean).join('\n');
  },

  /**
   * Formats all clients in a case as an inline string ("FirstName LastName / FirstName LastName").
   * @param {Object} caseData 
   * @returns {string}
   */
  formatClientsInline: (caseData) => {
    const clients = ClientHelper.getClients(caseData);
    if (clients.length === 0) return (caseData?.clientName || '').trim();

    return clients.map(c => {
      const fName = (c.firstName || '').trim();
      const lName = (c.lastName || '').trim();
      if (fName && lName) return `${fName} ${lName}`;
      return fName || lName;
    }).filter(Boolean).join(' / ');
  },

  /**
   * Adds a new client to a case data object, initializing the clients array if needed.
   * Maintains legacy clientName synchronization.
   * @param {Object} caseData 
   * @param {Object} client { firstName, lastName, isPrimary }
   * @returns {Object} Updated caseData
   */
  addClient: (caseData, client = {}) => {
    if (!caseData || typeof caseData !== 'object') return caseData;

    const existingClients = ClientHelper.getClients(caseData);
    const newClient = {
      id: client.id || ClientHelper.generateClientId(),
      firstName: (client.firstName || '').trim(),
      lastName: (client.lastName || '').trim(),
      isPrimary: existingClients.length === 0 ? true : Boolean(client.isPrimary)
    };

    if (newClient.isPrimary) {
      existingClients.forEach(c => { c.isPrimary = false; });
    }

    caseData.clients = [...existingClients, newClient];

    // Sync legacy clientName with primary client
    const primary = ClientHelper.getPrimaryClient(caseData);
    if (primary) {
      caseData.clientName = ClientHelper.formatSingleClient(primary);
    }

    return caseData;
  },

  /**
   * Removes a client by ID from a case.
   * Reassigns primary client status if the removed client was primary.
   * @param {Object} caseData 
   * @param {string} clientId 
   * @returns {Object} Updated caseData
   */
  removeClient: (caseData, clientId) => {
    if (!caseData || !Array.isArray(caseData.clients)) return caseData;

    const remaining = caseData.clients.filter(c => c.id !== clientId);
    if (remaining.length > 0 && !remaining.some(c => c.isPrimary)) {
      remaining[0].isPrimary = true;
    }

    caseData.clients = remaining;

    const primary = ClientHelper.getPrimaryClient(caseData);
    caseData.clientName = primary ? ClientHelper.formatSingleClient(primary) : '';

    return caseData;
  },

  /**
   * Updates an existing client by ID in a case.
   * @param {Object} caseData 
   * @param {string} clientId 
   * @param {Object} updatedFields 
   * @returns {Object} Updated caseData
   */
  updateClient: (caseData, clientId, updatedFields = {}) => {
    const clients = ClientHelper.getClients(caseData);
    const targetIdx = clients.findIndex(c => c.id === clientId);

    if (targetIdx === -1) return caseData;

    if (updatedFields.isPrimary) {
      clients.forEach(c => { c.isPrimary = false; });
    }

    clients[targetIdx] = {
      ...clients[targetIdx],
      ...updatedFields,
      firstName: updatedFields.firstName !== undefined ? updatedFields.firstName.trim() : clients[targetIdx].firstName,
      lastName: updatedFields.lastName !== undefined ? updatedFields.lastName.trim() : clients[targetIdx].lastName
    };

    caseData.clients = clients;

    const primary = ClientHelper.getPrimaryClient(caseData);
    if (primary) {
      caseData.clientName = ClientHelper.formatSingleClient(primary);
    }

    return caseData;
  },

  /**
   * Sets a specified client as primary for a case.
   * @param {Object} caseData 
   * @param {string} clientId 
   * @returns {Object} Updated caseData
   */
  setPrimaryClient: (caseData, clientId) => {
    return ClientHelper.updateClient(caseData, clientId, { isPrimary: true });
  }
};

window.ClientHelper = ClientHelper;
