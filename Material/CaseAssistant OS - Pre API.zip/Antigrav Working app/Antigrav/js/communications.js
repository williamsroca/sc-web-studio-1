/**
 * Case Assistant OS - Communications Engine
 * Version: 1.6.4
 * Pure, transport-agnostic communication generation engine.
 * 
 * Public API:
 * CommunicationEngine.generate(template, caseData, options) => { subject, body }
 * CommunicationEngine.registerTemplate(name, handler)
 * CommunicationEngine.hasTemplate(name) => boolean
 * CommunicationEngine.getRegisteredTemplates() => string[]
 * 
 * Rules:
 * - Pure engine (no DOM, no modals, no HTML, no alerts, no clipboard).
 * - Accepts normalized caseData object.
 * - Transport-agnostic content generation.
 */

(function (global) {
  'use strict';

  // Private template registry
  const _templateRegistry = new Map();

  /**
   * Normalizes raw case data into a clean, structured format with default fallbacks.
   * Accepts camelCase, snake_case, or alternative keys.
   * @param {Object} data 
   * @returns {Object} Normalized case data
   */
  function normalizeCaseData(data = {}) {
    const raw = data || {};
    return {
      clientName: raw.clientName || raw.client_name || raw.client || 'Client',
      claimNumber: raw.claimNumber || raw.claim_number || raw.claimNo || raw.claim_no || 'N/A',
      insuranceCompany: raw.insuranceCompany || raw.insurance_company || raw.insurer || raw.carrier || raw.insurance || 'Insurance Carrier',
      adjusterName: raw.adjusterName || raw.adjuster_name || raw.adjuster || 'Adjuster',
      adjusterEmail: raw.adjusterEmail || raw.adjuster_email || raw.email || '',
      adjusterPhone: raw.adjusterPhone || raw.adjuster_phone || raw.phone || '',
      policyNumber: raw.policyNumber || raw.policy_number || raw.policyNo || raw.policy || 'N/A',
      dateOfLoss: raw.dateOfLoss || raw.date_of_loss || raw.dol || 'N/A',
      pendingItem: raw.pendingItem || raw.pending_item || raw.item || raw.status || 'Status update / Liability determination',
      daysPending: raw.daysPending !== undefined ? raw.daysPending : (raw.days_pending !== undefined ? raw.days_pending : null),
      caseManager: raw.caseManager || raw.case_manager || raw.senderName || raw.sender_name || 'Case Assistant',
      notes: raw.notes || raw.remarks || '',
      ...raw
    };
  }

  /**
   * Formats pending duration text snippet.
   * @param {number|string|null} days 
   * @returns {string}
   */
  function formatDaysPendingPhrase(days) {
    if (days === null || days === undefined || days === '') return '';
    const num = Number(days);
    if (isNaN(num) || num <= 0) return '';
    return ` (pending for ${num} ${num === 1 ? 'day' : 'days'})`;
  }

  /**
   * Communication Engine Singleton
   */
  const CommunicationEngine = {
    /**
     * Registers a new template generator.
     * @param {string} templateName - Template identifier (e.g., 'insurance_followup')
     * @param {Function} handlerFn - Function (caseData, options) => { subject, body }
     */
    registerTemplate: function (templateName, handlerFn) {
      if (typeof templateName !== 'string' || !templateName.trim()) {
        throw new Error('CommunicationEngine.registerTemplate: Template name must be a non-empty string.');
      }
      if (typeof handlerFn !== 'function') {
        throw new Error('CommunicationEngine.registerTemplate: Handler must be a function.');
      }
      const key = templateName.toLowerCase().trim();
      _templateRegistry.set(key, handlerFn);
    },

    /**
     * Checks if a template is registered.
     * @param {string} templateName 
     * @returns {boolean}
     */
    hasTemplate: function (templateName) {
      if (!templateName || typeof templateName !== 'string') return false;
      return _templateRegistry.has(templateName.toLowerCase().trim());
    },

    /**
     * List all registered template names.
     * @returns {string[]}
     */
    getRegisteredTemplates: function () {
      return Array.from(_templateRegistry.keys());
    },

    /**
     * Pure communication generator function.
     * 
     * @param {string} template - Name of template (e.g., 'insurance_followup')
     * @param {Object} caseData - Case metadata object
     * @param {Object} [options={}] - Options (e.g., { tone: 'friendly' | 'professional' | 'firm' })
     * @returns {{ subject: string, body: string }}
     */
    generate: function (template, caseData, options = {}) {
      if (!template || typeof template !== 'string') {
        throw new Error('CommunicationEngine.generate: "template" argument is required and must be a string.');
      }

      const key = template.toLowerCase().trim();
      const handler = _templateRegistry.get(key);

      if (!handler) {
        throw new Error(
          `CommunicationEngine.generate: Unknown template "${template}". Registered templates: ${
            Array.from(_templateRegistry.keys()).join(', ') || 'none'
          }`
        );
      }

      const normalizedData = normalizeCaseData(caseData);
      const safeOptions = { tone: 'professional', ...options };
      if (typeof safeOptions.tone === 'string') {
        safeOptions.tone = safeOptions.tone.toLowerCase().trim();
      }

      return handler(normalizedData, safeOptions);
    }
  };

  // =========================================================================
  // BUILT-IN TEMPLATES REGISTRATION
  // =========================================================================

  /**
   * Template: insurance_followup
   * Generates liability status follow-up emails.
   * Tones: 'friendly', 'professional', 'firm'
   */
  CommunicationEngine.registerTemplate('insurance_followup', function (data, options) {
    const tone = (options.tone || 'professional').toLowerCase();

    // Subject contains ONLY the Claim Number (or blank if missing / empty / N/A)
    let subject = '';
    if (data.claimNumber && typeof data.claimNumber === 'string') {
      const cleanClaim = data.claimNumber.replace(/^Claim\s*#?\s*/i, '').trim();
      if (cleanClaim && cleanClaim.toUpperCase() !== 'N/A' && cleanClaim.toUpperCase() !== 'NONE') {
        subject = cleanClaim;
      }
    }

    const adjusterGreetingName = (data.adjusterName && data.adjusterName !== 'Adjuster' && data.adjusterName.trim()) 
      ? data.adjusterName.trim()
      : '';

    let body = '';

    const matterBlock = [
      `Client Name: ${data.clientName || ''}`,
      `Insurance Company: ${data.insuranceCompany || ''}`,
      `Date of Loss: ${data.dateOfLoss || ''}`,
      `Claim Number: ${data.claimNumber || ''}`
    ].join('\n');

    switch (tone) {
      case 'friendly': {
        const greeting = adjusterGreetingName ? `Hello ${adjusterGreetingName},` : `Good morning,`;
        body = [
          greeting,
          ``,
          `I hope this message finds you well.`,
          ``,
          `I am following up regarding the liability claim for the following matter:`,
          ``,
          matterBlock,
          ``,
          `Could you please provide an update regarding the current liability status when you have a moment?`,
          ``,
          `Thank you for your time and assistance!`,
          ``,
          `Best regards,`
        ].join('\n');
        break;
      }

      case 'firm': {
        const greeting = adjusterGreetingName ? `Dear ${adjusterGreetingName},` : `Dear Claims Adjuster,`;
        body = [
          greeting,
          ``,
          `This letter serves as a formal follow-up regarding the liability claim for the following matter:`,
          ``,
          matterBlock,
          ``,
          `We have not yet received a determination regarding liability status. Please review this matter and provide an updated status at your earliest convenience.`,
          ``,
          `Thank you for your prompt attention to this matter.`,
          ``,
          `Best regards,`
        ].join('\n');
        break;
      }

      case 'professional':
      default: {
        const greeting = adjusterGreetingName ? `Dear ${adjusterGreetingName},` : `Good morning,`;
        body = [
          greeting,
          ``,
          `I hope you are doing well.`,
          ``,
          `I am following up regarding the liability claim for the following matter:`,
          ``,
          matterBlock,
          ``,
          `Could you please provide an update regarding the current liability status when you have a moment?`,
          ``,
          `Thank you for your time.`,
          ``,
          `Best regards,`
        ].join('\n');
        break;
      }
    }

    return {
      subject: subject,
      body: body
    };
  });

  // Export to global window object
  global.CommunicationEngine = CommunicationEngine;

})(typeof window !== 'undefined' ? window : this);
