/**
 * Case Assistant OS - Storage & Migration System
 * Handles LocalStorage persistence, data migrations, backup/restore JSON, and session activity tracking.
 */

const CURRENT_VERSION = '1.6.0';

const STORAGE_KEYS = {
  VERSION: 'kr_law_app_version',
  ACTIVE_MANAGER: 'kr_law_active_manager',
  CASES: 'kr_law_cases',
  REQUESTS: 'kr_law_requests',
  LIABILITY: 'kr_law_liability',
  ACTIVITY_LOGS: 'kr_law_activity_logs',
  SESSION_LOGS: 'kr_law_session_logs',
  IMPORT_HISTORY: 'kr_law_import_history',
  NOTES_HISTORY: 'kr_law_notes_history',
  AI_EXTRACTION_HISTORY: 'kr_law_ai_extraction_history',
  AI_CURRENT_EXTRACTION: 'kr_law_ai_current_extraction',
  SETTINGS: 'kr_law_settings',
  INITIALIZED: 'kr_law_is_initialized'
};

const Storage = {
  CURRENT_VERSION,

  // ==========================================
  // CORE STORAGE HELPERS
  // ==========================================

  getArray: (key) => {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error(`Error reading storage key ${key}:`, e);
      return [];
    }
  },

  setArray: (key, array) => {
    try {
      localStorage.setItem(key, JSON.stringify(array));
    } catch (e) {
      console.error(`Error saving to storage key ${key}:`, e);
    }
  },

  // ==========================================
  // GLOBAL ACTIVE CASE MANAGER STATE
  // ==========================================

  getActiveCaseManager: () => {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_MANAGER) || 'ALL';
  },

  setActiveCaseManager: (managerName) => {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_MANAGER, managerName);
    Storage.addActivityLog('Case Manager Switch', `Filtro global cambiado a: ${managerName === 'ALL' ? 'Todos' : managerName}`, 'System');
  },

  // ==========================================
  // SCHEMA MIGRATIONS
  // ==========================================

  runMigrations: () => {
    const savedVersion = localStorage.getItem(STORAGE_KEYS.VERSION) || '1.0.0';

    if (savedVersion !== CURRENT_VERSION) {
      console.log(`Running safe schema migration from v${savedVersion} to v${CURRENT_VERSION}...`);

      const requests = Storage.getRequests();
      const updatedReqs = requests.map(r => ({
        ...r,
        initialRequestDate: r.initialRequestDate || r.requestDate || Utils.formatDate(new Date()),
        lastContactDate: r.lastContactDate || r.lastFollowUp || r.requestDate || '',
        lastFollowUpDate: r.lastFollowUpDate || r.lastFollowUp || '',
        nextFollowUpDate: r.nextFollowUpDate || r.nextFollowUp || '',
        emailVerificationStatus: r.emailVerificationStatus || 'Pendiente'
      }));
      Storage.setArray(STORAGE_KEYS.REQUESTS, updatedReqs);

      const liability = Storage.getLiabilityItems();
      const updatedLiab = liability.map(l => ({
        ...l,
        lastContactDate: l.lastContactDate || l.lastContact || '',
        nextFollowUpDate: l.nextFollowUpDate || l.nextFollowUp || ''
      }));
      Storage.setArray(STORAGE_KEYS.LIABILITY, updatedLiab);

      localStorage.setItem(STORAGE_KEYS.VERSION, CURRENT_VERSION);
      Storage.addActivityLog('System Upgraded', `Base de datos migrada a v${CURRENT_VERSION} sin pérdida de datos.`, 'System');
    }
  },

  // ==========================================
  // CASES PERSISTENCE
  // ==========================================

  getCases: () => Storage.getArray(STORAGE_KEYS.CASES),

  saveCase: (caseItem) => {
    const cases = Storage.getCases();
    const idx = cases.findIndex(c => c.id === caseItem.id);
    caseItem.updatedAt = new Date().toISOString();
    if (idx >= 0) {
      cases[idx] = { ...cases[idx], ...caseItem };
    } else {
      if (!caseItem.id) caseItem.id = Utils.generateId();
      caseItem.createdAt = new Date().toISOString();
      cases.push(caseItem);
    }
    Storage.setArray(STORAGE_KEYS.CASES, cases);
    return caseItem;
  },

  // ==========================================
  // REQUESTS PERSISTENCE
  // ==========================================

  getRequests: () => Storage.getArray(STORAGE_KEYS.REQUESTS),

  saveRequest: (reqItem) => {
    const reqs = Storage.getRequests();
    const idx = reqs.findIndex(r => r.id === reqItem.id);
    reqItem.updatedAt = new Date().toISOString();
    if (idx >= 0) {
      reqs[idx] = { ...reqs[idx], ...reqItem };
    } else {
      if (!reqItem.id) reqItem.id = Utils.generateId();
      reqItem.createdAt = new Date().toISOString();
      reqs.push(reqItem);
    }
    Storage.setArray(STORAGE_KEYS.REQUESTS, reqs);
    return reqItem;
  },

  // ==========================================
  // LIABILITY PERSISTENCE
  // ==========================================

  getLiabilityItems: () => Storage.getArray(STORAGE_KEYS.LIABILITY),

  saveLiabilityItem: (liabItem) => {
    const items = Storage.getLiabilityItems();
    const idx = items.findIndex(l => l.id === liabItem.id);
    liabItem.updatedAt = new Date().toISOString();
    if (idx >= 0) {
      items[idx] = { ...items[idx], ...liabItem };
    } else {
      if (!liabItem.id) liabItem.id = Utils.generateId();
      liabItem.createdAt = new Date().toISOString();
      items.push(liabItem);
    }
    Storage.setArray(STORAGE_KEYS.LIABILITY, items);
    return liabItem;
  },

  // ==========================================
  // ACTIVITY & SESSION LOGS
  // ==========================================

  getActivityLogs: () => Storage.getArray(STORAGE_KEYS.ACTIVITY_LOGS),
  getSessionLogs: () => Storage.getArray(STORAGE_KEYS.SESSION_LOGS),
  
  addActivityLog: (action, details, targetType = 'General') => {
    const logs = Storage.getActivityLogs();
    const sessionLogs = Storage.getSessionLogs();
    
    const logEntry = {
      id: Utils.generateId(),
      action,
      details,
      targetType,
      timestamp: new Date().toISOString()
    };

    logs.unshift(logEntry);
    if (logs.length > 300) logs.pop();
    Storage.setArray(STORAGE_KEYS.ACTIVITY_LOGS, logs);

    sessionLogs.unshift(logEntry);
    Storage.setArray(STORAGE_KEYS.SESSION_LOGS, sessionLogs);

    return logEntry;
  },

  resetSessionLogs: () => {
    Storage.setArray(STORAGE_KEYS.SESSION_LOGS, []);
  },

  // ==========================================
  // IMPORT & NOTES HISTORY
  // ==========================================

  getImportHistory: () => Storage.getArray(STORAGE_KEYS.IMPORT_HISTORY),

  addImportHistory: (fileName, stats) => {
    const history = Storage.getImportHistory();
    const entry = {
      id: Utils.generateId(),
      fileName,
      timestamp: new Date().toISOString(),
      ...stats
    };
    history.unshift(entry);
    Storage.setArray(STORAGE_KEYS.IMPORT_HISTORY, history);
    return entry;
  },

  getNotesHistory: () => Storage.getArray(STORAGE_KEYS.NOTES_HISTORY),

  addNoteHistory: (clientName, dol, text, excelNote, casePeerNote) => {
    const history = Storage.getNotesHistory();
    const entry = {
      id: Utils.generateId(),
      clientName,
      dol,
      text,
      excelNote,
      casePeerNote,
      timestamp: new Date().toISOString()
    };
    history.unshift(entry);
    if (history.length > 200) history.pop();
    Storage.setArray(STORAGE_KEYS.NOTES_HISTORY, history);
    return entry;
  },

  // ==========================================
  // AI EXTRACTION PERSISTENCE
  // ==========================================

  getAIExtractionHistory: () => Storage.getArray(STORAGE_KEYS.AI_EXTRACTION_HISTORY),

  addAIExtractionHistory: (workflow, fileNames, extractionEnvelope) => {
    const history = Storage.getAIExtractionHistory();
    const entry = {
      id: window.Utils ? Utils.generateId() : 'ai_hist_' + Date.now(),
      timestamp: new Date().toISOString(),
      workflow: workflow || 'PROPERTY_DAMAGE',
      fileNames: Array.isArray(fileNames) ? fileNames : [],
      status: 'success',
      envelope: extractionEnvelope
    };
    history.unshift(entry);
    if (history.length > 100) history.pop();
    Storage.setArray(STORAGE_KEYS.AI_EXTRACTION_HISTORY, history);
    return entry;
  },

  deleteAIExtractionHistory: (id) => {
    const history = Storage.getAIExtractionHistory().filter(h => h.id !== id);
    Storage.setArray(STORAGE_KEYS.AI_EXTRACTION_HISTORY, history);
  },

  clearAIExtractionHistory: () => {
    Storage.setArray(STORAGE_KEYS.AI_EXTRACTION_HISTORY, []);
  },

  getAICurrentExtraction: () => {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AI_CURRENT_EXTRACTION);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  },

  saveAICurrentExtraction: (extractionData) => {
    try {
      localStorage.setItem(STORAGE_KEYS.AI_CURRENT_EXTRACTION, JSON.stringify(extractionData));
    } catch (e) {
      console.error('Failed to persist AI current extraction state:', e);
    }
  },

  clearAICurrentExtraction: () => {
    localStorage.removeItem(STORAGE_KEYS.AI_CURRENT_EXTRACTION);
  },

  // ==========================================
  // DATABASE BACKUP & RESTORE
  // ==========================================

  exportBackupJSON: () => {
    const backup = {
      version: CURRENT_VERSION,
      exportedAt: new Date().toISOString(),
      cases: Storage.getCases(),
      requests: Storage.getRequests(),
      liability: Storage.getLiabilityItems(),
      activityLogs: Storage.getActivityLogs(),
      importHistory: Storage.getImportHistory(),
      notesHistory: Storage.getNotesHistory()
    };
    const jsonStr = JSON.stringify(backup, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CaseAssistant_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    Utils.showToast('Base de datos exportada correctamente', 'success');
  },

  importBackupJSON: (jsonString) => {
    try {
      const backup = JSON.parse(jsonString);
      if (backup.cases) Storage.setArray(STORAGE_KEYS.CASES, backup.cases);
      if (backup.requests) Storage.setArray(STORAGE_KEYS.REQUESTS, backup.requests);
      if (backup.liability) Storage.setArray(STORAGE_KEYS.LIABILITY, backup.liability);
      if (backup.activityLogs) Storage.setArray(STORAGE_KEYS.ACTIVITY_LOGS, backup.activityLogs);
      if (backup.importHistory) Storage.setArray(STORAGE_KEYS.IMPORT_HISTORY, backup.importHistory);
      if (backup.notesHistory) Storage.setArray(STORAGE_KEYS.NOTES_HISTORY, backup.notesHistory);
      localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
      localStorage.setItem(STORAGE_KEYS.VERSION, CURRENT_VERSION);
      Utils.showToast('Base de datos restaurada con éxito', 'success');
      window.location.reload();
    } catch (err) {
      Utils.showToast('Error al importar archivo de respaldo JSON', 'danger');
      console.error(err);
    }
  },

  clearAllData: async () => {
    const confirmed = await Modals.confirm({
      title: '🚨 ¿Borrar TODOS los datos?',
      message: 'Esta acción eliminará de forma irreversible todos los casos, solicitudes, liability, notas e historial local. ¿Estás seguro de continuar?',
      confirmText: 'Sí, Borrar Todo',
      cancelText: 'Cancelar',
      isDanger: true
    });

    if (confirmed) {
      localStorage.clear();
      Utils.showToast('Base de datos reiniciada', 'info');
      setTimeout(() => window.location.reload(), 500);
    }
  }
};

window.Storage = Storage;
