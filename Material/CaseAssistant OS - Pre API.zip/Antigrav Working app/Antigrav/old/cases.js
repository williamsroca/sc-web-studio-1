/**
 * Case Assistant v1.5 - Cases Controller
 */

const Cases = {
  activeSearch: '',
  activeStatusFilter: '',
  activeManagerFilter: '',

  init: () => {
    Cases.renderCasesTable();
    Cases.setupFilters();
  },

  setupFilters: () => {
    const searchInput = document.getElementById('cases-search-input');
    const statusSelect = document.getElementById('cases-filter-status');
    const managerSelect = document.getElementById('cases-filter-manager');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        Cases.activeSearch = e.target.value.toLowerCase().trim();
        Cases.renderCasesTable();
      });
    }

    if (statusSelect) {
      statusSelect.addEventListener('change', (e) => {
        Cases.activeStatusFilter = e.target.value.toLowerCase();
        Cases.renderCasesTable();
      });
    }

    if (managerSelect) {
      managerSelect.addEventListener('change', (e) => {
        Cases.activeManagerFilter = e.target.value.toLowerCase();
        Cases.renderCasesTable();
      });
    }
  },

  renderCasesTable: () => {
    const container = document.getElementById('cases-table-body');
    if (!container) return;

    let cases = Storage.getCases();

    // Populate Manager dropdown
    const managerSelect = document.getElementById('cases-filter-manager');
    if (managerSelect && managerSelect.options.length <= 1) {
      const managers = Array.from(new Set(cases.map(c => c.caseManager || c.attorney).filter(Boolean))).sort();
      managers.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m;
        opt.textContent = m;
        managerSelect.appendChild(opt);
      });
    }

    // Apply Multi-criteria Filtering
    if (Cases.activeSearch) {
      const q = Cases.activeSearch;
      cases = cases.filter(c => 
        (c.clientName || '').toLowerCase().includes(q) ||
        (c.dol || '').toLowerCase().includes(q) ||
        (c.insurance || '').toLowerCase().includes(q) ||
        (c.claimNumber || '').toLowerCase().includes(q) ||
        (c.caseStatus || '').toLowerCase().includes(q) ||
        (c.fileNumber || '').toLowerCase().includes(q) ||
        (c.adjuster || '').toLowerCase().includes(q)
      );
    }

    if (Cases.activeStatusFilter) {
      cases = cases.filter(c => (c.caseStatus || '').toLowerCase().includes(Cases.activeStatusFilter));
    }

    if (Cases.activeManagerFilter) {
      cases = cases.filter(c => (c.caseManager || c.attorney || '').toLowerCase().includes(Cases.activeManagerFilter));
    }

    if (cases.length === 0) {
      container.innerHTML = `
        <tr>
          <td colspan="7" class="text-center text-muted py-4">
            No se encontraron casos con los criterios de búsqueda seleccionados.
          </td>
        </tr>
      `;
      return;
    }

    container.innerHTML = cases.map(c => {
      const stage = c.caseStatus || 'Treating';
      const liabilityBadge = (c.liabilityStatus || '').toLowerCase().includes('pending') ? 
        `<span class="badge badge-warning">Pending</span>` : 
        `<span class="badge badge-success">${c.liabilityStatus || 'Accepted'}</span>`;

      return `
        <tr>
          <td>
            <div class="user-avatar-info">
              <div class="user-avatar">${(c.clientName || 'C')[0].toUpperCase()}</div>
              <div>
                <strong>${c.clientName}</strong>
                ${c.fileNumber ? `<div style="font-size:0.75rem; color:var(--text-muted)">File #${c.fileNumber}</div>` : ''}
              </div>
            </div>
          </td>
          <td><strong>${c.dol || '-'}</strong></td>
          <td><span class="badge badge-info">${stage}</span></td>
          <td>${liabilityBadge}</td>
          <td>${c.insurance || '<span class="text-muted">No asignado</span>'}</td>
          <td>${c.caseManager || c.attorney || 'Erin Garcia'}</td>
          <td>
            <div class="action-btn-group">
              <button class="btn btn-xs btn-outline" onclick="Cases.openCaseDetails('${c.id}')">👁️ Ver Detalles</button>
              <button class="btn btn-xs btn-primary" onclick="Cases.quickNote('${c.id}')">📝 Nota</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openCaseDetails: (caseId) => {
    const cases = Storage.getCases();
    const c = cases.find(item => item.id === caseId);
    if (!c) return;

    const modal = document.getElementById('case-modal');
    const modalBody = document.getElementById('case-modal-body');
    if (!modal || !modalBody) return;

    const requests = Storage.getRequests().filter(r => r.clientName.toLowerCase() === c.clientName.toLowerCase());

    modalBody.innerHTML = `
      <div class="case-detail-header glass-card mb-3 p-3">
        <h2>${c.clientName}</h2>
        <div class="case-detail-meta" style="display:flex; gap:1rem; flex-wrap:wrap; font-size:0.85rem; color:var(--text-muted); margin-top:0.4rem;">
          <span><strong>DOL:</strong> ${c.dol}</span>
          <span><strong>Idioma:</strong> ${c.language || 'English'}</span>
          <span><strong>Estado:</strong> <span class="badge badge-info">${c.caseStatus}</span></span>
          <span><strong>Responsable:</strong> ${c.caseManager || 'Erin Garcia'}</span>
        </div>
      </div>

      <div class="case-detail-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
        <div class="glass-card p-3">
          <h4>🛡️ Seguro & Responsabilidad</h4>
          <p class="mt-1"><strong>Aseguradora:</strong> ${c.insurance || 'Pending'}</p>
          <p><strong>Ajustador:</strong> ${c.adjuster || 'Por contactar'}</p>
          <p><strong>Nº Reclamo:</strong> ${c.claimNumber || 'Sin número'}</p>
          <p><strong>Estado Liability:</strong> ${c.liabilityStatus || 'Pending'}</p>
        </div>

        <div class="glass-card p-3">
          <h4>🏥 Solicitudes Médicas (${requests.length})</h4>
          ${requests.length === 0 ? '<p class="text-muted mt-1">No hay requests para este caso.</p>' : requests.map(r => `
            <div class="priority-item-sub py-1 border-bottom">
              • <strong>${r.provider}</strong> (${r.requestType}) - <span class="badge badge-sm badge-outline">${r.status}</span>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="glass-card mt-3 p-3">
        <h4>📝 Notas del Caso</h4>
        <textarea id="case-notes-input-${c.id}" class="form-control mb-2 mt-2" rows="3" placeholder="Escribe una nota para este caso...">${c.notes || ''}</textarea>
        <button class="btn btn-primary btn-sm" onclick="Cases.saveCaseNotes('${c.id}')">💾 Guardar Notas & Generar Reporte</button>
      </div>
    `;

    modal.classList.add('active');
  },

  saveCaseNotes: (caseId) => {
    const cases = Storage.getCases();
    const c = cases.find(item => item.id === caseId);
    if (!c) return;

    const textarea = document.getElementById(`case-notes-input-${caseId}`);
    if (!textarea) return;

    const newNoteText = textarea.value.trim();
    c.notes = newNoteText;
    Storage.saveCase(c);

    NotesEngine.createNote(c.clientName, c.dol, newNoteText);
    Utils.showToast('Notas del caso guardadas', 'success');

    document.getElementById('case-modal')?.classList.remove('active');
  },

  quickNote: (caseId) => {
    const cases = Storage.getCases();
    const c = cases.find(item => item.id === caseId);
    if (!c) return;

    Modals.openFollowUpModal({
      title: 'Nota / Seguimiento Rápido de Caso',
      clientName: c.clientName,
      dol: c.dol,
      providerOrIns: c.insurance || 'Case Management',
      onSave: (data) => {
        c.notes = (c.notes ? c.notes + '\n' : '') + data.notes;
        Storage.saveCase(c);
        
        NotesEngine.createRichFollowUpNote({
          clientName: c.clientName,
          dol: c.dol,
          providerOrIns: c.insurance || 'Seguro',
          contactDate: data.contactDate,
          medium: data.medium,
          person: data.person,
          outcome: data.outcome,
          nextStep: data.nextStep,
          notes: data.notes,
          nextFollowUpDate: Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000))
        });

        Utils.showToast('Nota del caso agregada al historial de copiado!', 'success');
        Cases.renderCasesTable();
      }
    });
  }
};

window.Cases = Cases;
