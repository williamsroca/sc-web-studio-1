/**
 * Case Assistant OS - AI Schemas Registry
 * Defines structured JSON schemas and default null state factories for extractors.
 * Refined for Property Damage Package (Multi-Document Ingestion, Source Traceability,
 * Raw Numeric Formatting, Conflict Resolution, and AUTO_DETECT compatibility).
 */

const AISchemas = {
  /**
   * Property Damage Extraction Schema (Single Document Raw Extraction)
   * Numeric fields (estimate, mileage) are raw numbers without string formatting ($ or commas).
   */
  PROPERTY_DAMAGE: {
    type: 'object',
    properties: {
      insurance: { type: 'string', description: 'Insurance company name' },
      owner: { type: 'string', description: 'Vehicle owner full name' },
      year: { type: 'number', description: 'Vehicle year as integer (e.g. 2022)' },
      make: { type: 'string', description: 'Vehicle make (e.g. Toyota)' },
      model: { type: 'string', description: 'Vehicle model (e.g. Camry)' },
      color: { type: 'string', description: 'Vehicle color' },
      plate: { type: 'string', description: 'License plate number' },
      vin: { type: 'string', description: '17-character VIN number' },
      mileage: { type: 'number', description: 'Vehicle odometer mileage as integer (e.g. 45210)' },
      claimNumber: { type: 'string', description: 'Insurance claim number' },
      policyNumber: { type: 'string', description: 'Insurance policy number' },
      bodyShop: { type: 'string', description: 'Repair facility or body shop name' },
      estimate: { type: 'number', description: 'Total repair estimate as raw decimal number (e.g. 5582.19)' },
      notes: { type: 'string', description: 'Summary of structural damage, impact area, or repair notes' }
    },
    required: [
      'insurance', 'owner', 'year', 'make', 'model', 'color', 
      'plate', 'vin', 'mileage', 'claimNumber', 'policyNumber', 
      'bodyShop', 'estimate', 'notes'
    ]
  },

  /**
   * Factory function to return default null object for single Property Damage extraction.
   * All numeric fields default to null.
   * @returns {Object}
   */
  createDefaultPropertyDamage: () => ({
    insurance: null,
    owner: null,
    year: null,
    make: null,
    model: null,
    color: null,
    plate: null,
    vin: null,
    mileage: null,
    claimNumber: null,
    policyNumber: null,
    bodyShop: null,
    estimate: null,
    notes: null
  }),

  /**
   * Factory function to return a default field node with Source Traceability & Conflict Metadata.
   * @param {*} value - Initial value or null
   * @param {string|null} source - Source document name or classification
   * @returns {Object} { value, source, sources, confidence, hasConflict, conflicts }
   */
  createTraceableField: (value = null, source = null) => ({
    value: value,
    source: source,
    sources: source ? [source] : [],
    confidence: value !== null ? 0.95 : null,
    hasConflict: false,
    conflicts: []
  }),

  /**
   * Factory function returning default Merged Property Damage Package object.
   * Every field contains full source traceability and conflict metadata.
   * @returns {Object}
   */
  createDefaultMergedPackage: () => ({
    insurance: AISchemas.createTraceableField(),
    owner: AISchemas.createTraceableField(),
    year: AISchemas.createTraceableField(),
    make: AISchemas.createTraceableField(),
    model: AISchemas.createTraceableField(),
    color: AISchemas.createTraceableField(),
    plate: AISchemas.createTraceableField(),
    vin: AISchemas.createTraceableField(),
    mileage: AISchemas.createTraceableField(),
    claimNumber: AISchemas.createTraceableField(),
    policyNumber: AISchemas.createTraceableField(),
    bodyShop: AISchemas.createTraceableField(),
    estimate: AISchemas.createTraceableField(),
    notes: AISchemas.createTraceableField()
  }),

  /**
   * Generic Default Factory based on document type
   * @param {string} docType 
   * @returns {Object}
   */
  createDefault: (docType) => {
    const typeUpper = (docType || '').toUpperCase();
    if (typeUpper === 'PROPERTY_DAMAGE' || typeUpper === 'AUTO_DETECT') {
      return AISchemas.createDefaultPropertyDamage();
    }
    if (typeUpper === 'PROPERTY_DAMAGE_PACKAGE') {
      return AISchemas.createDefaultMergedPackage();
    }
    console.warn(`[AISchemas] Unknown docType '${docType}', returning empty default object.`);
    return {};
  }
};

if (typeof window !== 'undefined') {
  window.AISchemas = AISchemas;
}
