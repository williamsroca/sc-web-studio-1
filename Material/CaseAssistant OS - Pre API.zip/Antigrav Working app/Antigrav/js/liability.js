/**
 * Case Assistant OS - Liability Management Controller
 * Handles Liability status tracking, column sorting, inline table editing (Insurance, Police Report, DEC Page),
 * top section summary header cards, and search filtering.
 */

const Liability = {
  activeSearch: '',
  activeStatusFilter: '',
  sortField: 'clientName',
  sortOrder: 'asc',

  /**
   * Initializes the Liability module.
   */
  init: () => {
    Liability.renderSummaryHeader();
    Liability.renderLiabilityTable();
    Liability.setupSearch();
  },

  /**
   * Calculates Liability metrics (Single Source of Truth).
   * Pure calculation function: NEVER mutates, replaces, or filters the array passed to it.
   * @param {Array} [items] Optional items array. If omitted, fetches from Storage.
   * @returns {Object} { total, pending, accepted, overdue }
   */
  getMetrics: (items) => {
    const list = items || Storage.getLiabilityItems();
    const total = list.length;
    const pending = list.filter(l => {
      const s = (l.liabilityStatus || '').toLowerCase();
      return s.includes('pending') || s.includes('unknown') || !s;
    }).length;

    const accepted = list.filter(l => {
      const s = (l.liabilityStatus || '').toLowerCase();
      return s.includes('accepted') || s.includes('completed');
    }).length;

    const overdue = list.filter(l => {
      if (!l.nextFollowUpDate) return true;
      return Utils.daysFromToday(l.nextFollowUpDate) < 0;
    }).length;

    return { total, pending, accepted, overdue };
  },

  /**
   * Sets the status filter programmatically from KPI card navigation.
   * @param {string} status
   */
  setFilterStatus: (status) => {
    Liability.activeStatusFilter = (status || '').toLowerCase();
    const statusSelect = document.getElementById('liab-filter-status');
    if (statusSelect) statusSelect.value = status ? status : '';
    Liability.renderSummaryHeader();
    Liability.renderLiabilityTable();
  },

  /**
   * Toggles column sorting.
   * @param {string} field
   */
  sortBy: (field) => {
    if (Liability.sortField === field) {
      Liability.sortOrder = Liability.sortOrder === 'asc' ? 'desc' : 'asc';
    } else {
      Liability.sortField = field;
      Liability.sortOrder = 'asc';
    }
    Liability.renderLiabilityTable();
  },

  /**
   * Sets up search input and status filter dropdown listeners.
   */
  setupSearch: () => {
    const searchInput = document.getElementById('liab-search-input');
    const statusSelect = document.getElementById('liab-filter-status');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        Liability.activeSearch = e.target.value.toLowerCase().trim();
        Liability.renderLiabilityTable();
      });
    }

    if (statusSelect) {
      statusSelect.addEventListener('change', (e) => {
        Liability.activeStatusFilter = e.target.value.toLowerCase();
        Liability.renderLiabilityTable();
      });
    }
  },

  /**
   * Renders the Section Summary Header cards for Liability tab using the Single Source of Truth metrics.
   */
  renderSummaryHeader: () => {
    const container = document.getElementById('liability-summary-header');
    if (!container) return;

    const rawItems = Storage.getLiabilityItems();
    const items = Utils.filterByActiveCaseManager(rawItems);

    const metrics = Liability.getMetrics(items);

    container.innerHTML = `
      <div class="kpi-grid mb-3">
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Liability.setFilterStatus('')">
          <span class="kpi-title">Total Liability</span>
          <span class="kpi-value">${metrics.total}</span>
          <span class="kpi-sub">all records</span>
        </div>
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Liability.setFilterStatus('pending')">
          <span class="kpi-title">Pending</span>
          <span class="kpi-value" style="color:var(--status-warning)">${metrics.pending}</span>
          <span class="kpi-sub">awaiting decision</span>
        </div>
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Liability.setFilterStatus('accepted')">
          <span class="kpi-title">Accepted (Completed)</span>
          <span class="kpi-value" style="color:var(--status-success)">${metrics.accepted}</span>
          <span class="kpi-sub">liability clear</span>
        </div>
        <div class="kpi-card glass-card border-left-danger" style="cursor:pointer;" onclick="Liability.setFilterStatus('')">
          <span class="kpi-title">Needs Follow-Up / Overdue</span>
          <span class="kpi-value" style="color:var(--status-danger)">${metrics.overdue}</span>
          <span class="kpi-sub">past due date</span>
        </div>
      </div>
    `;
  },

  /**
   * Renders the Liability table with active search, filters, sorting, and in-table inline controls.
   */
  renderLiabilityTable: () => {
    const container = document.getElementById('liability-table-body');
    if (!container) return;

    const rawItems = Storage.getLiabilityItems();
    let items = Utils.filterByActiveCaseManager(rawItems);

    const q = Liability.activeSearch;

    // Filter by search query
    if (q) {
      items = items.filter(l => 
        (l.clientName || '').toLowerCase().includes(q) ||
        (l.insurance3P || '').toLowerCase().includes(q) ||
        (l.insurance1P || '').toLowerCase().includes(q) ||
        (l.adjuster || '').toLowerCase().includes(q) ||
        (l.liabilityStatus || '').toLowerCase().includes(q) ||
        (l.policeReportStatus || l.pendingItems || '').toLowerCase().includes(q) ||
        (l.decPageStatus || '').toLowerCase().includes(q) ||
        (l.dol || '').toLowerCase().includes(q)
      );
    }

    // Filter by status
    if (Liability.activeStatusFilter) {
      items = items.filter(l => (l.liabilityStatus || '').toLowerCase().includes(Liability.activeStatusFilter));
    }

    // Sort items
    const sf = Liability.sortField;
    const mult = Liability.sortOrder === 'asc' ? 1 : -1;
    items.sort((a, b) => {
      let valA = a[sf] || '';
      let valB = b[sf] || '';
      if (sf === 'insurance') valA = a.insurance3P || a.insurance1P || '';
      if (sf === 'insurance') valB = b.insurance3P || b.insurance1P || '';
      if (typeof valA === 'string') valA = valA.toLowerCase();
      if (typeof valB === 'string') valB = valB.toLowerCase();
      if (valA < valB) return -1 * mult;
      if (valA > valB) return 1 * mult;
      return 0;
    });

    // Update Header Sort Arrows
    ['clientName', 'insurance', 'liabilityStatus', 'policeReportStatus', 'decPageStatus', 'lastContactDate', 'nextFollowUpDate'].forEach(f => {
      const el = document.getElementById(`sort-icon-${f}`);
      if (el) {
        if (f === sf) {
          el.textContent = Liability.sortOrder === 'asc' ? ' ▲' : ' ▼';
        } else {
          el.textContent = '';
        }
      }
    });

    if (items.length === 0) {
      container.innerHTML = `
        <tr>
          <td colspan="8" class="text-center text-muted py-4">
            No liability records found matching the selected criteria.
          </td>
        </tr>
      `;
      return;
    }

    container.innerHTML = items.map(l => {
      const hasRealDate = Boolean(l.lastContactDate || l.lastContact);
      const dateDisplay = hasRealDate ? (l.lastContactDate || l.lastContact) : '<span class="badge badge-danger">No Date</span>';
      
      const daysOverdue = l.nextFollowUpDate ? Utils.daysFromToday(l.nextFollowUpDate) : 0;
      const badgeClass = !hasRealDate ? 'badge-danger' : (daysOverdue < 0 ? 'badge-danger' : (daysOverdue === 0 ? 'badge-warning' : 'badge-success'));
      const badgeText = !hasRealDate ? 'Needs Review' : (daysOverdue < 0 ? `${Math.abs(daysOverdue)}d Overdue` : `In ${daysOverdue}d`);

      const currentIns = l.insurance3P || l.insurance1P || '';
      const policeStatus = l.policeReportStatus || 'Pending';
      const decStatus = l.decPageStatus || 'Pending';

      return `
        <tr id="liab-row-${l.id}">
          <td>
            <strong>${l.clientName}</strong>
            <div style="font-size:0.75rem; color:var(--text-muted)">DOL: ${l.dol || 'N/A'}</div>
          </td>
          <td>
            <input type="text" class="form-control form-control-sm" style="width:140px; font-size:0.8rem;" 
              value="${currentIns.replace(/"/g, '&quot;')}" 
              placeholder="Insurer Name" 
              onchange="Liability.updateInlineField('${l.id}', 'insurance3P', this.value)">
          </td>
          <td>
            <select class="form-select-sm" onchange="Liability.updateLiabilityStatus('${l.id}', this.value)">
              <option value="Pending" ${l.liabilityStatus === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Accepted" ${l.liabilityStatus === 'Accepted' ? 'selected' : ''}>Accepted</option>
              <option value="Denied" ${l.liabilityStatus === 'Denied' ? 'selected' : ''}>Denied</option>
              <option value="Disputed" ${l.liabilityStatus === 'Disputed' ? 'selected' : ''}>Disputed</option>
            </select>
          </td>
          <td>
            <select class="form-select-sm" onchange="Liability.updateInlineField('${l.id}', 'policeReportStatus', this.value)">
              <option value="Pending" ${policeStatus === 'Pending' ? 'selected' : ''}>⏳ Pending</option>
              <option value="Ordered" ${policeStatus === 'Ordered' ? 'selected' : ''}>📑 Ordered</option>
              <option value="Received" ${policeStatus === 'Received' ? 'selected' : ''}>✅ Received</option>
              <option value="N/A" ${policeStatus === 'N/A' ? 'selected' : ''}>➖ N/A</option>
            </select>
          </td>
          <td>
            <select class="form-select-sm" onchange="Liability.updateInlineField('${l.id}', 'decPageStatus', this.value)">
              <option value="Pending" ${decStatus === 'Pending' ? 'selected' : ''}>⏳ Pending</option>
              <option value="Requested" ${decStatus === 'Requested' ? 'selected' : ''}>📑 Requested</option>
              <option value="Received" ${decStatus === 'Received' ? 'selected' : ''}>✅ Received</option>
              <option value="N/A" ${decStatus === 'N/A' ? 'selected' : ''}>➖ N/A</option>
            </select>
          </td>
          <td>${dateDisplay}</td>
          <td>
            <span class="badge ${badgeClass}">${badgeText}</span>
          </td>
          <td>
            <div class="action-btn-group" style="display:flex; gap:0.25rem;">
              <button class="btn btn-xs btn-primary" onclick="Liability.openRegisterFollowUpModal('${l.id}')" title="Register Contact">📞 Contact</button>
              <button class="btn btn-xs btn-outline" onclick="Liability.openCommunicationModal('${l.id}')" title="Insurance Follow-Up">💬</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  /**
   * Updates an inline field (Insurance, Police Report, DEC Page) directly from table.
   * @param {string} id
   * @param {string} fieldName
   * @param {string} value
   */
  updateInlineField: (id, fieldName, value) => {
    const items = Storage.getLiabilityItems();
    const l = items.find(item => item.id === id);
    if (!l) return;

    l[fieldName] = value;
    if (fieldName === 'policeReportStatus') {
      l.pendingItems = `Police Report: ${value} | DEC Page: ${l.decPageStatus || 'Pending'}`;
    }
    if (fieldName === 'decPageStatus') {
      l.pendingItems = `Police Report: ${l.policeReportStatus || 'Pending'} | DEC Page: ${value}`;
    }

    Storage.saveLiabilityItem(l);
    Utils.showToast(`Updated ${fieldName} for ${l.clientName}`, 'success');
    Storage.addActivityLog('Liability Info Updated', `${l.clientName}: ${fieldName} changed to "${value}"`, 'Liability');

    Liability.renderSummaryHeader();
    Dashboard.init();
  },

  /**
   * Updates the Liability status for a specific case item.
   * @param {string} id
   * @param {string} newStatus
   */
  updateLiabilityStatus: (id, newStatus) => {
    const items = Storage.getLiabilityItems();
    const l = items.find(item => item.id === id);
    if (!l) return;

    l.liabilityStatus = newStatus;
    Storage.saveLiabilityItem(l);

    const noteText = `Updated 3P Liability status to ${newStatus}.`;
    NotesEngine.createNote(l.clientName, l.dol, noteText);
    Storage.addActivityLog('Liability Status Updated', `${l.clientName}: Liability status set to ${newStatus}`, 'Liability');
    Utils.showToast(`Liability status updated to ${newStatus}`, 'success');

    Liability.renderSummaryHeader();
    Dashboard.init();
  },

  /**
   * Opens the Follow Up registration modal for a Liability record.
   * @param {string} id
   */
  openRegisterFollowUpModal: (id) => {
    const items = Storage.getLiabilityItems();
    const l = items.find(item => item.id === id);
    if (!l) return;

    Modals.openFollowUpModal({
      title: 'Register Liability Follow Up / Contact',
      clientName: l.clientName,
      dol: l.dol,
      providerOrIns: l.insurance3P || l.insurance1P || 'Liability Insurer',
      type: 'Liability',
      onSave: (data) => {
        const nextDate = Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000));
        
        l.lastContactDate = data.contactDate;
        l.lastFollowUpDate = data.contactDate;
        l.nextFollowUpDate = nextDate;
        
        const summary = `Liability follow-up: ${data.outcome}.${data.nextStep ? ' ' + data.nextStep : ''}`.trim();
        l.notes = (l.notes ? l.notes + '\n' : '') + summary;
        
        Storage.saveLiabilityItem(l);

        NotesEngine.createRichFollowUpNote({
          clientName: l.clientName,
          dol: l.dol,
          providerOrIns: l.insurance3P || l.insurance1P || 'Liability Insurer',
          contactDate: data.contactDate,
          medium: data.medium,
          person: data.person,
          outcome: data.outcome,
          nextStep: data.nextStep,
          notes: data.notes,
          nextFollowUpDate: nextDate
        });

        Storage.addActivityLog('Liability Follow Up', `${l.clientName}: Liability contact logged`, 'Liability');
        Utils.showToast('Liability follow-up saved & note generated!', 'success');

        Liability.renderSummaryHeader();
        Liability.renderLiabilityTable();
        Dashboard.init();
      }
    });
  },

  /**
   * Opens the Communication Follow-Up modal for a Liability record.
   * @param {string} id
   */
  openCommunicationModal: (id) => {
    const items = Storage.getLiabilityItems();
    const l = items.find(item => item.id === id);
    if (!l) return;

    Modals.openCommunicationModal({
      title: 'Insurance Follow-Up',
      templateKey: 'insurance_followup',
      record: l
    });
  }
};

window.Liability = Liability;
