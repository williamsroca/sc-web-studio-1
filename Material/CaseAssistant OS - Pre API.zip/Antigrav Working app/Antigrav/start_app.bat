@echo off
title Case Assistant v1.5 - Portable Launcher
echo ========================================================
echo         Case Assistant v1.5 - KR Law Workspace
echo ========================================================
echo.
echo Launching local server on port 8080...

:: Check if python server is running or start it in background
start /b python -m http.server 8080 > nul 2>&1

echo Server started on http://localhost:8080
echo Opening web browser...
timeout /t 2 > nul
start http://localhost:8080

echo.
echo Application running! Keep this window minimized if using standalone.
