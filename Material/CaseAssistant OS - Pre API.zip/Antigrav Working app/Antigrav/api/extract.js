/**
 * Case Assistant OS - AI Extraction Endpoint Alias (/api/extract)
 * Forwards requests to the primary v1 extraction handler.
 */

const handleExtractRequest = require('./v1/ai/extract');

module.exports = async function handler(req, res) {
  return handleExtractRequest(req, res);
};
