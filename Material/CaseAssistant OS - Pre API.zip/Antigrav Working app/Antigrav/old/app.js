/**
 * Case Assistant v1.5 - Master Application Controller
 */

const App = {
  init: async () => {
    console.log('Initializing Case Assistant v1.5...');

    // 1. Seed & run migrations
    await CSVImporter.seedLocalFilesIfEmpty();

    // 2. Setup Navigation Tabs
    App.setupTabs();

    // 3. Setup Keyboard Shortcuts
    App.setupKeyboardShortcuts();

    // 4. Initialize Sub-controllers
    Dashboard.init();
    Cases.init();
    Requests.init();
    Liability.init();
    Settings.init();
    NotesEngine.renderNotesDrawer();
    App.renderActivityTab();
  },

  // Setup Navigation Tabs
  setupTabs: () => {
    const navItems = document.querySelectorAll('.nav-item');
    const tabContents = document.querySelectorAll('.tab-content');

    navItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const tabId = item.getAttribute('data-tab');

        navItems.forEach(n => n.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));

        item.classList.add('active');
        const activeTab = document.getElementById(tabId);
        if (activeTab) {
          activeTab.classList.add('active');
        }

        if (tabId === 'tab-dashboard') Dashboard.init();
        if (tabId === 'tab-cases') Cases.renderCasesTable();
        if (tabId === 'tab-requests') Requests.renderRequestsTable();
        if (tabId === 'tab-liability') Liability.renderLiabilityTable();
        if (tabId === 'tab-settings') Settings.renderStats();
        if (tabId === 'tab-activity') App.renderActivityTab();
      });
    });
  },

  switchTab: (tabId) => {
    const navItem = document.querySelector(`.nav-item[data-tab="${tabId}"]`);
    if (navItem) navItem.click();
  },

  setupKeyboardShortcuts: () => {
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        App.openGlobalSearch();
      }

      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
        return;
      }

      const key = e.key.toLowerCase();
      if (key === 'n') {
        e.preventDefault();
        App.quickCreateNoteModal();
      } else if (key === 'd') {
        App.switchTab('tab-dashboard');
      } else if (key === 'c') {
        App.switchTab('tab-cases');
      } else if (key === 'r') {
        App.switchTab('tab-requests');
      } else if (key === 'l') {
        App.switchTab('tab-liability');
      }
    });
  },

  toggleTheme: () => {
    const html = document.documentElement;
    const current = html.getAttribute('data-theme');
    const next = current === 'light' ? 'dark' : 'light';
    html.setAttribute('data-theme', next);
    Utils.showToast(`Tema cambiado a modo ${next === 'dark' ? 'oscuro' : 'claro'}`, 'info');
  },

  openImportModal: () => {
    document.getElementById('csv-import-modal')?.classList.add('active');
  },

  handleCSVFileUpload: (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target.result;
      CSVImporter.importCSVText(text, file.name);
      document.getElementById('csv-import-modal')?.classList.remove('active');
      
      Dashboard.init();
      Cases.renderCasesTable();
      Requests.renderRequestsTable();
      Liability.renderLiabilityTable();
      App.renderActivityTab();
    };
    reader.readAsText(file);
  },

  // Custom Modal Quick Note Creator (No browser prompt)
  quickCreateNoteModal: () => {
    Modals.openFollowUpModal({
      title: 'Generar Nota Rápida / Follow Up',
      clientName: 'Cliente Rápido',
      dol: Utils.formatDate(new Date()),
      providerOrIns: 'Provider/Seguro',
      onSave: (data) => {
        NotesEngine.createRichFollowUpNote({
          clientName: 'Nota Rápida',
          dol: Utils.formatDate(new Date()),
          providerOrIns: 'Caso',
          contactDate: data.contactDate,
          medium: data.medium,
          person: data.person,
          outcome: data.outcome,
          nextStep: data.nextStep,
          notes: data.notes,
          nextFollowUpDate: Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000))
        });
        Utils.showToast('Nota generada en el panel lateral!', 'success');
      }
    });
  },

  openGlobalSearch: () => {
    const modal = document.getElementById('global-search-modal');
    const input = document.getElementById('global-search-input');
    const resultsContainer = document.getElementById('global-search-results');

    if (!modal || !input || !resultsContainer) return;
    modal.classList.add('active');
    input.value = '';
    input.focus();

    input.oninput = () => {
      const q = input.value.toLowerCase().trim();
      if (!q) {
        resultsContainer.innerHTML = '';
        return;
      }

      const cases = Storage.getCases().filter(c => 
        (c.clientName || '').toLowerCase().includes(q) ||
        (c.insurance || '').toLowerCase().includes(q) ||
        (c.claimNumber || '').toLowerCase().includes(q)
      );

      const reqs = Storage.getRequests().filter(r => 
        (r.clientName || '').toLowerCase().includes(q) ||
        (r.provider || '').toLowerCase().includes(q)
      );

      const liab = Storage.getLiabilityItems().filter(l => 
        (l.clientName || '').toLowerCase().includes(q) ||
        (l.insurance3P || '').toLowerCase().includes(q)
      );

      resultsContainer.innerHTML = `
        <div style="display:flex; flex-direction:column; gap:0.5rem; max-height:400px; overflow-y:auto;">
          ${cases.map(c => `
            <div class="priority-item glass-card" style="cursor:pointer;" onclick="document.getElementById('global-search-modal').classList.remove('active'); Cases.openCaseDetails('${c.id}');">
              <div class="priority-item-header">
                <strong>📁 Caso: ${c.clientName}</strong>
                <span class="badge badge-info">DOL: ${c.dol}</span>
              </div>
              <div class="priority-item-sub">Seguro: ${c.insurance || 'Pending'} | Estado: ${c.caseStatus}</div>
            </div>
          `).join('')}

          ${reqs.map(r => `
            <div class="priority-item glass-card" style="cursor:pointer;" onclick="document.getElementById('global-search-modal').classList.remove('active'); App.switchTab('tab-requests');">
              <div class="priority-item-header">
                <strong>🏥 Request: ${r.provider}</strong>
                <span class="badge badge-warning">${r.status}</span>
              </div>
              <div class="priority-item-sub">Cliente: ${r.clientName} (${r.requestType})</div>
            </div>
          `).join('')}

          ${liab.map(l => `
            <div class="priority-item glass-card" style="cursor:pointer;" onclick="document.getElementById('global-search-modal').classList.remove('active'); App.switchTab('tab-liability');">
              <div class="priority-item-header">
                <strong>🛡️ Liability: ${l.insurance3P || 'Pending'}</strong>
                <span class="badge badge-success">${l.liabilityStatus}</span>
              </div>
              <div class="priority-item-sub">Cliente: ${l.clientName}</div>
            </div>
          `).join('')}

          ${cases.length === 0 && reqs.length === 0 && liab.length === 0 ? '<p class="text-muted p-2">Sin coincidencias encontradas.</p>' : ''}
        </div>
      `;
    };
  },

  renderActivityTab: () => {
    const importContainer = document.getElementById('import-history-list');
    const activityContainer = document.getElementById('activity-full-list');

    if (importContainer) {
      const history = Storage.getImportHistory();
      if (history.length === 0) {
        importContainer.innerHTML = '<p class="text-muted">No se han realizado importaciones manuales aún.</p>';
      } else {
        importContainer.innerHTML = history.map(h => `
          <div class="priority-item glass-card mb-2">
            <div class="priority-item-header">
              <strong>📥 ${h.fileName}</strong>
              <span class="text-muted" style="font-size:0.78rem">${Utils.getRelativeTimeString(h.timestamp)}</span>
            </div>
            <div class="priority-item-sub">
              Añadidos: <strong>${h.addedCount || 0}</strong> | Actualizados: <strong>${h.updatedCount || 0}</strong> | Notas Conservadas: <strong>${h.preservedNotesCount || 0}</strong>
            </div>
          </div>
        `).join('');
      }
    }

    if (activityContainer) {
      const logs = Storage.getActivityLogs();
      if (logs.length === 0) {
        activityContainer.innerHTML = '<p class="text-muted">Sin logs registrados.</p>';
      } else {
        activityContainer.innerHTML = logs.map(l => `
          <div class="activity-item">
            <span class="activity-dot"></span>
            <div class="activity-content">
              <div class="activity-title"><strong>[${l.targetType}] ${l.action}</strong> <small class="text-muted">(${Utils.getRelativeTimeString(l.timestamp)})</small></div>
              <div class="activity-desc">${l.details}</div>
            </div>
          </div>
        `).join('');
      }
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

window.App = App;
