/**
 * Case Assistant OS - Master AI Subsystem Manager (AIManager)
 * Acts as the primary public API entry point for the entire application.
 * Fully decoupled from UI and Storage. Coordinates providers and extractors.
 */

const AIManager = {
  activeProviderName: 'gemini',
  providers: {},

  /**
   * Initializes the AI Subsystem, registers available providers.
   */
  init: () => {
    console.log('[AIManager] Initializing AI Layer Subsystem...');

    // Register default Gemini Provider
    if (window.GeminiService) {
      AIManager.providers.gemini = new window.GeminiService();
    }

    // Set default provider
    AIManager.activeProviderName = 'gemini';
    console.log(`[AIManager] Active AI Provider set to '${AIManager.activeProviderName}'.`);
  },

  /**
   * Returns the currently active AI Provider instance.
   * @returns {AIProvider}
   */
  getProvider: () => {
    const provider = AIManager.providers[AIManager.activeProviderName];
    if (!provider) {
      throw new Error(`[AIManager] Active provider '${AIManager.activeProviderName}' is not registered.`);
    }
    return provider;
  },

  /**
   * Set or switch active AI Provider
   * @param {string|AIProvider} provider 
   */
  setProvider: (provider) => {
    if (typeof provider === 'string') {
      if (!AIManager.providers[provider]) {
        throw new Error(`[AIManager] Cannot switch to unregistered provider '${provider}'.`);
      }
      AIManager.activeProviderName = provider;
    } else if (provider && provider.name) {
      AIManager.providers[provider.name] = provider;
      AIManager.activeProviderName = provider.name;
    }
    console.log(`[AIManager] Active AI Provider changed to '${AIManager.activeProviderName}'.`);
  },

  /**
   * PRIMARY PUBLIC API: Extract Property Damage data from uploaded file(s).
   * @param {File|Array<File>} files - Native browser File or Array of File objects (PDF or Image)
   * @returns {Promise<Object>} Object containing { documents: [], mergedData: {} }
   */
  extractPropertyDamage: async (files) => {
    const provider = AIManager.getProvider();
    if (!window.AIExtractor) {
      throw new Error('[AIManager] AIExtractor module is not loaded.');
    }
    return window.AIExtractor.extractPropertyDamage(files, provider);
  },

  /**
   * FUTURE EXTENSIBILITY PUBLIC API: Generic document extraction.
   * @param {File|Array<File>} files - Native browser File or Array of File objects
   * @param {string} docType - Document type (e.g. 'PROPERTY_DAMAGE', 'MEDICAL_RECORDS', 'AUTO_DETECT')
   * @returns {Promise<Object>}
   */
  extract: async (files, docType = 'PROPERTY_DAMAGE') => {
    const provider = AIManager.getProvider();
    if (!window.AIExtractor) {
      throw new Error('[AIManager] AIExtractor module is not loaded.');
    }
    return window.AIExtractor.extractDocument(files, docType, provider);
  }
};

if (typeof window !== 'undefined') {
  window.AIManager = AIManager;
}
