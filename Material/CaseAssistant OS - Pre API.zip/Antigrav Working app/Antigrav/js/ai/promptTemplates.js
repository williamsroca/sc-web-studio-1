/**
 * Case Assistant OS - AI Prompt Templates Repository
 * Stores structured system instructions and extraction prompt templates.
 * Enforces strict zero-hallucination rules, raw numeric values, and JSON-only response formats.
 */

const AIPromptTemplates = {
  /**
   * System Instruction appended to all extraction prompts
   */
  SYSTEM_INSTRUCTION: `You are an expert legal and insurance document data extraction assistant for personal injury law practices.
Your task is to analyze the provided document (PDF text/image) and extract exact key data fields into a strict JSON object matching the requested schema.

CRITICAL INSTRUCTIONS & ZERO-HALLUCINATION RULES:
1. Extract ONLY facts explicitly present in the document.
2. If a field is not clearly specified, missing, or illegible, set its value strictly to null.
3. NEVER guess, infer, extrapolate, or invent values.
4. NUMERIC FIELDS STRATEGY: Do NOT format numbers as strings with currency symbols or commas. Return raw numbers (e.g. 5582.19 instead of "$5,582.19", 45210 instead of "45,210", 2022 instead of "2022"). UI will format strings.
5. Format VIN numbers as uppercase 17-character strings if present.
6. Return ONLY the raw JSON object. Do not include introductory text, markdown code block backticks (\`\`\`json), or conversational explanations.`,

  /**
   * Prompt builder for Property Damage Estimate & Intake documents
   * @returns {string}
   */
  getPropertyDamagePrompt: () => {
    return `${AIPromptTemplates.SYSTEM_INSTRUCTION}

DOCUMENT TYPE: Property Damage Document (Intake Form, Body Shop Estimate, Insurance Appraisal, etc.)

Please extract the following 14 fields into a JSON object:
{
  "insurance": "Insurance company name (e.g. State Farm, Geico, Progressive) or null",
  "owner": "Vehicle owner full name or null",
  "year": 2022 (raw integer year or null),
  "make": "Vehicle make (e.g. Honda, Ford, Toyota) or null",
  "model": "Vehicle model (e.g. Civic, F-150, Camry) or null",
  "color": "Vehicle exterior color or null",
  "plate": "License plate number or null",
  "vin": "17-character Vehicle Identification Number or null",
  "mileage": 45210 (raw integer odometer reading or null),
  "claimNumber": "Insurance claim number or null",
  "policyNumber": "Insurance policy number or null",
  "bodyShop": "Repair facility, collision center, or body shop name or null",
  "estimate": 5582.19 (raw decimal repair total amount without $ or commas, or null),
  "notes": "Concise summary of key damages described or repair notes, or null"
}

Remember: Use null for any field not explicitly present in the document. Do not invent data.`;
  },

  /**
   * Helper to retrieve prompt by document type
   * @param {string} docType 
   * @returns {string}
   */
  getPrompt: (docType) => {
    const typeUpper = (docType || '').toUpperCase();
    switch (typeUpper) {
      case 'PROPERTY_DAMAGE':
      case 'PROPERTY_DAMAGE_PACKAGE':
      case 'AUTO_DETECT':
        return AIPromptTemplates.getPropertyDamagePrompt();
      default:
        return AIPromptTemplates.SYSTEM_INSTRUCTION;
    }
  }
};

if (typeof window !== 'undefined') {
  window.AIPromptTemplates = AIPromptTemplates;
}
