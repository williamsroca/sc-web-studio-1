# Case Assistant OS — System Architecture

This document describes the high-level architecture, module responsibilities, and interaction patterns of **Case Assistant OS**.

---

## High-Level Design Principles

1. **Zero External Dependencies**: Standard Vanilla HTML5, ES6 JavaScript, and Vanilla CSS3. Runs natively in any browser.
2. **Single Source of Truth (`Storage`)**: All application state persists in `localStorage` under namespaced keys managed by `Storage`.
3. **Decoupled Utility Modules**: Helper modules (`ClientHelper`, `CaseSummary`, `Utils`) contain pure logic, zero DOM manipulation, and zero direct storage mutations.
4. **Centralized Dialog Management (`Modals`)**: Single-responsibility focus manager preventing stacked or overlapping native dialogs.

---

## Module Breakdown & Responsibilities

### 1. Dashboard (`js/dashboard.js`)
- **Responsibilities**: Calculates top-level KPI metrics, summary card counts, request aging distribution, and activity lists.
- **Interactions**: Reads data from `Storage.getCases()`, `Storage.getRequests()`, `Storage.getLiabilityItems()`, filtered by `Utils.filterByActiveCaseManager()`.

### 2. Cases (`js/cases.js`)
- **Responsibilities**: Manages the core portfolio table view, multi-field search, status filtering, case detail modal inspection, and quick note triggers.
- **Interactions**: Consumes `Storage.getCases()`, `Modals.openFollowUpModal()`, `NotesEngine.createRichFollowUpNote()`, and `ClientHelper`.

### 3. Requests (`js/requests.js`)
- **Responsibilities**: Handles medical records and billing requests, status updates, automated request aging badges (15/20/30 day thresholds), and follow-up notes.
- **Interactions**: Reads/writes `Storage.getRequests()`, delegates note generation to `NotesEngine`.

### 4. Liability (`js/liability.js`)
- **Responsibilities**: Tracks third-party and first-party insurance claims, adjuster details, coverage status, and communication modal triggers.
- **Interactions**: Reads/writes `Storage.getLiabilityItems()`, delegates email generation to `Modals.openCommunicationModal()`.

### 5. Notes (`js/notes.js`)
- **Responsibilities**: Generates dual follow-up notes, renders saved note history cards inside the slide-out Notes Drawer (`#notes-drawer-list`), and handles open/close drawer transitions.
- **Interactions**: Consumes `Storage.addNoteHistory()`, delegates single-line Excel clipboard copying to `CaseSummary`.

### 6. Communications (`js/communications.js`)
- **Responsibilities**: Generates structured, template-driven email copy (Subject + Body) for adjusters and insurance companies across tone choices (Friendly, Professional, Firm).
- **Interactions**: Used by `Modals.openCommunicationModal()`. Pure string template engine.

### 7. Case Summary (`js/caseSummary.js`)
- **Responsibilities**: Standalone helper module providing single-line Excel cell ready text for `Copy Name + DOL` (`LastName, FirstName - DOL MM/DD/YYYY`) and `Copy Note` (flattened single line note).
- **Interactions**: Called by `notes.js` UI action buttons; delegates clipboard write to `Utils.copyToClipboard()`.

### 8. Client Helper (`js/clientHelper.js`)
- **Responsibilities**: Standalone multi-client utility module. Manages 0, 1, or multiple client collections per case. Adapts legacy single-client fields (`clientName`, `firstName`, `lastName`) into structured client arrays without data migration.
- **Interactions**: Consumed by case and document management modules.

### 9. Case Details (`js/caseDetails.js`)
- **Responsibilities**: Pure View Controller. Renders the central Case Details workspace (`CaseDetails.open(caseData)`). Completely decoupled from `Storage`. Delegates client rendering exclusively to `ClientHelper`.
- **Interactions**: Invoked by `cases.js` with pre-fetched `caseData`.

---

## Module Interaction Overview

```
                        ┌──────────────────┐
                        │     Storage      │
                        └────────┬─────────┘
                                 │ (Get/Save Array Data)
                                 ▼
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│   dashboard.js   │    │     cases.js     │    │   requests.js    │
└──────────────────┘    └────────┬─────────┘    └──────────────────┘
                                 │
                                 ▼
                        ┌──────────────────┐
                        │   clientHelper   │
                        └──────────────────┘
                                 │
                                 ▼
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│   liability.js   │ ─► │     notes.js     │ ─► │   caseSummary    │
└──────────────────┘    └──────────────────┘    └──────────────────┘
```
