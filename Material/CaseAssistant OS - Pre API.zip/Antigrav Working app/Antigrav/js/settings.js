/**
 * Case Assistant OS - Settings & System Storage Controller
 * Handles system stats rendering, JSON database exports/imports, and database resets.
 */

const Settings = {
  /**
   * Initializes Settings tab.
   */
  init: () => {
    Settings.renderStats();
  },

  /**
   * Renders storage metrics (Counts of Cases, Requests, Liability records, and total LocalStorage bytes used).
   */
  renderStats: () => {
    const versionEl = document.getElementById('settings-version');
    const casesCount = document.getElementById('settings-cases-count');
    const reqsCount = document.getElementById('settings-reqs-count');
    const liabCount = document.getElementById('settings-liab-count');
    const storageBytesEl = document.getElementById('settings-storage-bytes');

    if (versionEl) versionEl.textContent = Storage.CURRENT_VERSION;
    if (casesCount) casesCount.textContent = Storage.getCases().length;
    if (reqsCount) reqsCount.textContent = Storage.getRequests().length;
    if (liabCount) liabCount.textContent = Storage.getLiabilityItems().length;

    if (storageBytesEl) {
      let totalBytes = 0;
      for (let x in localStorage) {
        if (localStorage.hasOwnProperty(x)) {
          totalBytes += (localStorage[x].length + x.length) * 2;
        }
      }
      const kb = (totalBytes / 1024).toFixed(2);
      storageBytesEl.textContent = `${kb} KB`;
    }
  },

  /**
   * Triggers JSON backup export.
   */
  exportData: () => {
    Storage.exportBackupJSON();
  },

  /**
   * Handles JSON file selection for database restore.
   * @param {Event} e
   */
  importData: (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      Storage.importBackupJSON(evt.target.result);
    };
    reader.readAsText(file);
  },

  /**
   * Triggers complete LocalStorage reset dialog.
   */
  wipeDatabase: () => {
    Storage.clearAllData();
  }
};

window.Settings = Settings;
