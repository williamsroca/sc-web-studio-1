/**
 * Case Assistant OS - Rich Dual Note Generator & Notes Drawer Controller
 * Generates natural, human-written Case Manager style notes in CasePeer & Excel formats.
 */

const NotesEngine = {
  /**
   * Generates a dual follow-up note (Excel single line & CasePeer multiline format) in natural English.
   * Format matches CaseManager standard:
   * Action sentence.
   * Status / Next step.
   * Next Follow-Up: MM/DD/YYYY.
   * @param {Object} params { clientName, dol, providerOrIns, contactDate, medium, person, outcome, nextStep, notes, nextFollowUpDate }
   * @returns {Object} { excelNote, casePeerNote, entry }
   */
  createRichFollowUpNote: ({ clientName, dol, providerOrIns, contactDate, medium, person, outcome, nextStep, notes, nextFollowUpDate }) => {
    const cleanClient = (clientName || '').trim();
    const cleanDOL = (dol || '').trim();
    const cleanProvider = (providerOrIns || 'Provider').trim();

    let clientHeader = cleanClient;
    if (cleanDOL) clientHeader += ` ${cleanDOL}`;

    // Sentence 1: Contact / Action statement
    let actionSentence = '';
    const cleanMedium = (medium || '').trim();
    const cleanPerson = (person || '').trim();

    if (cleanMedium === 'Phone Call') {
      if (cleanPerson && cleanPerson.toLowerCase() !== 'staff') {
        actionSentence = `Spoke with ${cleanPerson} at ${cleanProvider}.`;
      } else {
        actionSentence = `Called ${cleanProvider}.`;
      }
    } else if (cleanMedium === 'Email') {
      actionSentence = `Emailed ${cleanProvider}${cleanPerson && cleanPerson.toLowerCase() !== 'staff' ? ' (' + cleanPerson + ')' : ''}.`;
    } else if (cleanMedium === 'Fax') {
      actionSentence = `Faxed request to ${cleanProvider}.`;
    } else if (cleanMedium === 'Web Portal' || cleanMedium === 'Portal') {
      actionSentence = `Checked portal for ${cleanProvider}.`;
    } else if (cleanMedium) {
      actionSentence = `Contacted ${cleanProvider} via ${cleanMedium}.`;
    } else {
      actionSentence = `Followed up with ${cleanProvider}.`;
    }

    // Sentence 2: Status / Next step / Notes
    let detailSentence = '';
    if (nextStep && nextStep.trim()) {
      detailSentence = nextStep.trim();
      if (!detailSentence.endsWith('.')) detailSentence += '.';
    } else if (notes && notes.trim()) {
      detailSentence = notes.trim();
      if (!detailSentence.endsWith('.')) detailSentence += '.';
    } else if (outcome && outcome.trim()) {
      const cleanOutcome = outcome.trim();
      if (cleanOutcome.toLowerCase().includes('pending')) {
        detailSentence = 'Waiting for provider response.';
      } else if (cleanOutcome.toLowerCase().includes('process')) {
        detailSentence = 'In process under review.';
      } else if (cleanOutcome.toLowerCase().includes('completed') || cleanOutcome.toLowerCase().includes('received')) {
        detailSentence = 'Records received.';
      } else if (cleanOutcome.toLowerCase().includes('fee') || cleanOutcome.toLowerCase().includes('payment')) {
        detailSentence = 'Payment fee required for records.';
      } else {
        detailSentence = cleanOutcome.endsWith('.') ? cleanOutcome : cleanOutcome + '.';
      }
    }

    // Sentence 3: Next Follow-Up
    let followUpSentence = '';
    if (nextFollowUpDate && nextFollowUpDate.trim()) {
      followUpSentence = `Next Follow-Up: ${nextFollowUpDate.trim()}.`;
    }

    // Assemble CasePeer multiline note (No date header, no outcome label, no robotic headings)
    const casePeerLines = [
      actionSentence,
      detailSentence,
      followUpSentence
    ].filter(Boolean);

    const casePeerNote = casePeerLines.join('\n');

    // Excel single-line note
    const summaryShort = `${actionSentence} ${detailSentence}`.trim();
    const excelNote = clientHeader ? `${clientHeader} - ${summaryShort}` : summaryShort;

    const savedEntry = Storage.addNoteHistory(cleanClient, cleanDOL, summaryShort, excelNote, casePeerNote);
    Storage.addActivityLog('Follow-Up Note Created', `${cleanClient} (${cleanProvider}): Note logged`, 'Notes');
    
    NotesEngine.renderNotesDrawer();
    NotesEngine.openDrawer();

    return { excelNote, casePeerNote, entry: savedEntry };
  },

  /**
   * Generates a quick note from text input.
   * @param {string} clientName
   * @param {string} dol
   * @param {string} noteText
   * @param {Object} options { saveToHistory, autoOpenDrawer }
   * @returns {Object|null}
   */
  createNote: (clientName, dol, noteText, options = { saveToHistory: true, autoOpenDrawer: true }) => {
    if (!noteText || !noteText.trim()) return null;

    const cleanClient = (clientName || '').trim();
    const cleanDOL = (dol || '').trim();
    const cleanText = noteText.trim();

    let clientPart = cleanClient;
    if (cleanDOL) clientPart += ` ${cleanDOL}`;
    const excelNote = clientPart ? `${clientPart} - ${cleanText}` : cleanText;
    const casePeerNote = cleanText;

    let savedEntry = null;
    if (options.saveToHistory) {
      savedEntry = Storage.addNoteHistory(cleanClient, cleanDOL, cleanText, excelNote, casePeerNote);
      Storage.addActivityLog('Quick Note Created', `Note for ${cleanClient || 'General'}: "${cleanText.substring(0, 35)}..."`, 'Notes');
      NotesEngine.renderNotesDrawer();
      if (options.autoOpenDrawer) NotesEngine.openDrawer();
    }

    return { excelNote, casePeerNote, entry: savedEntry };
  },

  /**
   * Opens the slide-out notes drawer.
   */
  openDrawer: () => {
    document.getElementById('notes-drawer')?.classList.add('active');
    document.getElementById('notes-drawer-backdrop')?.classList.add('active');
  },

  /**
   * Closes the slide-out notes drawer.
   */
  closeDrawer: () => {
    document.getElementById('notes-drawer')?.classList.remove('active');
    document.getElementById('notes-drawer-backdrop')?.classList.remove('active');
  },

  /**
   * Toggles the visibility of the slide-out notes drawer.
   */
  toggleDrawer: () => {
    const drawer = document.getElementById('notes-drawer');
    if (drawer?.classList.contains('active')) NotesEngine.closeDrawer();
    else NotesEngine.openDrawer();
  },

  /**
   * Renders saved note cards in the slide-out notes drawer.
   */
  renderNotesDrawer: () => {
    const container = document.getElementById('notes-drawer-list');
    if (!container) return;

    const notes = Storage.getNotesHistory();
    if (notes.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <span style="font-size:2rem; display:block; margin-bottom:0.5rem;">📝</span>
          <p class="text-muted" style="font-size: 0.88rem;">No generated notes yet.<br>Manual updates will generate notes here.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = notes.map((item) => `
      <div class="note-card glass-card mb-3">
        <div class="note-header">
          <span class="note-title">${item.clientName ? item.clientName : 'General Note'} ${item.dol ? `<small class="text-muted">(${item.dol})</small>` : ''}</span>
          <span class="note-time">${Utils.getRelativeTimeString(item.timestamp)}</span>
        </div>
        
        <div class="note-body" style="white-space: pre-wrap; font-family: monospace; font-size: 0.82rem; background: rgba(0,0,0,0.15); padding: 0.5rem; border-radius: 4px; margin: 0.4rem 0;">${item.casePeerNote || item.text}</div>
        
        <div class="note-actions" style="display:flex; gap:0.35rem; flex-wrap:wrap;">
          <button class="btn btn-xs btn-outline-excel" onclick="Utils.copyToClipboard('${(item.excelNote || '').replace(/'/g, "\\'").replace(/\n/g, ' ')}', 'Excel Note')">
            📋 Copy Excel
          </button>
          <button class="btn btn-xs btn-outline-excel" onclick="CaseSummary.copyNameAndDOL('${(item.clientName || '').replace(/'/g, "\\'").replace(/\n/g, ' ')}', '${(item.dol || '').replace(/'/g, "\\'").replace(/\n/g, ' ')}')">
            📋 Copy Name + DOL
          </button>
          <button class="btn btn-xs btn-outline-casepeer" onclick="CaseSummary.copyNote('${((item.casePeerNote || item.text) || '').replace(/'/g, "\\'").replace(/\n/g, '\\n')}')">
            📋 Copy Note
          </button>
        </div>
      </div>
    `).join('');
  },

  /**
   * Renders note history cards contextualized for a case inside a specified target container.
   * @param {string} containerId DOM element ID to render into
   * @param {Object} caseData Case data object
   */
  renderCaseNotesList: (containerId, caseData) => {
    const container = document.getElementById(containerId);
    if (!container) return;

    const allNotes = Storage.getNotesHistory();
    const primaryName = window.ClientHelper ? ClientHelper.formatSingleClient(caseData) : (caseData.clientName || '');
    const cleanPrimary = primaryName.toLowerCase().trim();
    const cleanDOL = (caseData.dol || '').trim();

    // Filter notes matching this case's client name or DOL
    let caseNotes = allNotes.filter(n => {
      const nClient = (n.clientName || '').toLowerCase().trim();
      const nDOL = (n.dol || '').trim();
      return (cleanPrimary && nClient.includes(cleanPrimary)) || (cleanDOL && nDOL === cleanDOL);
    });

    if (caseNotes.length === 0) {
      caseNotes = allNotes.slice(0, 3);
    }

    if (caseNotes.length === 0) {
      container.innerHTML = `
        <div class="empty-state p-2 text-center">
          <p class="text-muted" style="font-size: 0.82rem; margin:0;">No notes generated yet for this case.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = caseNotes.slice(0, 5).map((item) => `
      <div class="note-card glass-card p-2 mb-2" style="background:rgba(255,255,255,0.02); border:1px solid var(--glass-border);">
        <div class="note-header" style="display:flex; justify-content:space-between; align-items:center; font-size:0.8rem; margin-bottom:0.3rem;">
          <span class="note-title" style="font-weight:600;">${item.clientName ? item.clientName : 'General Note'} ${item.dol ? `<small class="text-muted">(${item.dol})</small>` : ''}</span>
          <span class="note-time text-muted" style="font-size:0.75rem;">${Utils.getRelativeTimeString(item.timestamp)}</span>
        </div>
        
        <div class="note-body mb-2" style="white-space: pre-wrap; font-family: monospace; font-size: 0.8rem; background: rgba(0,0,0,0.15); padding: 0.4rem; border-radius: 4px;">${item.casePeerNote || item.text}</div>
        
        <div class="note-actions" style="display:flex; gap:0.3rem; flex-wrap:wrap;">
          <button class="btn btn-xs btn-outline-excel" onclick="Utils.copyToClipboard('${(item.excelNote || '').replace(/'/g, "\\'").replace(/\n/g, ' ')}', 'Excel Note')">
            📋 Copy Excel
          </button>
          <button class="btn btn-xs btn-outline-excel" onclick="CaseSummary.copyNameAndDOL('${(item.clientName || '').replace(/'/g, "\\'").replace(/\n/g, ' ')}', '${(item.dol || '').replace(/'/g, "\\'").replace(/\n/g, ' ')}')">
            📋 Copy Name + DOL
          </button>
          <button class="btn btn-xs btn-outline-casepeer" onclick="CaseSummary.copyNote('${((item.casePeerNote || item.text) || '').replace(/'/g, "\\'").replace(/\n/g, '\\n')}')">
            📋 Copy Note
          </button>
        </div>
      </div>
    `).join('');
  }
};

window.NotesEngine = NotesEngine;
