# Case Assistant OS — Product Roadmap

This document summarizes completed releases, the current version, and upcoming feature sprints for **Case Assistant OS**.

---

## Completed Releases

- **`v1.0.0` (Initial Release)**: Personal workspace dashboard, glassmorphism design system, initial CSV seeding.
- **`v1.5.0` (Custom Modals & Dual Notes)**: Automated request aging calculator, glassmorphism custom modal framework, portable desktop launcher (`start_app.bat`), CasePeer & Excel dual note generator.
- **`v1.5.1` (Dropdown Audits)**: Case Manager request filters, dark mode contrast enhancements.
- **`v1.6.0` (Global Case Manager & Session Log)**: Global active Case Manager selector, End of Day Summary ("Finalizar Jornada") modal, API integration architecture.
- **`v1.6.6` (Case Summary Optimizer)**: Standalone `js/caseSummary.js` utility, single-line Excel cell copy buttons (`Copy Name + DOL`, `Copy Note`).

---

## Current Version

### `v1.7.4` — Notes Workspace Migration
- **Notes Module Composition (`CaseDetails.renderNotes`)**: Embedded existing `NotesEngine` and `CaseSummary` modules natively into Case Details workspace with auto-populated case context (Client Name, DOL, Insurance) and single-cell Excel copy actions (`Copy Excel`, `Copy Name + DOL`, `Copy Note`).

---

## Upcoming Releases

### `v1.7.5` — Communications Center Workspace Migration
- Transform the existing Communications Engine into a full Communications Center inside Case Details (Weekly Client Updates, Smart Autofill Templates, Provider & Insurance Outreach) without duplicating communication logic.

---

## Future Ideas & Backlog

- **Integrations Activation**: Live sync with Google Calendar API, Outlook M365, and CasePeer API.
- **Advanced CSV Rules**: Custom field mapping editor for non-standard CSV headers during import.
- **PDF Report Exporter**: Direct client status summary PDF generation for law firm partners.
