/**
 * Case Assistant OS - Gemini Service Provider
 * Implements AIProvider for Google Gemini 1.5/2.0 Flash API via the secure serverless proxy endpoint (/api/v1/ai/extract).
 */

class GeminiService extends window.AIProvider {
  constructor() {
    super('gemini');
    this.primaryEndpoint = '/api/v1/ai/extract';
    this.fallbackEndpoint = '/api/extract';
  }

  /**
   * Executes multi-file or single-file document extraction via Gemini Flash API proxy endpoint.
   * @param {Object} options
   * @param {Object|Array} options.filePayload - Single file payload { base64Data, mimeType, fileName } or array of files
   * @param {string} [options.prompt] - Prompt text
   * @param {string} [options.docType] - Document type identifier (e.g. 'PROPERTY_DAMAGE')
   * @returns {Promise<Object>} Full response envelope { status, documents[], mergedData }
   */
  async executeExtraction({ filePayload, prompt, docType }) {
    // Normalize files payload into array
    let filesArray = [];
    if (Array.isArray(filePayload)) {
      filesArray = filePayload;
    } else if (filePayload && filePayload.base64Data) {
      filesArray = [filePayload];
    }

    if (filesArray.length === 0) {
      throw new Error('[GeminiService] Missing required file payload base64 data.');
    }

    const payload = {
      documentType: docType || 'PROPERTY_DAMAGE',
      provider: 'gemini',
      options: {
        strictNulls: true,
        includeConfidence: true
      },
      files: filesArray.map((f, idx) => ({
        id: f.id || `file_${idx + 1}_${Date.now()}`,
        fileName: f.fileName || `document_${idx + 1}.pdf`,
        mimeType: f.mimeType || 'application/pdf',
        sizeBytes: f.sizeBytes || Math.ceil(((f.base64Data || '').length * 3) / 4),
        base64Data: f.base64Data
      }))
    };

    console.log(`[GeminiService] Sending extraction request for ${filesArray.length} file(s) to proxy endpoint (${this.primaryEndpoint})...`);

    let response = null;
    let endpointUsed = this.primaryEndpoint;

    try {
      response = await fetch(this.primaryEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });
    } catch (primaryErr) {
      console.warn(`[GeminiService] Primary endpoint '${this.primaryEndpoint}' unreachable. Trying fallback '${this.fallbackEndpoint}'...`);
      endpointUsed = this.fallbackEndpoint;
      response = await fetch(this.fallbackEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });
    }

    if (!response.ok) {
      let errMessage = `HTTP Error ${response.status}: ${response.statusText}`;
      try {
        const errData = await response.json();
        if (errData && errData.error && errData.error.message) {
          errMessage = `${errData.error.code || 'ERROR'}: ${errData.error.message}`;
        }
      } catch (e) {
        // Fallback
      }
      throw new Error(`[GeminiService] Proxy request to '${endpointUsed}' failed: ${errMessage}`);
    }

    const responseEnvelope = await response.json();
    return responseEnvelope;
  }
}

if (typeof window !== 'undefined') {
  window.GeminiService = GeminiService;
}
