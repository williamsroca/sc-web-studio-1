# Case Assistant OS — Git Workflow & Branching Strategy

This document outlines the version control policies, branching strategies, and merge workflows for **Case Assistant OS**.

---

## Branching Model

```text
 feature/sprint work
       │
       ▼
   refactor ─────────► [ Local Browser Testing ]
       │
       │ (Merge after thorough validation)
       ▼
     main   ─────────► [ Tag Release vX.Y.Z ]
```

### 1. `refactor` (Development Branch)
- All active development, feature implementations, bug fixes, and infrastructure refactoring take place on `refactor`.
- Commits are made directly or via topic branches merged into `refactor`.

### 2. `main` (Production Branch)
- `main` always represents the latest stable production release.
- Code is merged into `main` ONLY after passing full verification checklists (0 console errors, UI regression checks, backward data compatibility checks).
- Direct unreviewed commits to `main` are strictly prohibited.

---

## Standard Development Workflow

1. **Develop on `refactor`**:
   Write code, add helper utilities, and update UI components on the `refactor` branch.

2. **Test Locally**:
   Launch `start_app.bat` or open `index.html` locally in a modern browser. Verify all features, console output, and storage operations.

3. **Commit Changes**:
   ```bash
   git add .
   git commit -m "feat(scope): descriptive summary of changes"
   ```

4. **Push to `refactor`**:
   ```bash
   git push origin refactor
   ```

5. **Merge into `main`**:
   Switch to `main` and merge `refactor`:
   ```bash
   git checkout main
   git merge refactor
   ```

6. **Tag Release**:
   Create a annotated git tag corresponding to `VERSION.md`:
   ```bash
   git tag -a v1.7.0 -m "Release v1.7.0 - Multi-Client Foundation & Project Documentation"
   git push origin main --tags
   ```

7. **Create GitHub Release**:
   Publish the GitHub release attaching changelog release notes.

---

## Why `main` Always Represents Latest Stable Version

- Ensures zero downtime or broken states for Case Managers utilizing the workspace.
- Guarantees `main` can be cloned and executed immediately with zero build scripts or setup.
- Enables clear semantic version rollback if unforeseen browser edge cases occur.
