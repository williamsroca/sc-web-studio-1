# Case Assistant OS

Case Assistant OS is a personal workspace web application designed for Personal Injury Law Case Managers (specifically tailored for KR Law workflows). It streamlines daily case management, medical records/billing request tracking, third-party liability management, automatic dual-note generation (CasePeer & Excel), email communications, and end-of-day productivity reporting.

---

## Main Features

- **Dashboard & KPI Analytics**: Real-time overview of active cases, request aging thresholds, liability status, and manager metrics.
- **Global Active Case Manager Filter**: Topbar selector filtering application state single-source-of-truth across all tabs.
- **Cases Management**: Filterable portfolio table with multi-search, stage tracking, and detailed case inspection modals.
- **Medical Requests Tracker**: Dedicated aging calculator (15/20/30 day thresholds) for provider records and bill follow-ups.
- **Liability Module**: 3P/1P insurance claim tracking, adjuster logs, and automated communication generator integration.
- **Dual Note Generator & Slide-Out Drawer**: Instant standard CaseManager follow-up notes formatted for CasePeer and 1-click single-line Excel cell copy (`Copy Name + DOL`, `Copy Note`).
- **Communication Generator**: Instant template-based email generation with customizable tones (Friendly, Professional, Firm).
- **End-of-Day Summary ("Finalizar Jornada")**: Session logger summarizing daily follow-ups, updates, and exports.
- **Multi-Client Foundation**: Internal data architecture supporting multi-client case relationships with 100% legacy backward compatibility.
- **CSV Data Merger**: Non-degrading CSV importer with auto-matching and date preservation.

---

## Current Architecture

Case Assistant OS follows a clean, zero-dependency, modular Vanilla HTML/CSS/JavaScript architecture. Modules communicate through explicit event handlers and the central `Storage` and `Utils` singletons:

```
                  ┌────────────────────────┐
                  │       index.html       │
                  └───────────┬────────────┘
                              │
             ┌────────────────┴────────────────┐
             ▼                                 ▼
   ┌───────────────────┐             ┌───────────────────┐
   │    Core State     │             │ Controller Layer  │
   │ ───────────────── │             │ ───────────────── │
   │ storage.js        │             │ dashboard.js      │
   │ utils.js          │ ──────────► │ cases.js          │
   │ clientHelper.js   │             │ requests.js       │
   │ caseSummary.js    │             │ liability.js      │
   └───────────────────┘             └───────────────────┘
             │                                 │
             ▼                                 ▼
   ┌───────────────────┐             ┌───────────────────┐
   │ Modal & UI Dialogs│             │   Integrations    │
   │ ───────────────── │             │ ───────────────── │
   │ modals.js         │             │ communications.js │
   │ notes.js          │             │ csvImporter.js    │
   └───────────────────┘             └───────────────────┘
```

---

## Folder Structure

```text
├── css/
│   └── styles.css              # Central glassmorphic design system & UI styles
├── js/
│   ├── app.js                  # Main application bootstrap & tab routing
│   ├── cases.js                # Cases portfolio tab controller
│   ├── caseSummary.js          # Standalone Case Summary Excel formatting utility
│   ├── clientHelper.js         # Multi-client data model helper utility
│   ├── communications.js       # Template communication engine
│   ├── csvImporter.js          # Non-destructive CSV parsing & data merger
│   ├── dashboard.js            # KPI metrics & activity summaries
│   ├── liability.js            # Liability management controller
│   ├── modals.js               # Centralized modal queue manager
│   ├── notes.js                # Dual Note generator & slide-out drawer
│   ├── requests.js             # Medical records/billing request controller
│   ├── settings.js             # Data backup export/import & settings
│   ├── storage.js              # LocalStorage persistence layer & initial seeds
│   ├── utils.js                # Date formatting, filtering, toast & clipboard helpers
│   └── integrations/           # External API integration placeholders
├── docs/                       # Project documentation
│   ├── Architecture.md         # System architecture & module interactions
│   ├── GitWorkflow.md          # Git branching & release workflow
│   ├── Roadmap.md              # Version history & future feature roadmap
│   └── ReleaseProcess.md       # Step-by-step release checklist
├── index.html                  # Main application HTML SPA container
├── start_app.bat               # Windows local launcher script
├── CHANGELOG.md                # Semantic version release notes
├── README.md                   # Main project documentation
└── VERSION.md                  # Current version tracking file (v1.7.0)
```

---

## Technology Stack

- **Core**: Vanilla HTML5, Vanilla JavaScript (ES6+), Vanilla CSS3.
- **Styling**: Custom CSS custom properties, glassmorphism UI tokens, Google Fonts (Inter).
- **Persistence**: Browser `localStorage` with JSON backup export/import.
- **Dependencies**: 0 external npm dependencies or build tools.

---

## How to Run Locally

1. Clone or download the repository to your local machine.
2. Double-click `start_app.bat` or open `index.html` directly in any modern web browser (Chrome, Edge, Firefox, Safari).
3. No web server, Node.js, or build step is required.

---

## Current Git Workflow

- All feature work and refactoring take place on the `refactor` branch.
- Changes are thoroughly tested locally in the browser before merging into `main`.
- `main` always represents the latest stable production release.
- Merges to `main` are tagged with semantic version numbers (`vX.Y.Z`) and published as GitHub Releases.

---

## Release Strategy & Roadmap Summary

- **Strategy**: Semantic Versioning (`MAJOR.MINOR.PATCH`).
- **Current Version**: `1.7.0` (Multi-Client Foundation & Project Documentation).
- **Upcoming Releases**:
  - `v1.7.1`: Client Management UI
  - `v1.7.2`: Communications Migration
  - `v1.7.3`: Notes Migration

---

## Current Version

`v1.7.0`
