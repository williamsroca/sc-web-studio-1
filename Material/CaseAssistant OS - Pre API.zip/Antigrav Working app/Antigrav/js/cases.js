/**
 * Case Assistant OS - Cases Controller
 * Handles Case management table rendering, multi-field filtering, detail view modal,
 * section summary header cards, and quick case notes.
 */

const Cases = {
  activeSearch: '',
  activeStatusFilter: '',
  activeManagerFilter: '',

  /**
   * Initializes the Cases tab module.
   */
  init: () => {
    Cases.renderSummaryHeader();
    Cases.renderCasesTable();
    Cases.setupFilters();
  },

  /**
   * Sets status filter programmatically from Dashboard KPI navigation.
   * @param {string} status
   */
  setFilterStatus: (status) => {
    Cases.activeStatusFilter = (status || '').toLowerCase();
    const statusSelect = document.getElementById('cases-filter-status');
    if (statusSelect) statusSelect.value = status ? status : '';
    Cases.renderSummaryHeader();
    Cases.renderCasesTable();
  },

  /**
   * Sets up DOM event listeners for search input and dropdown filters.
   */
  setupFilters: () => {
    const searchInput = document.getElementById('cases-search-input');
    const statusSelect = document.getElementById('cases-filter-status');
    const managerSelect = document.getElementById('cases-filter-manager');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        Cases.activeSearch = e.target.value.toLowerCase().trim();
        Cases.renderCasesTable();
      });
    }

    if (statusSelect) {
      statusSelect.addEventListener('change', (e) => {
        Cases.activeStatusFilter = e.target.value.toLowerCase();
        Cases.renderCasesTable();
      });
    }

    if (managerSelect) {
      managerSelect.addEventListener('change', (e) => {
        Cases.activeManagerFilter = e.target.value.toLowerCase();
        Cases.renderCasesTable();
      });
    }
  },

  /**
   * Renders top Section Summary Header cards for Cases tab.
   */
  renderSummaryHeader: () => {
    const container = document.getElementById('cases-summary-header');
    if (!container) return;

    const cases = Utils.filterByActiveCaseManager(Storage.getCases());
    const total = cases.length;
    const intake = cases.filter(c => (c.caseStatus || '').toLowerCase().includes('intake')).length;
    const treating = cases.filter(c => (c.caseStatus || '').toLowerCase().includes('treating')).length;
    const closedOrDrop = cases.filter(c => (c.caseStatus || '').toLowerCase().includes('drop') || (c.caseStatus || '').toLowerCase().includes('closed')).length;

    container.innerHTML = `
      <div class="kpi-grid mb-3">
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Cases.setFilterStatus('')">
          <span class="kpi-title">Total Cases</span>
          <span class="kpi-value">${total}</span>
          <span class="kpi-sub">all portfolio cases</span>
        </div>
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Cases.setFilterStatus('intake')">
          <span class="kpi-title">Intake Stage</span>
          <span class="kpi-value" style="color:var(--accent-primary)">${intake}</span>
          <span class="kpi-sub">new clients</span>
        </div>
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Cases.setFilterStatus('treating')">
          <span class="kpi-title">Active Treating</span>
          <span class="kpi-value" style="color:var(--status-success)">${treating}</span>
          <span class="kpi-sub">medical treatment active</span>
        </div>
        <div class="kpi-card glass-card" style="cursor:pointer;" onclick="Cases.setFilterStatus('pending drop')">
          <span class="kpi-title">Pending Drop / Closed</span>
          <span class="kpi-value" style="color:var(--text-muted)">${closedOrDrop}</span>
          <span class="kpi-sub">inactive / pending drop</span>
        </div>
      </div>
    `;
  },

  /**
   * Renders the Cases table with active local and global manager filters applied.
   */
  renderCasesTable: () => {
    const container = document.getElementById('cases-table-body');
    if (!container) return;

    const rawCases = Storage.getCases();

    // Dynamically populate Case Manager dropdown options
    const managerSelect = document.getElementById('cases-filter-manager');
    if (managerSelect && managerSelect.options.length <= 1) {
      const managers = Array.from(new Set(rawCases.map(c => c.caseManager || c.attorney).filter(Boolean))).sort();
      managers.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m;
        opt.textContent = m;
        managerSelect.appendChild(opt);
      });
    }

    // Apply Global Active Case Manager Filter (Single Source of Truth)
    let cases = Utils.filterByActiveCaseManager(rawCases);

    // Apply Local Search Query Filter
    if (Cases.activeSearch) {
      const q = Cases.activeSearch;
      cases = cases.filter(c => 
        (c.clientName || '').toLowerCase().includes(q) ||
        (c.dol || '').toLowerCase().includes(q) ||
        (c.insurance || '').toLowerCase().includes(q) ||
        (c.claimNumber || '').toLowerCase().includes(q) ||
        (c.caseStatus || '').toLowerCase().includes(q) ||
        (c.fileNumber || '').toLowerCase().includes(q) ||
        (c.adjuster || '').toLowerCase().includes(q)
      );
    }

    // Apply Local Status Filter
    if (Cases.activeStatusFilter) {
      cases = cases.filter(c => (c.caseStatus || '').toLowerCase().includes(Cases.activeStatusFilter));
    }

    // Apply Local Manager Filter
    if (Cases.activeManagerFilter) {
      cases = cases.filter(c => (c.caseManager || c.attorney || '').toLowerCase().includes(Cases.activeManagerFilter));
    }

    if (cases.length === 0) {
      container.innerHTML = `
        <tr>
          <td colspan="7" class="text-center text-muted py-4">
            No cases found matching the selected criteria.
          </td>
        </tr>
      `;
      return;
    }

    container.innerHTML = cases.map(c => {
      const stage = c.caseStatus || 'Treating';
      const liabilityBadge = (c.liabilityStatus || '').toLowerCase().includes('pending') ? 
        `<span class="badge badge-warning">Pending</span>` : 
        `<span class="badge badge-success">${c.liabilityStatus || 'Accepted'}</span>`;

      return `
        <tr>
          <td>
            <div class="user-avatar-info">
              <div class="user-avatar">${(c.clientName || 'C')[0].toUpperCase()}</div>
              <div>
                <strong>${c.clientName}</strong>
                ${c.fileNumber ? `<div style="font-size:0.75rem; color:var(--text-muted)">File #${c.fileNumber}</div>` : ''}
              </div>
            </div>
          </td>
          <td><strong>${c.dol || '-'}</strong></td>
          <td><span class="badge badge-info">${stage}</span></td>
          <td>${liabilityBadge}</td>
          <td>${c.insurance || '<span class="text-muted">Unassigned</span>'}</td>
          <td>${c.caseManager || c.attorney || 'Erin Garcia'}</td>
          <td>
            <div class="action-btn-group">
              <button class="btn btn-xs btn-outline" onclick="Cases.openCaseDetails('${c.id}')">👁️ View Details</button>
              <button class="btn btn-xs btn-primary" onclick="Cases.quickNote('${c.id}')">📝 Note</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  /**
   * Opens the full details view for a target case by fetching caseData from Storage and delegating rendering to CaseDetails View.
   * @param {string} caseId
   */
  openCaseDetails: (caseId) => {
    const cases = Storage.getCases();
    const caseData = cases.find(item => item.id === caseId);
    if (caseData && window.CaseDetails) {
      CaseDetails.open(caseData);
    }
  },

  /**
   * Central controller handler for multi-client actions (add, edit, remove, setPrimary).
   * Delegates array operations to ClientHelper, persists to Storage, and refreshes UI views.
   * @param {string} caseId 
   * @param {'add'|'edit'|'remove'|'setPrimary'} actionType 
   * @param {Object} payload 
   */
  handleClientAction: (caseId, actionType, payload = {}) => {
    const cases = Storage.getCases();
    const caseData = cases.find(c => c.id === caseId);
    if (!caseData) return;

    let toastMsg = 'Client updated';

    if (actionType === 'add') {
      ClientHelper.addClient(caseData, payload);
      toastMsg = 'Client added successfully';
    } else if (actionType === 'edit') {
      ClientHelper.updateClient(caseData, payload.clientId, payload.fields);
      toastMsg = 'Client details updated';
    } else if (actionType === 'remove') {
      ClientHelper.removeClient(caseData, payload.clientId);
      toastMsg = 'Client removed';
    } else if (actionType === 'setPrimary') {
      ClientHelper.setPrimaryClient(caseData, payload.clientId);
      toastMsg = 'Primary client updated';
    }

    Storage.saveCase(caseData);

    // Refresh Cases table view
    Cases.renderCasesTable();

    // Refresh Case Details view if active
    if (window.CaseDetails) {
      CaseDetails.open(caseData);
    }

    Utils.showToast(toastMsg, 'success');
  },

  /**
   * Opens modal to add a new client to a case.
   * @param {string} caseId 
   */
  openAddClientModal: (caseId) => {
    Modals.openClientFormModal({
      title: 'Add Co-Client',
      client: {},
      onSave: (data) => Cases.handleClientAction(caseId, 'add', data)
    });
  },

  /**
   * Opens modal to edit an existing client on a case.
   * @param {string} caseId 
   * @param {string} clientId 
   */
  openEditClientModal: (caseId, clientId) => {
    const cases = Storage.getCases();
    const caseData = cases.find(c => c.id === caseId);
    if (!caseData) return;

    const clients = ClientHelper.getClients(caseData);
    const target = clients.find(c => c.id === clientId);
    if (!target) return;

    Modals.openClientFormModal({
      title: 'Edit Client Details',
      client: target,
      onSave: (data) => Cases.handleClientAction(caseId, 'edit', { clientId, fields: data })
    });
  },

  /**
   * Prompts confirmation and removes a client from a case.
   * @param {string} caseId 
   * @param {string} clientId 
   */
  removeClient: async (caseId, clientId) => {
    const cases = Storage.getCases();
    const caseData = cases.find(c => c.id === caseId);
    if (!caseData) return;

    const clients = ClientHelper.getClients(caseData);
    const target = clients.find(c => c.id === clientId);
    const clientName = target ? ClientHelper.formatSingleClient(target) : 'this client';

    const confirmed = await Modals.confirm({
      title: 'Remove Client',
      message: `Are you sure you want to remove ${clientName} from this case?`,
      confirmText: 'Yes, Remove',
      isDanger: true
    });

    if (confirmed) {
      Cases.handleClientAction(caseId, 'remove', { clientId });
    }
  },

  /**
   * Sets a client as primary for a case.
   * @param {string} caseId 
   * @param {string} clientId 
   */
  setPrimaryClient: (caseId, clientId) => {
    Cases.handleClientAction(caseId, 'setPrimary', { clientId });
  },

  /**
   * Saves updated notes for a case and triggers a note entry.
   * @param {string} caseId
   */
  saveCaseNotes: (caseId) => {
    const cases = Storage.getCases();
    const c = cases.find(item => item.id === caseId);
    if (!c) return;

    const textarea = document.getElementById(`case-notes-input-${caseId}`);
    if (!textarea) return;

    const newNoteText = textarea.value.trim();
    c.notes = newNoteText;
    Storage.saveCase(c);

    NotesEngine.createNote(c.clientName, c.dol, newNoteText);
    Utils.showToast('Case notes saved', 'success');

    document.getElementById('case-modal')?.classList.remove('active');
  },

  /**
   * Opens the quick follow-up note modal for a target case.
   * @param {string} caseId
   */
  quickNote: (caseId) => {
    const cases = Storage.getCases();
    const c = cases.find(item => item.id === caseId);
    if (!c) return;

    Modals.openFollowUpModal({
      title: 'Quick Case Note / Follow Up',
      clientName: c.clientName,
      dol: c.dol,
      providerOrIns: c.insurance || 'Case Management',
      onSave: (data) => {
        c.notes = (c.notes ? c.notes + '\n' : '') + data.notes;
        Storage.saveCase(c);
        
        NotesEngine.createRichFollowUpNote({
          clientName: c.clientName,
          dol: c.dol,
          providerOrIns: c.insurance || 'Insurance',
          contactDate: data.contactDate,
          medium: data.medium,
          person: data.person,
          outcome: data.outcome,
          nextStep: data.nextStep,
          notes: data.notes,
          nextFollowUpDate: Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000))
        });

        Utils.showToast('Case note added to drawer!', 'success');
        Cases.renderCasesTable();
      }
    });
  }
};

window.Cases = Cases;
