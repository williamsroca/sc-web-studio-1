/**
 * Case Assistant v1.5 - Liability Management Controller
 */

const Liability = {
  activeSearch: '',
  activeStatusFilter: '',

  init: () => {
    Liability.renderLiabilityTable();
    Liability.setupSearch();
  },

  setupSearch: () => {
    const searchInput = document.getElementById('liab-search-input');
    const statusSelect = document.getElementById('liab-filter-status');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        Liability.activeSearch = e.target.value.toLowerCase().trim();
        Liability.renderLiabilityTable();
      });
    }

    if (statusSelect) {
      statusSelect.addEventListener('change', (e) => {
        Liability.activeStatusFilter = e.target.value.toLowerCase();
        Liability.renderLiabilityTable();
      });
    }
  },

  renderLiabilityTable: () => {
    const container = document.getElementById('liability-table-body');
    if (!container) return;

    let items = Storage.getLiabilityItems();
    const q = Liability.activeSearch;

    if (q) {
      items = items.filter(l => 
        (l.clientName || '').toLowerCase().includes(q) ||
        (l.insurance3P || '').toLowerCase().includes(q) ||
        (l.insurance1P || '').toLowerCase().includes(q) ||
        (l.adjuster || '').toLowerCase().includes(q) ||
        (l.liabilityStatus || '').toLowerCase().includes(q) ||
        (l.dol || '').toLowerCase().includes(q)
      );
    }

    if (Liability.activeStatusFilter) {
      items = items.filter(l => (l.liabilityStatus || '').toLowerCase().includes(Liability.activeStatusFilter));
    }

    if (items.length === 0) {
      container.innerHTML = `
        <tr>
          <td colspan="7" class="text-center text-muted py-4">
            No se encontraron casos de Liability con los criterios seleccionados.
          </td>
        </tr>
      `;
      return;
    }

    container.innerHTML = items.map(l => {
      // REAL DATE LOGIC FOR LIABILITY
      const hasRealDate = Boolean(l.lastContactDate || l.lastContact);
      const dateDisplay = hasRealDate ? (l.lastContactDate || l.lastContact) : '<span class="badge badge-danger">Fecha desconocida</span>';
      
      const daysOverdue = l.nextFollowUpDate ? Utils.daysFromToday(l.nextFollowUpDate) : 0;
      const badgeClass = !hasRealDate ? 'badge-danger' : (daysOverdue < 0 ? 'badge-danger' : (daysOverdue === 0 ? 'badge-warning' : 'badge-success'));
      const badgeText = !hasRealDate ? 'Requiere revisión' : (daysOverdue < 0 ? `${Math.abs(daysOverdue)}d Overdue` : `En ${daysOverdue}d`);

      return `
        <tr>
          <td>
            <strong>${l.clientName}</strong>
            <div style="font-size:0.75rem; color:var(--text-muted)">DOL: ${l.dol || 'N/A'}</div>
          </td>
          <td>🛡️ <strong>${l.insurance3P || l.insurance1P || 'Seguro Pendiente'}</strong></td>
          <td>
            <select class="form-select-sm" onchange="Liability.updateLiabilityStatus('${l.id}', this.value)">
              <option value="Pending" ${l.liabilityStatus === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Accepted" ${l.liabilityStatus === 'Accepted' ? 'selected' : ''}>Accepted</option>
              <option value="Denied" ${l.liabilityStatus === 'Denied' ? 'selected' : ''}>Denied</option>
              <option value="Disputed" ${l.liabilityStatus === 'Disputed' ? 'selected' : ''}>Disputed</option>
            </select>
          </td>
          <td>${l.pendingItems || 'Pendiente Reporte Policial / CHP'}</td>
          <td>${dateDisplay}</td>
          <td>
            <span class="badge ${badgeClass}">${badgeText}</span>
          </td>
          <td>
            <div class="action-btn-group">
              <button class="btn btn-xs btn-primary" onclick="Liability.openRegisterFollowUpModal('${l.id}')" title="Registrar Contacto">📞 Contacto</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  updateLiabilityStatus: (id, newStatus) => {
    const items = Storage.getLiabilityItems();
    const l = items.find(item => item.id === id);
    if (!l) return;

    l.liabilityStatus = newStatus;
    Storage.saveLiabilityItem(l);

    const noteText = `Updated 3P Liability status to ${newStatus}.`;
    NotesEngine.createNote(l.clientName, l.dol, noteText);
    Storage.addActivityLog('Liability Status Updated', `${l.clientName}: Liability cambiado a ${newStatus}`, 'Liability');
    Utils.showToast(`Estado de Liability actualizado a ${newStatus}`, 'success');

    Dashboard.init();
  },

  // Open "Registrar Follow Up" Modal for Liability
  openRegisterFollowUpModal: (id) => {
    const items = Storage.getLiabilityItems();
    const l = items.find(item => item.id === id);
    if (!l) return;

    Modals.openFollowUpModal({
      title: 'Registrar Contacto / Follow Up de Liability',
      clientName: l.clientName,
      dol: l.dol,
      providerOrIns: l.insurance3P || l.insurance1P || 'Seguro Liability',
      type: 'Liability',
      onSave: (data) => {
        const nextDate = Utils.formatDate(new Date(Date.now() + data.daysNext * 24 * 60 * 60 * 1000));
        
        l.lastContactDate = data.contactDate;
        l.lastFollowUpDate = data.contactDate;
        l.nextFollowUpDate = nextDate;
        
        const summary = `Liability follow-up: ${data.outcome}. ${data.nextStep || ''}`.trim();
        l.notes = (l.notes ? l.notes + '\n' : '') + summary;
        
        Storage.saveLiabilityItem(l);

        NotesEngine.createRichFollowUpNote({
          clientName: l.clientName,
          dol: l.dol,
          providerOrIns: l.insurance3P || l.insurance1P || 'Aseguradora Liability',
          contactDate: data.contactDate,
          medium: data.medium,
          person: data.person,
          outcome: data.outcome,
          nextStep: data.nextStep,
          notes: data.notes,
          nextFollowUpDate: nextDate
        });

        Storage.addActivityLog('Liability Follow Up', `${l.clientName}: Contacto de Liability registrado.`, 'Liability');
        Utils.showToast('Seguimiento de Liability guardado y notas generadas!', 'success');

        Liability.renderLiabilityTable();
        Dashboard.init();
      }
    });
  }
};

window.Liability = Liability;
